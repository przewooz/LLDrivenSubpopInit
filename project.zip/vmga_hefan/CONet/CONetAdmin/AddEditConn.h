#pragma once

#include  "atlstr.h"  //CString
#include  "..\\HEFAN\\TopologyTranslator.h"
#include  "CODb.h"

//windows
#include  "AddEditResult.h"

//list item comparer
#include  "list_comparer.h"


using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

using namespace CONetDbTools;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for AddEditConn
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CAddEditConn : public System::Windows::Forms::Form
	{
	public: 
		CAddEditConn(CSystem  *pcSystem)
		{
			pc_system  =  pcSystem;

			pc_fdb_root  =  NULL;
			i_net_index  =  -1;
			i_conn_index  =  -1;
			b_activated  =  false;

			i_selected_result_index  =  -1;
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}




































	private: System::Windows::Forms::GroupBox *  groupBox6;
	private: System::Windows::Forms::GroupBox *  groupBox7;
	private: System::Windows::Forms::GroupBox *  groupBox3;
	public: System::Windows::Forms::TextBox *  text_chosen_file;
	public: System::Windows::Forms::TextBox *  textConnDir;
	private: System::Windows::Forms::Label *  label3;
	private: System::Windows::Forms::Button *  but_find_dir;
	public: System::Windows::Forms::TextBox *  textConnName;
	private: System::Windows::Forms::Label *  label10;
	private: System::Windows::Forms::GroupBox *  groupBox2;
	public: System::Windows::Forms::TextBox *  textNetName;
	private: System::Windows::Forms::Label *  label1;
	public: System::Windows::Forms::TextBox *  textNetDir;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::GroupBox *  groupBox1;
	public: System::Windows::Forms::TextBox *  textFDbName;
	private: System::Windows::Forms::Label *  label6;
	public: System::Windows::Forms::TextBox *  textFDbDir;
	private: System::Windows::Forms::Label *  label4;
	private: System::Windows::Forms::GroupBox *  groupBox5;
	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::Button *  butOk;
	private: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::GroupBox *  groupBox8;
	private: System::Windows::Forms::GroupBox *  groupBox9;
	private: System::Windows::Forms::ListView *  list_results;
	private: System::Windows::Forms::ColumnHeader *  columnHeader8;
	private: System::Windows::Forms::ColumnHeader *  columnHeader16;
	private: System::Windows::Forms::ColumnHeader *  columnHeader17;

	private: System::Windows::Forms::ColumnHeader *  columnHeader19;
	private: System::Windows::Forms::ColumnHeader *  columnHeader20;
	private: System::Windows::Forms::Button *  but_rem_result;
	private: System::Windows::Forms::Button *  but_edit_result;
	private: System::Windows::Forms::Button *  but_add_result;
	private: System::Windows::Forms::ColumnHeader *  columnHeader1;



	private: System::Windows::Forms::OpenFileDialog *  openFileDialog1;

	public:  void  vSetFDbRootAndNetIndex(CCOFDbRoot  *pcFDbRoot, int iNetIndex)  {pc_fdb_root = pcFDbRoot;i_net_index = iNetIndex;};
	public:  void  vSetConnIndex(int iConnIndex)  {i_conn_index = iConnIndex;};

	private:

		CSystem  *pc_system;
		bool  b_activated;
		CCOFDbRoot  *pc_fdb_root;
		int  i_net_index;
		int  i_conn_index;

		int  i_selected_result_index;

		void  v_refresh_results();
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->openFileDialog1 = new System::Windows::Forms::OpenFileDialog();
			this->groupBox6 = new System::Windows::Forms::GroupBox();
			this->groupBox3 = new System::Windows::Forms::GroupBox();
			this->text_chosen_file = new System::Windows::Forms::TextBox();
			this->textConnDir = new System::Windows::Forms::TextBox();
			this->label3 = new System::Windows::Forms::Label();
			this->but_find_dir = new System::Windows::Forms::Button();
			this->textConnName = new System::Windows::Forms::TextBox();
			this->label10 = new System::Windows::Forms::Label();
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->textNetName = new System::Windows::Forms::TextBox();
			this->label1 = new System::Windows::Forms::Label();
			this->textNetDir = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->textFDbName = new System::Windows::Forms::TextBox();
			this->label6 = new System::Windows::Forms::Label();
			this->textFDbDir = new System::Windows::Forms::TextBox();
			this->label4 = new System::Windows::Forms::Label();
			this->groupBox7 = new System::Windows::Forms::GroupBox();
			this->groupBox4 = new System::Windows::Forms::GroupBox();
			this->groupBox9 = new System::Windows::Forms::GroupBox();
			this->list_results = new System::Windows::Forms::ListView();
			this->columnHeader8 = new System::Windows::Forms::ColumnHeader();
			this->columnHeader16 = new System::Windows::Forms::ColumnHeader();
			this->columnHeader17 = new System::Windows::Forms::ColumnHeader();
			this->columnHeader19 = new System::Windows::Forms::ColumnHeader();
			this->columnHeader20 = new System::Windows::Forms::ColumnHeader();
			this->groupBox8 = new System::Windows::Forms::GroupBox();
			this->but_rem_result = new System::Windows::Forms::Button();
			this->but_edit_result = new System::Windows::Forms::Button();
			this->but_add_result = new System::Windows::Forms::Button();
			this->groupBox5 = new System::Windows::Forms::GroupBox();
			this->butCancel = new System::Windows::Forms::Button();
			this->butOk = new System::Windows::Forms::Button();
			this->columnHeader1 = new System::Windows::Forms::ColumnHeader();
			this->groupBox6->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox7->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox9->SuspendLayout();
			this->groupBox8->SuspendLayout();
			this->groupBox5->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox6
			// 
			this->groupBox6->Controls->Add(this->groupBox3);
			this->groupBox6->Controls->Add(this->groupBox2);
			this->groupBox6->Controls->Add(this->groupBox1);
			this->groupBox6->Dock = System::Windows::Forms::DockStyle::Left;
			this->groupBox6->Location = System::Drawing::Point(0, 0);
			this->groupBox6->Name = S"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(408, 445);
			this->groupBox6->TabIndex = 39;
			this->groupBox6->TabStop = false;
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->text_chosen_file);
			this->groupBox3->Controls->Add(this->textConnDir);
			this->groupBox3->Controls->Add(this->label3);
			this->groupBox3->Controls->Add(this->but_find_dir);
			this->groupBox3->Controls->Add(this->textConnName);
			this->groupBox3->Controls->Add(this->label10);
			this->groupBox3->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox3->Location = System::Drawing::Point(3, 288);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(402, 154);
			this->groupBox3->TabIndex = 38;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = S"Connections config info";
			// 
			// text_chosen_file
			// 
			this->text_chosen_file->Location = System::Drawing::Point(16, 120);
			this->text_chosen_file->Name = S"text_chosen_file";
			this->text_chosen_file->ReadOnly = true;
			this->text_chosen_file->Size = System::Drawing::Size(264, 20);
			this->text_chosen_file->TabIndex = 42;
			this->text_chosen_file->Text = S"";
			// 
			// textConnDir
			// 
			this->textConnDir->Location = System::Drawing::Point(40, 88);
			this->textConnDir->Name = S"textConnDir";
			this->textConnDir->ReadOnly = true;
			this->textConnDir->Size = System::Drawing::Size(304, 20);
			this->textConnDir->TabIndex = 35;
			this->textConnDir->Text = S"";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(24, 72);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(90, 16);
			this->label3->TabIndex = 34;
			this->label3->Text = S"Configuration dir:";
			// 
			// but_find_dir
			// 
			this->but_find_dir->Location = System::Drawing::Point(280, 120);
			this->but_find_dir->Name = S"but_find_dir";
			this->but_find_dir->TabIndex = 28;
			this->but_find_dir->Text = S"Open file";
			this->but_find_dir->Click += new System::EventHandler(this, &CAddEditConn::but_find_dir_Click);
			// 
			// textConnName
			// 
			this->textConnName->Location = System::Drawing::Point(40, 42);
			this->textConnName->Name = S"textConnName";
			this->textConnName->Size = System::Drawing::Size(304, 20);
			this->textConnName->TabIndex = 25;
			this->textConnName->Text = S"";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(24, 26);
			this->label10->Name = S"label10";
			this->label10->Size = System::Drawing::Size(106, 16);
			this->label10->TabIndex = 24;
			this->label10->Text = S"Configuration name:";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->textNetName);
			this->groupBox2->Controls->Add(this->label1);
			this->groupBox2->Controls->Add(this->textNetDir);
			this->groupBox2->Controls->Add(this->label2);
			this->groupBox2->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox2->Location = System::Drawing::Point(3, 168);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(402, 120);
			this->groupBox2->TabIndex = 37;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Net info";
			// 
			// textNetName
			// 
			this->textNetName->Location = System::Drawing::Point(40, 40);
			this->textNetName->Name = S"textNetName";
			this->textNetName->ReadOnly = true;
			this->textNetName->Size = System::Drawing::Size(304, 20);
			this->textNetName->TabIndex = 37;
			this->textNetName->Text = S"";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(16, 24);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(56, 16);
			this->label1->TabIndex = 36;
			this->label1->Text = S"Net name:";
			// 
			// textNetDir
			// 
			this->textNetDir->Location = System::Drawing::Point(40, 88);
			this->textNetDir->Name = S"textNetDir";
			this->textNetDir->ReadOnly = true;
			this->textNetDir->Size = System::Drawing::Size(304, 20);
			this->textNetDir->TabIndex = 35;
			this->textNetDir->Text = S"";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(16, 72);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(41, 16);
			this->label2->TabIndex = 34;
			this->label2->Text = S"Net dir:";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->textFDbName);
			this->groupBox1->Controls->Add(this->label6);
			this->groupBox1->Controls->Add(this->textFDbDir);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox1->Location = System::Drawing::Point(3, 16);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(402, 152);
			this->groupBox1->TabIndex = 36;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"FDb info";
			// 
			// textFDbName
			// 
			this->textFDbName->Location = System::Drawing::Point(40, 40);
			this->textFDbName->Name = S"textFDbName";
			this->textFDbName->ReadOnly = true;
			this->textFDbName->Size = System::Drawing::Size(304, 20);
			this->textFDbName->TabIndex = 37;
			this->textFDbName->Text = S"";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(16, 24);
			this->label6->Name = S"label6";
			this->label6->Size = System::Drawing::Size(60, 16);
			this->label6->TabIndex = 36;
			this->label6->Text = S"FDb name:";
			// 
			// textFDbDir
			// 
			this->textFDbDir->Location = System::Drawing::Point(40, 88);
			this->textFDbDir->Multiline = true;
			this->textFDbDir->Name = S"textFDbDir";
			this->textFDbDir->ReadOnly = true;
			this->textFDbDir->Size = System::Drawing::Size(304, 48);
			this->textFDbDir->TabIndex = 35;
			this->textFDbDir->Text = S"";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(16, 72);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(67, 16);
			this->label4->TabIndex = 34;
			this->label4->Text = S"FDb root dir:";
			// 
			// groupBox7
			// 
			this->groupBox7->Controls->Add(this->groupBox4);
			this->groupBox7->Controls->Add(this->groupBox5);
			this->groupBox7->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox7->Location = System::Drawing::Point(408, 0);
			this->groupBox7->Name = S"groupBox7";
			this->groupBox7->Size = System::Drawing::Size(328, 445);
			this->groupBox7->TabIndex = 40;
			this->groupBox7->TabStop = false;
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->groupBox9);
			this->groupBox4->Controls->Add(this->groupBox8);
			this->groupBox4->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox4->Location = System::Drawing::Point(3, 16);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(322, 370);
			this->groupBox4->TabIndex = 39;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = S"Results";
			// 
			// groupBox9
			// 
			this->groupBox9->Controls->Add(this->list_results);
			this->groupBox9->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox9->Location = System::Drawing::Point(96, 16);
			this->groupBox9->Name = S"groupBox9";
			this->groupBox9->Size = System::Drawing::Size(223, 351);
			this->groupBox9->TabIndex = 1;
			this->groupBox9->TabStop = false;
			// 
			// list_results
			// 
			this->list_results->AllowColumnReorder = true;
			System::Windows::Forms::ColumnHeader* __mcTemp__1[] = new System::Windows::Forms::ColumnHeader*[6];
			__mcTemp__1[0] = this->columnHeader8;
			__mcTemp__1[1] = this->columnHeader16;
			__mcTemp__1[2] = this->columnHeader17;
			__mcTemp__1[3] = this->columnHeader19;
			__mcTemp__1[4] = this->columnHeader20;
			__mcTemp__1[5] = this->columnHeader1;
			this->list_results->Columns->AddRange(__mcTemp__1);
			this->list_results->Dock = System::Windows::Forms::DockStyle::Fill;
			this->list_results->ForeColor = System::Drawing::SystemColors::WindowText;
			this->list_results->FullRowSelect = true;
			this->list_results->GridLines = true;
			this->list_results->Location = System::Drawing::Point(3, 16);
			this->list_results->Name = S"list_results";
			this->list_results->Size = System::Drawing::Size(217, 332);
			this->list_results->TabIndex = 5;
			this->list_results->View = System::Windows::Forms::View::Details;
			this->list_results->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CAddEditConn::list_results_MouseDown);
			this->list_results->DoubleClick += new System::EventHandler(this, &CAddEditConn::list_results_DoubleClick);
			this->list_results->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CAddEditConn::list_results_ColumnClick);
			// 
			// columnHeader8
			// 
			this->columnHeader8->Text = S"Fitt. value";
			this->columnHeader8->Width = 80;
			// 
			// columnHeader16
			// 
			this->columnHeader16->Text = S"Fitt. func.";
			this->columnHeader16->Width = 80;
			// 
			// columnHeader17
			// 
			this->columnHeader17->Text = S"Algorithm";
			this->columnHeader17->Width = 80;
			// 
			// columnHeader19
			// 
			this->columnHeader19->Text = S"Time";
			// 
			// columnHeader20
			// 
			this->columnHeader20->Text = S"Computer";
			this->columnHeader20->Width = 80;
			// 
			// groupBox8
			// 
			this->groupBox8->Controls->Add(this->but_rem_result);
			this->groupBox8->Controls->Add(this->but_edit_result);
			this->groupBox8->Controls->Add(this->but_add_result);
			this->groupBox8->Dock = System::Windows::Forms::DockStyle::Left;
			this->groupBox8->Location = System::Drawing::Point(3, 16);
			this->groupBox8->Name = S"groupBox8";
			this->groupBox8->Size = System::Drawing::Size(93, 351);
			this->groupBox8->TabIndex = 0;
			this->groupBox8->TabStop = false;
			// 
			// but_rem_result
			// 
			this->but_rem_result->Location = System::Drawing::Point(8, 88);
			this->but_rem_result->Name = S"but_rem_result";
			this->but_rem_result->TabIndex = 8;
			this->but_rem_result->Text = S"Remove";
			this->but_rem_result->Click += new System::EventHandler(this, &CAddEditConn::but_rem_result_Click);
			// 
			// but_edit_result
			// 
			this->but_edit_result->Location = System::Drawing::Point(8, 56);
			this->but_edit_result->Name = S"but_edit_result";
			this->but_edit_result->TabIndex = 7;
			this->but_edit_result->Text = S"Edit";
			this->but_edit_result->Click += new System::EventHandler(this, &CAddEditConn::but_edit_result_Click);
			// 
			// but_add_result
			// 
			this->but_add_result->Location = System::Drawing::Point(8, 24);
			this->but_add_result->Name = S"but_add_result";
			this->but_add_result->TabIndex = 6;
			this->but_add_result->Text = S"Add";
			this->but_add_result->Click += new System::EventHandler(this, &CAddEditConn::but_add_result_Click);
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->butCancel);
			this->groupBox5->Controls->Add(this->butOk);
			this->groupBox5->Dock = System::Windows::Forms::DockStyle::Bottom;
			this->groupBox5->Location = System::Drawing::Point(3, 386);
			this->groupBox5->Name = S"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(322, 56);
			this->groupBox5->TabIndex = 38;
			this->groupBox5->TabStop = false;
			// 
			// butCancel
			// 
			this->butCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->butCancel->Location = System::Drawing::Point(184, 24);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 29;
			this->butCancel->Text = S"Cancel";
			// 
			// butOk
			// 
			this->butOk->Location = System::Drawing::Point(96, 24);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 28;
			this->butOk->Text = S"OK";
			this->butOk->Click += new System::EventHandler(this, &CAddEditConn::butOk_Click);
			// 
			// columnHeader1
			// 
			this->columnHeader1->Text = S"Date";
			this->columnHeader1->Width = 120;
			// 
			// CAddEditConn
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(736, 445);
			this->Controls->Add(this->groupBox7);
			this->Controls->Add(this->groupBox6);
			this->Name = S"CAddEditConn";
			this->Text = S"AddEditConn";
			this->WindowState = System::Windows::Forms::FormWindowState::Maximized;
			this->Activated += new System::EventHandler(this, &CAddEditConn::CAddEditConn_Activated);
			this->groupBox6->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			this->groupBox1->ResumeLayout(false);
			this->groupBox7->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox9->ResumeLayout(false);
			this->groupBox8->ResumeLayout(false);
			this->groupBox5->ResumeLayout(false);
			this->ResumeLayout(false);

		}		
	private: System::Void but_find_dir_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void CAddEditConn_Activated(System::Object *  sender, System::EventArgs *  e);
private: System::Void butOk_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void but_add_result_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_edit_result_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_rem_result_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void list_results_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_results_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_results_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

};
};