#pragma once


__gc class list_item_comparer : public IComparer 
{
public:
	list_item_comparer()  {i_col=0;b_incr=true;};
	list_item_comparer(int iColumn) {i_col=iColumn;b_incr=true;};
	list_item_comparer(int iColumn, bool bIncr) {i_col=iColumn;b_incr=bIncr;};

	int  iGetColumn()  {return(i_col);};
	bool  bGetDirection()  {return(b_incr);};
	int Compare(Object* pcO1, Object* pcO2)
	{
		if  (b_incr)
			return String::Compare
				(
				(dynamic_cast<ListViewItem*>(pcO1))->SubItems->Item[i_col]->Text,
				(dynamic_cast<ListViewItem*>(pcO2))->SubItems->Item[i_col]->Text
				);
		else
			return String::Compare
				(
				(dynamic_cast<ListViewItem*>(pcO2))->SubItems->Item[i_col]->Text,
				(dynamic_cast<ListViewItem*>(pcO1))->SubItems->Item[i_col]->Text
				);
	}//int Compare(Object* pcO1, Object* pcO2)

private:
	int  i_col;
	bool  b_incr;
};//__gc class ListViewItemComparer : public IComparer 