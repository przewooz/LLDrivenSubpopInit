#pragma once

//tools
#include  "atlstr.h"  //CString
#include  "system.h"

//list item comparer
#include  "list_comparer.h"


//windows
#include  "ConnectionOptions.h"
#include  "AddEditFDb.h"
#include  "AddEditNet.h"
#include  "AddEditConn.h"
#include  "AddEditAlgorithm.h"
#include  "AddEditFitFunc.h"
#include  "AddEditComputer.h"
#include  "AddEditResultsSet.h"

#include "massive_add_info.h"




namespace CONetAdmin
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	
	/// <summary> 
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CCONetmainForm : public System::Windows::Forms::Form
	{	
	public:
		CCONetmainForm(void);
		
	protected:
		void Dispose(Boolean disposing)
		{
			for  (int ii = 0;  ii < (int) pv_fdb_roots->size(); ii++)
				delete  pv_fdb_roots->at(ii);
			delete  pv_fdb_roots;

			for  (int ii = 0;  ii < (int) pv_algorithms->size(); ii++)
				delete  pv_algorithms->at(ii);
			delete  pv_algorithms;

			for  (int ii = 0;  ii < (int) pv_fit_funcs->size(); ii++)
				delete  pv_fit_funcs->at(ii);
			delete  pv_fit_funcs;

			for  (int ii = 0;  ii < (int) pv_computers->size(); ii++)
				delete  pv_computers->at(ii);
			delete  pv_computers;

			for  (int ii = 0;  ii < (int) pv_rsets->size(); ii++)
				delete  pv_rsets->at(ii);
			delete  pv_rsets;
			
			

			if  (pc_chosen_fdb  !=  NULL)  delete  pc_chosen_fdb;

			delete  pc_system;

			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}



	private: System::Windows::Forms::TabPage *  tabPage3;
	private: System::Windows::Forms::MainMenu *  menu_main;
	private: System::Windows::Forms::MenuItem *  menu_main_exit;
	private: System::Windows::Forms::MenuItem *  menu_main_connect_opt;
	private: System::Windows::Forms::MenuItem *  menu_main_help;
	private: System::Windows::Forms::StatusBar *  statusMain;
	private: System::Windows::Forms::Button *  but_massive_add_results_old;
	private: System::Windows::Forms::TabPage *  tabpg_results_sets;
	private: System::Windows::Forms::GroupBox *  groupBox13;
	private: System::Windows::Forms::TabControl *  tabControl5;
	private: System::Windows::Forms::TabPage *  tabPage11;

	private: System::Windows::Forms::TabPage *  tabPage12;
	private: System::Windows::Forms::ColumnHeader *  columnHeader21;
	private: System::Windows::Forms::ColumnHeader *  columnHeader22;
	private: System::Windows::Forms::GroupBox *  groupBox14;

	private: System::Windows::Forms::Label *  label21;
	private: System::Windows::Forms::Label *  label22;

	private: System::Windows::Forms::ListView *  list_results_sets;
	private: System::Windows::Forms::Button *  butRemRSet;
	private: System::Windows::Forms::Button *  butAddRSet;
	private: System::Windows::Forms::Button *  butEditRSet;
	private: System::Windows::Forms::TextBox *  textRSetName;
	private: System::Windows::Forms::TextBox *  textRSetComm;
	private: System::Windows::Forms::TabPage *  tabPgResults;


	private: System::Windows::Forms::Button *  but_massive_add_results_walk;
	private: System::Windows::Forms::Button *  but_massive_add_results;


	private: System::Windows::Forms::TabPage *  tabPage13;


	private: System::Windows::Forms::TabControl *  tabControlStats;
	private: System::Windows::Forms::TabPage *  tabpg_stats_general;
	private: System::Windows::Forms::Button *  but_results_test;

	private: System::Windows::Forms::GroupBox *  groupBox15;








	private: System::Windows::Forms::GroupBox *  groupBox17;
	private: System::Windows::Forms::GroupBox *  groupBox16;
	private: System::Windows::Forms::TabControl *  tabControl6;
	private: System::Windows::Forms::TabPage *  tabPage2;
	private: System::Windows::Forms::ListView *  list_choose_nets;
	private: System::Windows::Forms::TabPage *  tabPage14;
	private: System::Windows::Forms::ColumnHeader *  columnHeader23;
	private: System::Windows::Forms::ColumnHeader *  columnHeader24;
	private: System::Windows::Forms::ColumnHeader *  columnHeader25;
	private: System::Windows::Forms::ColumnHeader *  columnHeader26;
private: System::Windows::Forms::Button *  but_choose_nets_select_all;
private: System::Windows::Forms::Button *  but_choose_nets_deselect_all;
private: System::Windows::Forms::Button *  but_choose_nets_invert;
private: System::Windows::Forms::TabControl *  tabControl7;
private: System::Windows::Forms::TabPage *  tabPage15;
private: System::Windows::Forms::TabPage *  tabPage16;
private: System::Windows::Forms::GroupBox *  groupBox18;



private: System::Windows::Forms::ListView *  list_choose_set;
private: System::Windows::Forms::ColumnHeader *  columnHeader27;
private: System::Windows::Forms::ColumnHeader *  columnHeader28;
private: System::Windows::Forms::Button *  but_choose_set_invert;
private: System::Windows::Forms::Button *  but_choose_set_deselect_all;
private: System::Windows::Forms::Button *  but_choose_set_select_all;
private: System::Windows::Forms::Button *  but_report_general;
private: System::Windows::Forms::ComboBox *  combo_normalize;
private: System::Windows::Forms::CheckBox *  chk_report_max;
private: System::Windows::Forms::ColumnHeader *  columnHeader29;
private: System::Windows::Forms::SaveFileDialog *  saveFileDialog1;
private: System::Windows::Forms::Button*  but_compare_set;
private: System::Windows::Forms::FolderBrowserDialog*  folderBrowserDialog1;
private: System::Windows::Forms::ComboBox*  combo_ext;
private: System::Windows::Forms::Button*  but_choose_nets_select_a;
private: System::Windows::Forms::Button*  but_choose_nets_select_c;
private: System::Windows::Forms::Button*  but_choose_nets_select_b;














	private:

		//system tools
		CSystem  *pc_system;

		//massive connections adding
		void  v_add_conn_by_name(CString  sConnPath);
		void  v_add_result_old(CString  sSettingsFile, int iCompId, int iRSetId);
		void  v_add_result(CString  sSettingsFile, int iCompId, int iRSetId);
		void  v_add_result_walk(CString  sSolutionFile,  int  iCompId, int  iRSetId, int  iAlgId, int iFitFunc);
		void  v_create_results_set_for_tuning_lfl(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);

		void  v_create_results_set_for_tuning_vmea(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		void  v_create_results_set_for_tuning_vmea_mut_tuning(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		void  v_create_results_set_for_tuning_vmea_cut_splice_tuning(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		void  v_create_results_set_for_tuning_vmea_final(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		void  v_create_results_set_for_tuning_vmea_init_mut_tuning(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		void  v_create_chosen_result_for_vmea(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		

		void  v_create_results_set_for_tuning_standard_ea(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		void  v_create_chosen_results_set_for_tuning_lfl(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		void  v_create_chosen_result_for_hefan_2_1_1_root(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		void  v_create_chosen_result_for_hefan_2_0(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		void  v_create_chosen_result_for_hefan_1_0(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
		void  v_create_chosen_result_for_standard_ea(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs);
				
	private: System::Windows::Forms::GroupBox *  groupFDbControls;
	private: System::Windows::Forms::Button *  butRemoveFDb;
	private: System::Windows::Forms::Button *  butAddFDb;
	private: System::Windows::Forms::Button *  butEditFDb;


	private: System::Windows::Forms::TextBox *  textFDbDir;
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::TextBox *  textFDbName;
	private: System::Windows::Forms::GroupBox *  groupFDbListAndFilters;











	private: System::Windows::Forms::TabPage *  tabpg_netowrks;
	private: System::Windows::Forms::GroupBox *  groupBox1;








	private: System::Windows::Forms::GroupBox *  groupBox6;











	private: System::Windows::Forms::Button *  butRemoveNet;
	private: System::Windows::Forms::Button *  butAddNet;
	private: System::Windows::Forms::Button *  butEditNet;































private: System::Windows::Forms::GroupBox *  groupChosenFDb;
private: System::Windows::Forms::TextBox *  textChosenFDbName;
private: System::Windows::Forms::Button *  butFDbDeselect;
private: System::Windows::Forms::GroupBox *  groupFDbList;


private: System::Windows::Forms::ColumnHeader *  col_root_name;
private: System::Windows::Forms::ColumnHeader *  col_root_dir;



	bool  b_activated;//set to false in constructor, is used for only one window init in onActivate
private: System::Windows::Forms::TabControl *  tabControl_main;
private: System::Windows::Forms::TabControl *  tabControl_admin;
private: System::Windows::Forms::GroupBox *  groupBox2;
private: System::Windows::Forms::CheckBox *  check_filter_by_fdb_root;
private: System::Windows::Forms::TextBox *  textChosenFDbNameForNets;
private: System::Windows::Forms::Button *  butFDbDeselectNets;
private: System::Windows::Forms::TabControl *  tabControl_net_list_tree;
private: System::Windows::Forms::TabPage *  tabPage_net_list;
private: System::Windows::Forms::TabPage *  tabPage_net_tree;
private: System::Windows::Forms::ListView *  list_nets;
private: System::Windows::Forms::ColumnHeader *  columnHeader1;
private: System::Windows::Forms::ColumnHeader *  columnHeader2;
private: System::Windows::Forms::ColumnHeader *  columnHeader3;
private: System::Windows::Forms::ColumnHeader *  columnHeader4;

private: System::Windows::Forms::Label *  label7;
public: System::Windows::Forms::TextBox *  textNetNodesNum;
private: System::Windows::Forms::Label *  label5;
public: System::Windows::Forms::TextBox *  textNetDir;
private: System::Windows::Forms::Label *  label3;
private: System::Windows::Forms::Label *  label4;
public: System::Windows::Forms::TextBox *  textNetName;
private: System::Windows::Forms::Label *  label6;
public: System::Windows::Forms::TextBox *  textAddedBy;
private: System::Windows::Forms::Label *  label8;
public: System::Windows::Forms::TextBox *  textNetComments;
public: System::Windows::Forms::TextBox *  textNetLinksNum;
private: System::Windows::Forms::CheckBox *  check_config;
private: System::Windows::Forms::TabPage *  tabpg_algorithms;

private: System::Windows::Forms::GroupBox *  groupBox4;
private: System::Windows::Forms::GroupBox *  groupBox3;




private: System::Windows::Forms::TabControl *  tabControl1;
private: System::Windows::Forms::TabPage *  tabPage1;

private: System::Windows::Forms::TabPage *  tabPage4;




private: System::Windows::Forms::GroupBox *  groupBox10;
private: System::Windows::Forms::GroupBox *  groupBox7;
private: System::Windows::Forms::TabControl *  tabControl2;
private: System::Windows::Forms::TabPage *  tabPage5;

private: System::Windows::Forms::TabPage *  tabPage6;




private: System::Windows::Forms::ColumnHeader *  columnHeader9;







private: System::Windows::Forms::TabPage *  tabpg_results;
private: System::Windows::Forms::TabPage *  tabpg_fitt_funcs;

private: System::Windows::Forms::Label *  label9;
private: System::Windows::Forms::Label *  label10;




private: System::Windows::Forms::TextBox *  textAlgName;
private: System::Windows::Forms::TextBox *  textAlgComments;
private: System::Windows::Forms::ListView *  list_algorithms;
private: System::Windows::Forms::ColumnHeader *  columnHeader13;
private: System::Windows::Forms::ColumnHeader *  columnHeader14;
private: System::Windows::Forms::ColumnHeader *  columnHeader15;

private: System::Windows::Forms::Button *  but_rem_alg;
private: System::Windows::Forms::Button *  but_add_alg;
private: System::Windows::Forms::Button *  but_edit_alg;
private: System::Windows::Forms::ColumnHeader *  columnHeader5;
private: System::Windows::Forms::TextBox *  textFFuncName;
private: System::Windows::Forms::Label *  label11;
private: System::Windows::Forms::Label *  label12;
private: System::Windows::Forms::TextBox *  textFFuncComm;



private: System::Windows::Forms::ListView *  list_ff;
private: System::Windows::Forms::Button *  butRemoveFF;
private: System::Windows::Forms::Button *  butAddFF;
private: System::Windows::Forms::Button *  butEditFF;
private: System::Windows::Forms::TabPage *  tabpg_computers;
private: System::Windows::Forms::GroupBox *  groupBox5;
private: System::Windows::Forms::TabControl *  tabControl3;
private: System::Windows::Forms::TabPage *  tabPage7;

private: System::Windows::Forms::TabPage *  tabPage8;
private: System::Windows::Forms::ColumnHeader *  columnHeader6;
private: System::Windows::Forms::ColumnHeader *  columnHeader7;
private: System::Windows::Forms::GroupBox *  groupBox8;

private: System::Windows::Forms::Label *  label13;
private: System::Windows::Forms::Label *  label14;

private: System::Windows::Forms::TextBox *  textCompName;
private: System::Windows::Forms::TextBox *  textCompComm;
private: System::Windows::Forms::Button *  butRemoveComp;
private: System::Windows::Forms::Button *  butAddComp;
private: System::Windows::Forms::Button *  butEditComp;
private: System::Windows::Forms::ListView *  list_computers;
private: System::Windows::Forms::GroupBox *  groupBox9;
private: System::Windows::Forms::TabControl *  tabControl4;
private: System::Windows::Forms::TabPage *  tabPage9;

private: System::Windows::Forms::TabPage *  tabPage10;
private: System::Windows::Forms::GroupBox *  groupBox11;

private: System::Windows::Forms::CheckBox *  checkBox2;


private: System::Windows::Forms::ColumnHeader *  columnHeader8;
private: System::Windows::Forms::ColumnHeader *  columnHeader10;
private: System::Windows::Forms::ColumnHeader *  columnHeader11;
private: System::Windows::Forms::ColumnHeader *  columnHeader12;
private: System::Windows::Forms::GroupBox *  groupBox12;
public: System::Windows::Forms::TextBox *  textBox2;
private: System::Windows::Forms::Label *  label15;
public: System::Windows::Forms::TextBox *  textBox3;
public: System::Windows::Forms::TextBox *  textBox4;
private: System::Windows::Forms::Label *  label16;
public: System::Windows::Forms::TextBox *  textBox5;
private: System::Windows::Forms::Label *  label17;
public: System::Windows::Forms::TextBox *  textBox6;
private: System::Windows::Forms::Label *  label18;
private: System::Windows::Forms::Label *  label19;
public: System::Windows::Forms::TextBox *  textBox7;
private: System::Windows::Forms::Label *  label20;
private: System::Windows::Forms::Button *  button2;
private: System::Windows::Forms::Button *  button3;
private: System::Windows::Forms::Button *  button4;
private: System::Windows::Forms::TextBox *  textChosenFDbNameForResults;
private: System::Windows::Forms::Button *  butFDbDeselectResults;
private: System::Windows::Forms::ListView *  list_results;
private: System::Windows::Forms::ColumnHeader *  columnHeader16;
private: System::Windows::Forms::ColumnHeader *  columnHeader17;
private: System::Windows::Forms::ColumnHeader *  columnHeader18;
private: System::Windows::Forms::ColumnHeader *  columnHeader19;
private: System::Windows::Forms::ColumnHeader *  columnHeader20;
private: System::Windows::Forms::Button *  but_massive_add_conns;
private: System::Windows::Forms::OpenFileDialog *  openFileDialog1;












private: System::Windows::Forms::ListView *  list_fdb_roots;


	void  v_refresh_roots();
	void  v_refresh_nets();
	void  v_refresh_nets_only();
	void  v_refresh_nets_with_conns();
	void  v_refresh_results();
	void  v_refresh_algs();
	void  v_refresh_fit_funcs();
	void  v_refresh_computers();
	void  v_refresh_rsets();

	void  v_refresh_choose();
	void  v_refresh_choose_nets();
	void  v_refresh_choose_sets();

	

	private: System::Windows::Forms::TabPage *  tabpgAdmin;






	private: System::Windows::Forms::TabPage *  tabpg_db_roots;
private: System::ComponentModel::IContainer*  components;



		/// <summary>
		/// Required designer variable.
		/// </summary>


		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void);

		//windows
		CConnOpt  *pcConnOpt;

		vector  <CCOFDbRoot  *>  *pv_fdb_roots;
		vector  <CCOAlgorithm  *>  *pv_algorithms;
		vector  <CCOFitFunc  *>  *pv_fit_funcs;
		vector  <CCOComputer  *>  *pv_computers;
		vector  <CCOResultSet  *>  *pv_rsets;
		int  i_selected_fdb_index;//last clicked fdb item
		int  i_selected_net_index;//last clicked net item
		int  i_selected_net_conn_index;//last clicked net conn item (if enabled)
		int  i_selected_alg_index;//last clicked alg item
		int  i_selected_ff_index;//last clicked ff item
		int  i_selected_comp_index;//last clicked ff item
		int  i_selected_rset_index;//last clicked ff item

		int  i_selected_choose_net_index;////last clicked choose net item
		int  i_selected_choose_set_index;
		CCOFDbRoot  *pc_chosen_fdb;//chosen fdb item


		System::Void menu_main_exit_Click(System::Object *  sender, System::EventArgs *  e);
		System::Void menu_main_connect_opt_Click(System::Object *  sender, System::EventArgs *  e);
		System::Void cCONetmainForm_Closing(System::Object *  sender, System::ComponentModel::CancelEventArgs *  e);
		System::Void cCONetmainForm_Activated(System::Object *  sender, System::EventArgs *  e);
		
	
		//fdb functions
		System::Void list_fdb_roots_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);
		System::Void list_fdb_roots_MouseUp(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);
		System::Void list_fdb_roots_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
		System::Void list_fdb_roots_DoubleClick(System::Object *  sender, System::EventArgs *  e);
				
		System::Void butEditFDb_Click(System::Object *  sender, System::EventArgs *  e);
		System::Void butRemoveFDb_Click(System::Object *  sender, System::EventArgs *  e);
		System::Void butAddFDb_Click(System::Object *  sender, System::EventArgs *  e);

		System::Void butFDbDeselect_Click(System::Object *  sender, System::EventArgs *  e);
		

		//net functions
		System::Void butAddNet_Click(System::Object *  sender, System::EventArgs *  e);
 
	
private: System::Void tabControl_main_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
		 {
			 tabControl_main_refresh_proper_tab();
		 }

private: System::Void tabControl_main_VisibleChanged(System::Object *  sender, System::EventArgs *  e)
		 {
			 tabControl_main_refresh_proper_tab();
		 }


private:  void  tabControl_main_refresh_proper_tab()
		  {
		  
		  }//void  tabControl_main_refresh_proper_tab()



private: System::Void tabControl_admin_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
		 {
			 tabControl_admin_refresh_proper_tab();
		 }

private: System::Void tabControl_admin_VisibleChanged(System::Object *  sender, System::EventArgs *  e)
		 {
			 tabControl_admin_refresh_proper_tab();
		 }

private:  void  tabControl_admin_refresh_proper_tab()
		  {
			  if  (tabControl_admin->SelectedTab  ==  tabpg_db_roots)  v_refresh_roots();
			  if  (tabControl_admin->SelectedTab  ==  tabpg_netowrks)  v_refresh_nets();
			  if  (tabControl_admin->SelectedTab  ==  tabpg_results)  v_refresh_results();
			  if  (tabControl_admin->SelectedTab  ==  tabpg_algorithms)  v_refresh_algs();
			  if  (tabControl_admin->SelectedTab  ==  tabpg_fitt_funcs)  v_refresh_fit_funcs();
			  if  (tabControl_admin->SelectedTab  ==  tabpg_computers)  v_refresh_computers();
			  if  (tabControl_admin->SelectedTab  ==  tabpg_results_sets)  v_refresh_rsets();
			  			 
		  }//void  tabControl_admin_refresh_propoer_tab()


private: void but_edit_net_only_Click(System::Object *  sender, System::EventArgs *  e);
private: void but_edit_net_with_conns_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void butEditNet_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void list_nets_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_nets_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_nets_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

private: System::Void butFDbDeselectNets_Click(System::Object *  sender, System::EventArgs *  e)
		 {
			 butFDbDeselect_Click(sender, e);
		 }


private: System::Void butRemoveNet_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void check_config_CheckedChanged(System::Object *  sender, System::EventArgs *  e);


private: System::Void but_edit_alg_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_add_alg_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_rem_alg_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void list_algorithms_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_algorithms_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_algorithms_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

private: System::Void butEditFF_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void butAddFF_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void butRemoveFF_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void list_ff_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_ff_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_ff_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

private: System::Void butEditComp_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void butAddComp_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void butRemoveComp_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void list_computers_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_computers_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_computers_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);




private: System::Void but_massive_add_conns_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_massive_add_results_old_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void butEditRSet_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void butAddRSet_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void butRemRSet_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void list_results_sets_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_results_sets_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_results_sets_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

private: System::Void but_results_test_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void but_massive_add_results_walk_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_massive_add_results_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void textBox11_TextChanged(System::Object *  sender, System::EventArgs *  e)
		 {
		 }

private: System::Void label25_Click(System::Object *  sender, System::EventArgs *  e)
		 {
		 }

private: System::Void textBox12_TextChanged(System::Object *  sender, System::EventArgs *  e)
		 {
		 }

private: System::Void label26_Click(System::Object *  sender, System::EventArgs *  e)
		 {
		 }

private: System::Void textBox13_TextChanged(System::Object *  sender, System::EventArgs *  e)
		 {
		 }

private: System::Void label28_Click(System::Object *  sender, System::EventArgs *  e)
		 {
		 }

private: System::Void textBox10_TextChanged(System::Object *  sender, System::EventArgs *  e)
		 {
		 }

private: System::Void label24_Click(System::Object *  sender, System::EventArgs *  e)
		 {
		 }


private:  void  tabControlStats_refresh_proper_tab()
		  {
			  if  (tabControlStats->SelectedTab  ==  tabpg_stats_general)  v_refresh_choose();
		  }//void  tabControlStats_refresh_proper_tab()


private: System::Void tabControlStats_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
		 {
			 tabControlStats_refresh_proper_tab();
		 }

private: System::Void tabControlStats_VisibleChanged(System::Object *  sender, System::EventArgs *  e)
		 {
			 tabControlStats_refresh_proper_tab();
		 }

private: System::Void list_choose_nets_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_choose_nets_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_choose_nets_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

private: void  list_change_state(System::Windows::Forms::ListViewItem  *pcItem);
private: void  list_selected_state(System::Windows::Forms::ListViewItem  *pcItem);
private: void  list_unselected_state(System::Windows::Forms::ListViewItem  *pcItem);
private: System::Void but_choose_nets_select_all_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_choose_nets_deselect_all_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_choose_nets_invert_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void but_choose_set_select_all_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_choose_set_deselect_all_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_choose_set_invert_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void list_choose_set_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_choose_set_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_choose_set_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

private: System::Void but_report_general_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void but_compare_set_Click(System::Object*  sender, System::EventArgs*  e);
private: System::Void but_choose_nets_select_a_Click(System::Object*  sender, System::EventArgs*  e);
private: System::Void but_choose_nets_select_b_Click(System::Object*  sender, System::EventArgs*  e);
private: System::Void but_choose_nets_select_c_Click(System::Object*  sender, System::EventArgs*  e);
};//public __gc class CONetmainForm : public System::Windows::Forms::Form


};//namespace CONetAdmin


