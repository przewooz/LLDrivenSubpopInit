#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for AddEditFDb
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CAddEditFDb : public System::Windows::Forms::Form
	{
	public: 
		CAddEditFDb(void)
		{
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	public: System::Windows::Forms::TextBox *  textFDbName;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::Label *  label1;
	public: System::Windows::Forms::TextBox *  textFDbDir;

	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::Button *  butOk;
	private: System::Windows::Forms::Button *  but_find_dir;
	private: System::Windows::Forms::FolderBrowserDialog *  folderBrowserDialog1;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->textFDbName = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->label1 = new System::Windows::Forms::Label();
			this->textFDbDir = new System::Windows::Forms::TextBox();
			this->butOk = new System::Windows::Forms::Button();
			this->butCancel = new System::Windows::Forms::Button();
			this->but_find_dir = new System::Windows::Forms::Button();
			this->folderBrowserDialog1 = new System::Windows::Forms::FolderBrowserDialog();
			this->SuspendLayout();
			// 
			// textFDbName
			// 
			this->textFDbName->Location = System::Drawing::Point(40, 40);
			this->textFDbName->Name = S"textFDbName";
			this->textFDbName->Size = System::Drawing::Size(304, 20);
			this->textFDbName->TabIndex = 16;
			this->textFDbName->Text = S"";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(16, 16);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(107, 16);
			this->label2->TabIndex = 15;
			this->label2->Text = S"File database name:";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(16, 80);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(92, 16);
			this->label1->TabIndex = 14;
			this->label1->Text = S"File databse root:";
			// 
			// textFDbDir
			// 
			this->textFDbDir->Location = System::Drawing::Point(40, 104);
			this->textFDbDir->Multiline = true;
			this->textFDbDir->Name = S"textFDbDir";
			this->textFDbDir->Size = System::Drawing::Size(304, 56);
			this->textFDbDir->TabIndex = 17;
			this->textFDbDir->Text = S"";
			// 
			// butOk
			// 
			this->butOk->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->butOk->Location = System::Drawing::Point(288, 192);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 18;
			this->butOk->Text = S"OK";
			this->butOk->Click += new System::EventHandler(this, &CAddEditFDb::butOk_Click);
			// 
			// butCancel
			// 
			this->butCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->butCancel->Location = System::Drawing::Point(376, 192);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 19;
			this->butCancel->Text = S"Cancel";
			// 
			// but_find_dir
			// 
			this->but_find_dir->Location = System::Drawing::Point(360, 112);
			this->but_find_dir->Name = S"but_find_dir";
			this->but_find_dir->TabIndex = 20;
			this->but_find_dir->Text = S"Find dir";
			this->but_find_dir->Click += new System::EventHandler(this, &CAddEditFDb::but_find_dir_Click);
			// 
			// CAddEditFDb
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(464, 237);
			this->Controls->Add(this->but_find_dir);
			this->Controls->Add(this->butCancel);
			this->Controls->Add(this->butOk);
			this->Controls->Add(this->textFDbName);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textFDbDir);
			this->Name = S"CAddEditFDb";
			this->Text = S"AddEditFDb";
			this->ResumeLayout(false);

		}		
	 

private: System::Void but_find_dir_Click(System::Object *  sender, System::EventArgs *  e);
		 
private: System::Void butOk_Click(System::Object *  sender, System::EventArgs *  e)
		 {
		 }

};
};//namespace CONetAdmin