#pragma once

#include  "atlstr.h"  //CString
#include  "..\\HEFAN\\TopologyTranslator.h"
#include  "CODb.h"

//windows
#include  "AddEditConn.h"
#include  "info_window.h"

//list item comparer
#include  "list_comparer.h"


using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

using namespace CONetDbTools;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for AddEditNet
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CAddEditNet : public System::Windows::Forms::Form
	{
	public: 
		CAddEditNet(CSystem  *pcSystem)
		{
			pc_system  =  pcSystem;
			pc_fdb_root  =  NULL;
			i_net_index  =  -1;
			b_activated  =  false;
			i_selected_conn_index  =  -1;
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}








	private: System::Windows::Forms::GroupBox *  groupBox1;

	private: System::Windows::Forms::Label *  label4;
	private: System::Windows::Forms::GroupBox *  groupBox2;
	public: System::Windows::Forms::TextBox *  textNetName;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::Label *  label1;

	private: System::Windows::Forms::Button *  but_find_dir;

	private: System::Windows::Forms::Label *  label3;

	private: System::Windows::Forms::Label *  label5;

	private: System::Windows::Forms::Label *  label6;

	private: System::Windows::Forms::Label *  label7;
	private: System::Windows::Forms::Label *  label8;



	private: System::Windows::Forms::OpenFileDialog *  openFileDialog1;
	public: System::Windows::Forms::TextBox *  textFDbName;
	public: System::Windows::Forms::TextBox *  textFDbDir;
	public: System::Windows::Forms::TextBox *  textAddedBy;

	public: System::Windows::Forms::TextBox *  textNetNodesNum;
	public: System::Windows::Forms::TextBox *  textNetDir;
	public: System::Windows::Forms::TextBox *  text_chosen_file;
	public: System::Windows::Forms::TextBox *  textNetLinksNum;
	private: System::Windows::Forms::GroupBox *  groupBox3;
	private: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::Button *  butOk;
	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::GroupBox *  groupBox5;
	private: System::Windows::Forms::GroupBox *  groupBox6;

	private: System::Windows::Forms::Button *  but_add_conn;
	private: System::Windows::Forms::Button *  but_edit_conn;
	private: System::Windows::Forms::Button *  but_rem_conn;
	private: System::Windows::Forms::ListView *  list_conns;
	private: System::Windows::Forms::ColumnHeader *  columnHeader1;
	private: System::Windows::Forms::ColumnHeader *  columnHeader2;
	private: System::Windows::Forms::ColumnHeader *  columnHeader3;
	private: System::Windows::Forms::Button *  but_ok_for_all;


	public: System::Windows::Forms::TextBox *  textNetComments;



	public:  void  vSetFDbRoot(CCOFDbRoot  *pcFDbRoot)  {pc_fdb_root = pcFDbRoot;};
	public:  void  vSetNetIndex(int iNetIndex)  {i_net_index = iNetIndex;};

	private:  void  v_refresh_conns();


	private:

		CSystem  *pc_system;

		CCOFDbRoot  *pc_fdb_root;
		int  i_net_index;
		int  i_selected_conn_index;
		bool  b_activated;
		void  v_add_net(CString  sNetPath);
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->textFDbName = new System::Windows::Forms::TextBox();
			this->label6 = new System::Windows::Forms::Label();
			this->textFDbDir = new System::Windows::Forms::TextBox();
			this->label4 = new System::Windows::Forms::Label();
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->text_chosen_file = new System::Windows::Forms::TextBox();
			this->textAddedBy = new System::Windows::Forms::TextBox();
			this->label8 = new System::Windows::Forms::Label();
			this->textNetLinksNum = new System::Windows::Forms::TextBox();
			this->label7 = new System::Windows::Forms::Label();
			this->textNetNodesNum = new System::Windows::Forms::TextBox();
			this->label5 = new System::Windows::Forms::Label();
			this->textNetDir = new System::Windows::Forms::TextBox();
			this->label3 = new System::Windows::Forms::Label();
			this->but_find_dir = new System::Windows::Forms::Button();
			this->label1 = new System::Windows::Forms::Label();
			this->textNetComments = new System::Windows::Forms::TextBox();
			this->textNetName = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->openFileDialog1 = new System::Windows::Forms::OpenFileDialog();
			this->groupBox3 = new System::Windows::Forms::GroupBox();
			this->butCancel = new System::Windows::Forms::Button();
			this->butOk = new System::Windows::Forms::Button();
			this->groupBox4 = new System::Windows::Forms::GroupBox();
			this->groupBox6 = new System::Windows::Forms::GroupBox();
			this->list_conns = new System::Windows::Forms::ListView();
			this->columnHeader1 = new System::Windows::Forms::ColumnHeader();
			this->columnHeader2 = new System::Windows::Forms::ColumnHeader();
			this->columnHeader3 = new System::Windows::Forms::ColumnHeader();
			this->groupBox5 = new System::Windows::Forms::GroupBox();
			this->but_rem_conn = new System::Windows::Forms::Button();
			this->but_edit_conn = new System::Windows::Forms::Button();
			this->but_add_conn = new System::Windows::Forms::Button();
			this->but_ok_for_all = new System::Windows::Forms::Button();
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox6->SuspendLayout();
			this->groupBox5->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->textFDbName);
			this->groupBox1->Controls->Add(this->label6);
			this->groupBox1->Controls->Add(this->textFDbDir);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox1->Location = System::Drawing::Point(0, 0);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(672, 152);
			this->groupBox1->TabIndex = 32;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"FDb info";
			// 
			// textFDbName
			// 
			this->textFDbName->Location = System::Drawing::Point(40, 40);
			this->textFDbName->Name = S"textFDbName";
			this->textFDbName->ReadOnly = true;
			this->textFDbName->Size = System::Drawing::Size(304, 20);
			this->textFDbName->TabIndex = 37;
			this->textFDbName->Text = S"";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(16, 24);
			this->label6->Name = S"label6";
			this->label6->Size = System::Drawing::Size(60, 16);
			this->label6->TabIndex = 36;
			this->label6->Text = S"FDb name:";
			// 
			// textFDbDir
			// 
			this->textFDbDir->Location = System::Drawing::Point(40, 88);
			this->textFDbDir->Multiline = true;
			this->textFDbDir->Name = S"textFDbDir";
			this->textFDbDir->ReadOnly = true;
			this->textFDbDir->Size = System::Drawing::Size(304, 48);
			this->textFDbDir->TabIndex = 35;
			this->textFDbDir->Text = S"";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(16, 72);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(67, 16);
			this->label4->TabIndex = 34;
			this->label4->Text = S"FDb root dir:";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->text_chosen_file);
			this->groupBox2->Controls->Add(this->textAddedBy);
			this->groupBox2->Controls->Add(this->label8);
			this->groupBox2->Controls->Add(this->textNetLinksNum);
			this->groupBox2->Controls->Add(this->label7);
			this->groupBox2->Controls->Add(this->textNetNodesNum);
			this->groupBox2->Controls->Add(this->label5);
			this->groupBox2->Controls->Add(this->textNetDir);
			this->groupBox2->Controls->Add(this->label3);
			this->groupBox2->Controls->Add(this->but_find_dir);
			this->groupBox2->Controls->Add(this->label1);
			this->groupBox2->Controls->Add(this->textNetComments);
			this->groupBox2->Controls->Add(this->textNetName);
			this->groupBox2->Controls->Add(this->label2);
			this->groupBox2->Dock = System::Windows::Forms::DockStyle::Left;
			this->groupBox2->Location = System::Drawing::Point(0, 152);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(368, 445);
			this->groupBox2->TabIndex = 33;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Netowork info";
			// 
			// text_chosen_file
			// 
			this->text_chosen_file->Location = System::Drawing::Point(16, 408);
			this->text_chosen_file->Name = S"text_chosen_file";
			this->text_chosen_file->ReadOnly = true;
			this->text_chosen_file->Size = System::Drawing::Size(264, 20);
			this->text_chosen_file->TabIndex = 42;
			this->text_chosen_file->Text = S"";
			// 
			// textAddedBy
			// 
			this->textAddedBy->Location = System::Drawing::Point(80, 368);
			this->textAddedBy->Name = S"textAddedBy";
			this->textAddedBy->ReadOnly = true;
			this->textAddedBy->Size = System::Drawing::Size(264, 20);
			this->textAddedBy->TabIndex = 41;
			this->textAddedBy->Text = S"";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(32, 376);
			this->label8->Name = S"label8";
			this->label8->Size = System::Drawing::Size(37, 16);
			this->label8->TabIndex = 40;
			this->label8->Text = S"Added";
			// 
			// textNetLinksNum
			// 
			this->textNetLinksNum->Location = System::Drawing::Point(144, 136);
			this->textNetLinksNum->Name = S"textNetLinksNum";
			this->textNetLinksNum->ReadOnly = true;
			this->textNetLinksNum->Size = System::Drawing::Size(64, 20);
			this->textNetLinksNum->TabIndex = 39;
			this->textNetLinksNum->Text = S"";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(128, 120);
			this->label7->Name = S"label7";
			this->label7->Size = System::Drawing::Size(59, 16);
			this->label7->TabIndex = 38;
			this->label7->Text = S"Links num:";
			// 
			// textNetNodesNum
			// 
			this->textNetNodesNum->Location = System::Drawing::Point(40, 136);
			this->textNetNodesNum->Name = S"textNetNodesNum";
			this->textNetNodesNum->ReadOnly = true;
			this->textNetNodesNum->Size = System::Drawing::Size(64, 20);
			this->textNetNodesNum->TabIndex = 37;
			this->textNetNodesNum->Text = S"";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(24, 120);
			this->label5->Name = S"label5";
			this->label5->Size = System::Drawing::Size(65, 16);
			this->label5->TabIndex = 36;
			this->label5->Text = S"Nodes num:";
			// 
			// textNetDir
			// 
			this->textNetDir->Location = System::Drawing::Point(40, 88);
			this->textNetDir->Name = S"textNetDir";
			this->textNetDir->ReadOnly = true;
			this->textNetDir->Size = System::Drawing::Size(304, 20);
			this->textNetDir->TabIndex = 35;
			this->textNetDir->Text = S"";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(24, 72);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(41, 16);
			this->label3->TabIndex = 34;
			this->label3->Text = S"Net dir:";
			// 
			// but_find_dir
			// 
			this->but_find_dir->Location = System::Drawing::Point(280, 408);
			this->but_find_dir->Name = S"but_find_dir";
			this->but_find_dir->TabIndex = 28;
			this->but_find_dir->Text = S"Open file";
			this->but_find_dir->Click += new System::EventHandler(this, &CAddEditNet::but_find_dir_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(16, 168);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(62, 16);
			this->label1->TabIndex = 26;
			this->label1->Text = S"Comments:";
			// 
			// textNetComments
			// 
			this->textNetComments->Location = System::Drawing::Point(40, 184);
			this->textNetComments->Multiline = true;
			this->textNetComments->Name = S"textNetComments";
			this->textNetComments->Size = System::Drawing::Size(304, 160);
			this->textNetComments->TabIndex = 27;
			this->textNetComments->Text = S"";
			// 
			// textNetName
			// 
			this->textNetName->Location = System::Drawing::Point(40, 42);
			this->textNetName->Name = S"textNetName";
			this->textNetName->Size = System::Drawing::Size(304, 20);
			this->textNetName->TabIndex = 25;
			this->textNetName->Text = S"";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(24, 26);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(56, 16);
			this->label2->TabIndex = 24;
			this->label2->Text = S"Net name:";
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->but_ok_for_all);
			this->groupBox3->Controls->Add(this->butCancel);
			this->groupBox3->Controls->Add(this->butOk);
			this->groupBox3->Dock = System::Windows::Forms::DockStyle::Bottom;
			this->groupBox3->Location = System::Drawing::Point(368, 541);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(304, 56);
			this->groupBox3->TabIndex = 34;
			this->groupBox3->TabStop = false;
			// 
			// butCancel
			// 
			this->butCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->butCancel->Location = System::Drawing::Point(208, 24);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 27;
			this->butCancel->Text = S"Cancel";
			// 
			// butOk
			// 
			this->butOk->Location = System::Drawing::Point(128, 24);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 26;
			this->butOk->Text = S"OK";
			this->butOk->Click += new System::EventHandler(this, &CAddEditNet::butOk_Click);
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->groupBox6);
			this->groupBox4->Controls->Add(this->groupBox5);
			this->groupBox4->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox4->Location = System::Drawing::Point(368, 152);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(304, 389);
			this->groupBox4->TabIndex = 35;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = S"Connection configurations";
			// 
			// groupBox6
			// 
			this->groupBox6->Controls->Add(this->list_conns);
			this->groupBox6->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox6->Location = System::Drawing::Point(104, 16);
			this->groupBox6->Name = S"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(197, 370);
			this->groupBox6->TabIndex = 1;
			this->groupBox6->TabStop = false;
			// 
			// list_conns
			// 
			System::Windows::Forms::ColumnHeader* __mcTemp__1[] = new System::Windows::Forms::ColumnHeader*[3];
			__mcTemp__1[0] = this->columnHeader1;
			__mcTemp__1[1] = this->columnHeader2;
			__mcTemp__1[2] = this->columnHeader3;
			this->list_conns->Columns->AddRange(__mcTemp__1);
			this->list_conns->Dock = System::Windows::Forms::DockStyle::Fill;
			this->list_conns->FullRowSelect = true;
			this->list_conns->GridLines = true;
			this->list_conns->Location = System::Drawing::Point(3, 16);
			this->list_conns->Name = S"list_conns";
			this->list_conns->Size = System::Drawing::Size(191, 351);
			this->list_conns->TabIndex = 0;
			this->list_conns->View = System::Windows::Forms::View::Details;
			this->list_conns->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CAddEditNet::list_conns_MouseDown);
			this->list_conns->DoubleClick += new System::EventHandler(this, &CAddEditNet::list_conns_DoubleClick);
			this->list_conns->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CAddEditNet::list_conns_ColumnClick);
			// 
			// columnHeader1
			// 
			this->columnHeader1->Text = S"Name";
			// 
			// columnHeader2
			// 
			this->columnHeader2->Text = S"File";
			// 
			// columnHeader3
			// 
			this->columnHeader3->Text = S"Directory";
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->but_rem_conn);
			this->groupBox5->Controls->Add(this->but_edit_conn);
			this->groupBox5->Controls->Add(this->but_add_conn);
			this->groupBox5->Dock = System::Windows::Forms::DockStyle::Left;
			this->groupBox5->Location = System::Drawing::Point(3, 16);
			this->groupBox5->Name = S"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(101, 370);
			this->groupBox5->TabIndex = 0;
			this->groupBox5->TabStop = false;
			// 
			// but_rem_conn
			// 
			this->but_rem_conn->Location = System::Drawing::Point(16, 96);
			this->but_rem_conn->Name = S"but_rem_conn";
			this->but_rem_conn->TabIndex = 2;
			this->but_rem_conn->Text = S"Remove";
			this->but_rem_conn->Click += new System::EventHandler(this, &CAddEditNet::but_rem_conn_Click);
			// 
			// but_edit_conn
			// 
			this->but_edit_conn->Location = System::Drawing::Point(16, 64);
			this->but_edit_conn->Name = S"but_edit_conn";
			this->but_edit_conn->TabIndex = 1;
			this->but_edit_conn->Text = S"Edit";
			this->but_edit_conn->Click += new System::EventHandler(this, &CAddEditNet::but_edit_conn_Click);
			// 
			// but_add_conn
			// 
			this->but_add_conn->Location = System::Drawing::Point(16, 32);
			this->but_add_conn->Name = S"but_add_conn";
			this->but_add_conn->TabIndex = 0;
			this->but_add_conn->Text = S"Add";
			this->but_add_conn->Click += new System::EventHandler(this, &CAddEditNet::but_add_conn_Click);
			// 
			// but_ok_for_all
			// 
			this->but_ok_for_all->Location = System::Drawing::Point(16, 24);
			this->but_ok_for_all->Name = S"but_ok_for_all";
			this->but_ok_for_all->Size = System::Drawing::Size(88, 23);
			this->but_ok_for_all->TabIndex = 28;
			this->but_ok_for_all->Text = S"OK - FOR ALL";
			this->but_ok_for_all->Visible = false;
			this->but_ok_for_all->Click += new System::EventHandler(this, &CAddEditNet::but_ok_for_all_Click);
			// 
			// CAddEditNet
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(672, 597);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Name = S"CAddEditNet";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = S"AddEditNet";
			this->Activated += new System::EventHandler(this, &CAddEditNet::CAddEditNet_Activated);
			this->groupBox1->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox6->ResumeLayout(false);
			this->groupBox5->ResumeLayout(false);
			this->ResumeLayout(false);

		}		
	

private: System::Void but_find_dir_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void butOk_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void CAddEditNet_Activated(System::Object *  sender, System::EventArgs *  e);

private: System::Void but_add_conn_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_edit_conn_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_rem_conn_Click(System::Object *  sender, System::EventArgs *  e);




private: System::Void list_conns_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_conns_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_conns_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

private: System::Void but_ok_for_all_Click(System::Object *  sender, System::EventArgs *  e);


};

};

