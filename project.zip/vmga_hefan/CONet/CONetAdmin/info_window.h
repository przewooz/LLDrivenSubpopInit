#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace CONetAdmin
{
	#define  STANDARD_INFO_SLEEP	1000

	/// <summary> 
	/// Summary for info_window
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CInfoWindow : public System::Windows::Forms::Form
	{
	public: 
		CInfoWindow(void)
		{
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}


	public: System::Windows::Forms::ProgressBar *  pbar_progres;
	public: System::Windows::Forms::Label *  lab_text;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->pbar_progres = new System::Windows::Forms::ProgressBar();
			this->lab_text = new System::Windows::Forms::Label();
			this->SuspendLayout();
			// 
			// pbar_progres
			// 
			this->pbar_progres->Location = System::Drawing::Point(16, 16);
			this->pbar_progres->Name = S"pbar_progres";
			this->pbar_progres->Size = System::Drawing::Size(320, 23);
			this->pbar_progres->TabIndex = 0;
			// 
			// lab_text
			// 
			this->lab_text->AutoSize = true;
			this->lab_text->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, (System::Byte)238);
			this->lab_text->Location = System::Drawing::Point(16, 48);
			this->lab_text->Name = S"lab_text";
			this->lab_text->Size = System::Drawing::Size(0, 18);
			this->lab_text->TabIndex = 1;
			// 
			// CInfoWindow
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(354, 87);
			this->ControlBox = false;
			this->Controls->Add(this->lab_text);
			this->Controls->Add(this->pbar_progres);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = S"CInfoWindow";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = S"info_window";
			this->ResumeLayout(false);

		}		
	};
};//namespace CONetAdmin