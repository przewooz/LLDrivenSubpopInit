#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for AddEditFitFunc
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CAddEditFitFunc : public System::Windows::Forms::Form
	{
	public: 
		CAddEditFitFunc(void)
		{
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::Button *  butOk;
	public: System::Windows::Forms::TextBox *  textFFuncName;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::Label *  label1;
	public: System::Windows::Forms::TextBox *  textFFuncComm;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->butCancel = new System::Windows::Forms::Button();
			this->butOk = new System::Windows::Forms::Button();
			this->textFFuncName = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->label1 = new System::Windows::Forms::Label();
			this->textFFuncComm = new System::Windows::Forms::TextBox();
			this->SuspendLayout();
			// 
			// butCancel
			// 
			this->butCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->butCancel->Location = System::Drawing::Point(376, 200);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 32;
			this->butCancel->Text = S"Cancel";
			// 
			// butOk
			// 
			this->butOk->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->butOk->Location = System::Drawing::Point(288, 200);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 31;
			this->butOk->Text = S"OK";
			// 
			// textFFuncName
			// 
			this->textFFuncName->Location = System::Drawing::Point(40, 48);
			this->textFFuncName->Name = S"textFFuncName";
			this->textFFuncName->Size = System::Drawing::Size(304, 20);
			this->textFFuncName->TabIndex = 29;
			this->textFFuncName->Text = S"";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(16, 24);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(82, 16);
			this->label2->TabIndex = 28;
			this->label2->Text = S"Function name:";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(16, 88);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(106, 16);
			this->label1->TabIndex = 27;
			this->label1->Text = S"Function comments:";
			// 
			// textFFuncComm
			// 
			this->textFFuncComm->Location = System::Drawing::Point(40, 112);
			this->textFFuncComm->Multiline = true;
			this->textFFuncComm->Name = S"textFFuncComm";
			this->textFFuncComm->Size = System::Drawing::Size(304, 56);
			this->textFFuncComm->TabIndex = 30;
			this->textFFuncComm->Text = S"";
			// 
			// CAddEditFitFunc
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(464, 237);
			this->Controls->Add(this->butCancel);
			this->Controls->Add(this->butOk);
			this->Controls->Add(this->textFFuncName);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textFFuncComm);
			this->Name = S"CAddEditFitFunc";
			this->Text = S"AddEditFitFunc";
			this->ResumeLayout(false);

		}		
	};
};//namespace CONetAdmin