#include "StdAfx.h"
#include "AddEditFDb.h"


using namespace CONetAdmin;

System::Void CAddEditFDb::but_find_dir_Click(System::Object *  sender, System::EventArgs *  e)
{

	FolderBrowserDialog* folderBrowserDialog1 = new FolderBrowserDialog();

	// Set the help text description for the FolderBrowserDialog.
    folderBrowserDialog1->Description = S"Select the directory that you want to use as the file databse root.";

    // Do not allow the user to create new files via the FolderBrowserDialog.
    folderBrowserDialog1->ShowNewFolderButton = false;

    // Default to the My Documents folder.
    //folderBrowserDialog1->RootFolder = Environment::SpecialFolder::Personal;

	System::Windows::Forms::DialogResult result = folderBrowserDialog1->ShowDialog();
        if (result == DialogResult::OK) 
		{
			textFDbDir->Text = folderBrowserDialog1->SelectedPath;
		}//if (result == DialogResult::OK) 
	

}//System::Void CAddEditFDb::but_find_dir_Click(System::Object *  sender, System::EventArgs *  e)