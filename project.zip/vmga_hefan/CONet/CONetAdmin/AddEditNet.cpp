#include "StdAfx.h"
#include "AddEditNet.h"


using namespace CONetAdmin;
using namespace TopologyTranslator;
using namespace System::IO;



void  CAddEditNet::v_add_net(CString  sNetPath)
{
	CTopologyTranslator  c_net_buf;
	CString  s_comments;

	if  (
		c_net_buf.iLoadTopologyFile(sNetPath,  &s_comments)
		!=  1
		)  
	{
		::MessageBox(NULL, "Unable to load .net file", "Error", MB_OK);
		return;
	}//if  (

	CNETsimulatorSimplyfied  *pc_net;
	pc_net  =  (CNETsimulatorSimplyfied  *)  c_net_buf.pcGetSim();

	CString  s_buf;

	s_buf.Format("%ld", pc_net->lGetNodesNum());
	textNetNodesNum->Text  =  s_buf;

	s_buf.Format("%d", pc_net->lGetLinksNum());
	textNetLinksNum->Text  =  s_buf;

	FileInfo  *fi  =  new  FileInfo(sNetPath);
	s_buf  =  fi->Name;
	
	int  i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;


	CString  s_name;

	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_name  +=  s_buf.GetAt(ii);
	else
		s_name  =  s_buf;
	
	textNetName->Text  =  s_name;
	textNetComments->Text  =  s_comments;

	text_chosen_file->Text  =  sNetPath;

}//CError  CAddEditNet::e_add_net(CString  sNetPath)


System::Void CAddEditNet::but_find_dir_Click(System::Object *  sender, System::EventArgs *  e)
{
    OpenFileDialog* openFileDialog1 = new OpenFileDialog();
 
    //openFileDialog1->InitialDirectory = S"D:\\praca dyplomowa - nowy interfejs\\publikacja\\FD_init" ;
	openFileDialog1->Filter = "net files (*.net)|*.net|All files (*.*)|*.*";
    openFileDialog1->FilterIndex = 0;
    openFileDialog1->RestoreDirectory = true;
	openFileDialog1->Multiselect  =  true;

    if(openFileDialog1->ShowDialog() == DialogResult::OK)
    {
		CString  s_buf;

		if  (openFileDialog1->FileNames->Count  >  1)
		{
			CAddEditNet  *pc_buf_dialog;
			CInfoWindow  *pc_info_dialog;
			pc_info_dialog  =  NULL;
			CString  s_buf;
			pc_buf_dialog  =  new  CAddEditNet(pc_system);

			bool  b_ok_for_all  =  false;
			for  (int  ii = 0;  ii < openFileDialog1->FileNames->Count; ii++)
			{
				
				pc_buf_dialog->v_add_net(openFileDialog1->FileNames[ii]);
				pc_buf_dialog->vSetFDbRoot(pc_fdb_root);
				pc_buf_dialog->but_find_dir->Visible  =  false;
				pc_buf_dialog->but_ok_for_all->Visible  =  true;

				if  (b_ok_for_all  ==  false)
				{
					if  (pc_buf_dialog->ShowDialog()  ==  DialogResult::Yes)
					{
						b_ok_for_all  =  true;
						pc_info_dialog  =  new  CInfoWindow;
						pc_info_dialog->Text  =  S"Adding networks...";
					}//if  (pc_buf_dialog->ShowDialog()  ==  DialogResult::Yes)
				}//if  (b_ok_for_all  ==  false)
				if  (b_ok_for_all  ==  true)
				{
					pc_info_dialog->pbar_progres->Minimum = 0;
					pc_info_dialog->pbar_progres->Maximum = openFileDialog1->FileNames->Count;
					pc_info_dialog->pbar_progres->Value = ii;
					s_buf.Format("%d/%d networks added", ii, openFileDialog1->FileNames->Count);
					pc_info_dialog->lab_text->Text  =  s_buf;
					pc_info_dialog->Refresh();
					pc_info_dialog->Show();

					pc_buf_dialog->butOk_Click(sender, e);				
				}//if  (b_ok_for_all  ==  true)
			}//for  (int  ii = 0;  ii < openFileDialog1->FileNames->Count; ii++)
			if  (pc_info_dialog  !=  NULL)  
			{
				pc_info_dialog->pbar_progres->Minimum = 0;
				pc_info_dialog->pbar_progres->Maximum = openFileDialog1->FileNames->Count;
				pc_info_dialog->pbar_progres->Value = openFileDialog1->FileNames->Count;
				s_buf.Format("FINISHED! %d/%d networks added", openFileDialog1->FileNames->Count, openFileDialog1->FileNames->Count);
				pc_info_dialog->lab_text->Text  =  s_buf;
				pc_info_dialog->Refresh();
				pc_info_dialog->Show();
				Sleep(STANDARD_INFO_SLEEP);
				pc_info_dialog->Hide();
			}//if  (pc_info_dialog  !=  NULL)  
			DialogResult  =  DialogResult::OK;
			Close();
		}//if  (openFileDialog1->FileNames->Count  >  1)
		else
		{
			v_add_net(openFileDialog1->FileName);						
		}//else  if  (openFileDialog1->FileNames->Count  >  1)

    }//if(openFileDialog1->ShowDialog() == DialogResult::OK)


		 
};//System::Void CAddEditNet::but_find_dir_Click(System::Object *  sender, System::EventArgs *  e)



void  CAddEditNet::v_refresh_conns()
{
	CError  c_err;

	//if the net is not existing yet
	if  (i_net_index  <  0)
	{
		but_add_conn->Enabled  =  false;
		but_edit_conn->Enabled  =  false;
		but_rem_conn->Enabled  =  false;

		list_conns->Enabled  =  false;
		
		return;
	}//if  (i_net_index  <  0)

	if  (pc_fdb_root  ==  NULL)
	{
		c_err.vPutError("No fdb root given!");
		c_err.vShowWindow();
		Close();
		return;
	}//if  (pc_fdb_root  ==  NULL)

	c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->eRefreshNetConns();

	if  (c_err)
	{
		c_err.vShowWindow();
		return;
	}//if  (c_err)

	int  i_buf;
	CString  s_conn_name, s_conn_file, s_conn_dir;

	list_conns->Items->Clear();
	for  (int  ii = 0; ii < (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->size(); ii++)
	{
		pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(ii)->vGetData
			(
			&i_buf,  &i_buf,
			&s_conn_name, &s_conn_file, &s_conn_dir
			);

		ListViewItem* item_buf  =  new ListViewItem((String *) s_conn_name);
		item_buf->SubItems->Add((String *) s_conn_file);
		item_buf->SubItems->Add((String *) s_conn_dir);
		CString  s_buf;
		s_buf.Format("%d", ii);
		item_buf->SubItems->Add(s_buf);

		list_conns->Items->Add(item_buf);
		
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)

	i_selected_conn_index  =  -1;

	//list_fdb_roots_MouseUp(NULL, NULL);
	list_conns->Refresh();
}//void  CAddEditNet::v_refresh_conns()



System::Void CAddEditNet::CAddEditNet_Activated(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (pc_system  ==  NULL)
	{
		c_err.vPutError("No system object!");
		c_err.vShowWindow();
		Close();
		return;
	}//if  (pc_fdb_root  ==  NULL)

	if  (b_activated  ==  false)
	{
		if  (pc_fdb_root  ==  NULL)
		{
			c_err.vPutError("No fdb root given!");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		
		int  i_id;
		CString  s_root_dir, s_fdb_name;

		pc_fdb_root->vGetData
			(
			&i_id,
			&s_root_dir, &s_fdb_name
			);

		textFDbName->Text  =  (String *)  s_fdb_name;
		textFDbDir->Text  =  (String *)  s_root_dir;


		if  (i_net_index  >=  0)
		{
			if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
			{
				int  i_id;
				int  i_net_root_id;
				int  i_num_nodes,  i_num_edges;
				CString  s_net_name,  s_net_file,  s_net_dir;
				CString  s_net_comments;
				__int64  dt_added;

				pc_fdb_root->pvGetNets()->at(i_net_index)->vGetData
					(
					&i_id,
					&i_net_root_id,
					&i_num_nodes,  &i_num_edges,
					&s_net_name,  &s_net_file,  &s_net_dir,
					&s_net_comments,
					&dt_added		
					);

				textNetName->Text  =  (String *)  s_net_name;
				textNetDir->Text  =  (String *)  s_net_dir;
				textNetComments->Text  =  (String *)  s_net_comments;

				CString  s_buf;
				s_buf.Format("%d", i_num_nodes);
				textNetNodesNum->Text  =  (String *)  s_buf;
				s_buf.Format("%d", i_num_edges);
				textNetLinksNum->Text  =  (String *)  s_buf;
				
				System::DateTime  dt_buf;
				dt_buf  =  System::DateTime::FromFileTime(dt_added);
				textAddedBy->Text  =  dt_buf.ToString();

				//if we edit the file can not be changed!
				text_chosen_file->Visible  =  false;
				but_find_dir->Visible  =  false;
			
			}//if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
			else
			{
				c_err.vPutError("Wrong net index!");
				c_err.vShowWindow();
				Close();
				return;
			}//else  if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
		
		}//if  (i_net_index  >=  0)

		v_refresh_conns();
		
		b_activated  =  true;
	}//if  (b_activated  ==  false)

}//System::Void CAddEditNet::CAddEditNet_Activated(System::Object *  sender, System::EventArgs *  e)




System::Void CAddEditNet::but_ok_for_all_Click(System::Object *  sender, System::EventArgs *  e)
{
	DialogResult  =  DialogResult::Yes;
}//System::Void CAddEditNet::but_ok_for_all_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CAddEditNet::butOk_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (pc_fdb_root  ==  NULL)
	{
		c_err.vPutError("No fdb root assigned");
		c_err.vShowWindow();
		return;
	}//if  (pc_fdb_root  ==  NULL)

	
	//now loading data from window
	int  i_node_num,  i_link_num;
	CString  s_buf;

	s_buf  =  textNetNodesNum->Text;
	i_node_num  =  atoi( (LPCSTR) s_buf);

	s_buf  =  textNetLinksNum->Text;
	i_link_num  =  atoi( (LPCSTR) s_buf);


	if  (i_net_index  <  0)
	{
		//ADDING NEW NET

		c_err  =  pc_fdb_root->eRefresh();
		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)
		
		c_err  =  pc_fdb_root->eAddNetwork
			(
			text_chosen_file->Text, 
			i_node_num, i_link_num,
			textNetName->Text,  textNetComments->Text
			);
	}//if  (i_net_index  <  0)
	else
	{
		if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
		{
			int  i_id;
			int  i_net_root_id;
			int  i_num_nodes,  i_num_edges;
			CString  s_net_name,  s_net_file,  s_net_dir;
			CString  s_net_comments;
			__int64  dt_added;

			pc_fdb_root->pvGetNets()->at(i_net_index)->vGetData
				(
				&i_id,
				&i_net_root_id,
				&i_num_nodes,  &i_num_edges,
				&s_net_name,  &s_net_file,  &s_net_dir,
				&s_net_comments,
				&dt_added
				);

			
			c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->eUpdate
				(
				i_num_nodes,  i_num_edges,
				textNetName->Text,
				s_net_file,  s_net_dir,
				textNetComments->Text
				);

		}//if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
		else
		{
			c_err.vPutError("Wrong net index!");
			c_err.vShowWindow();
			Close();
			return;
		}//else  if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
	
			
	}//else  if  (i_net_index  <  0)

	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)

	DialogResult  =  DialogResult::OK;
};//System::Void CAddEditNet::butOk_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CAddEditNet::but_add_conn_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (pc_fdb_root  ==  NULL)
	{
		c_err.vPutError("You must choose fdb root to add a new network");
		c_err.vShowWindow();
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)

	if  ( (i_net_index  >=  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  <  0) )
	{
		c_err.vPutError("Wrong net index");
		c_err.vShowWindow();
		return;				
	}//if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )


	CAddEditConn  *pc_edit_window;

	pc_edit_window  =  new  CAddEditConn(pc_system);
	pc_edit_window->vSetFDbRootAndNetIndex(pc_fdb_root, i_net_index);

	
	if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
	{
		v_refresh_conns();
	}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
}//System::Void CAddEditNet::but_add_conn_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CAddEditNet::list_conns_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_conns->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_conns->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_conns->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_conns->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_conns->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_conns->ListViewItemSorter  !=  NULL)
	else
		list_conns->ListViewItemSorter = new list_item_comparer(e->Column);
}//System::Void CAddEditNet::list_conns_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)



System::Void CAddEditNet::list_conns_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	but_edit_conn_Click(sender, e);
}//System::Void CAddEditNet::list_conns_DoubleClick(System::Object *  sender, System::EventArgs *  e)


System::Void CAddEditNet::list_conns_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	ListViewItem *pc_selected = list_conns->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_conn_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);

		if  ( (i_selected_conn_index  <  (int) pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->size())&&(i_selected_conn_index  >=  0) )
		{
			
		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_conn_index  =  -1;
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)
}//System::Void CAddEditNet::list_conns_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)



System::Void CAddEditNet::but_edit_conn_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (pc_fdb_root  ==  NULL)||(i_net_index < 0) )
	{
		::MessageBox(NULL,"You must choose fdb root and net to add a new connection config","Info",MB_OK);
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)

	if  ( (i_selected_conn_index  <  (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->size())&&(i_selected_conn_index  >=  0) )
	{
		
		CAddEditConn  *pc_edit_window;

		pc_edit_window  =  new  CAddEditConn(pc_system);
		pc_edit_window->vSetFDbRootAndNetIndex(pc_fdb_root, i_net_index);
		pc_edit_window->vSetConnIndex(i_selected_conn_index);

		
		if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
		{
			v_refresh_conns();
		}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)	

		
	}//if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	else
	{
		::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
	}//else  if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	
}//System::Void CAddEditNet::but_edit_conn_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CAddEditNet::but_rem_conn_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (pc_fdb_root  ==  NULL)||(i_net_index < 0) )
	{
		::MessageBox(NULL,"You must choose fdb root and net to add a new connection config","Info",MB_OK);
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)

	if  ( (i_selected_conn_index  <  (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->size())&&(i_selected_conn_index  >=  0) )
	{
		CError  c_err;

		int  i_id;
		int  i_net_id;
		CString  s_conn_name;
		CString  s_conn_file,  s_conn_dir;

		pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_selected_conn_index)->vGetData
			(
			&i_id,
			&i_net_id,
			&s_conn_name,
			&s_conn_file,  &s_conn_dir
			);

	
		CString  s_buf;
		s_buf.Format("Are You sure You want to delete this network configuration?:'%s'?", (LPCSTR) s_conn_name);
		if  (::MessageBox(NULL,  s_buf, "Delete?", MB_YESNO)  ==  IDYES)  
		{
			c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->eRemoveNetConn(pc_fdb_root->sGetRootDir(), i_selected_conn_index);
			if  (c_err)  c_err.vShowWindow();
            v_refresh_conns();
		}//if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  

	}//if  (i_selected_index  <  i_fdb_len)
	else
	{
        ::MessageBox(NULL,"Unexpected error caused by wrong selection index."	, "Error", MB_OK);
	}//else  if  (i_selected_index  <  i_fdb_len)
};//System::Void CAddEditNet::but_rem_conn_Click(System::Object *  sender, System::EventArgs *  e)




