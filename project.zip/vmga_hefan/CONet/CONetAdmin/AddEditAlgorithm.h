#pragma once

#include  "atlstr.h"  //CString
#include  "CODb.h"

//windows
#include  "AddEditAlgParam.h"

//list item comparer
#include  "list_comparer.h"


using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

using namespace CONetDbTools;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for AddEditAlgorithm
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CAddEditAlgorithm : public System::Windows::Forms::Form
	{
	public: 
		CAddEditAlgorithm (void)
		{
			pc_alg  =  NULL;
			i_selected_param_index = -1;
			b_activated  =  false;

			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}











	private: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::Button *  butOk;
	private: System::Windows::Forms::GroupBox *  groupBox2;
	public: System::Windows::Forms::TextBox *  textAlgName;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::Label *  label1;
	public: System::Windows::Forms::TextBox *  textAlgComments;
	private: System::Windows::Forms::GroupBox *  groupBox1;
	private: System::Windows::Forms::GroupBox *  groupBox3;
	private: System::Windows::Forms::GroupBox *  groupBox5;

	private: System::Windows::Forms::ColumnHeader *  columnHeader1;
	private: System::Windows::Forms::ColumnHeader *  columnHeader2;

	private: System::Windows::Forms::Button *  but_rem_param;
	private: System::Windows::Forms::Button *  but_edit_param;
	private: System::Windows::Forms::ListView *  list_params;
	private: System::Windows::Forms::Button *  but_add_param;















	public:  void  vSetAlgorithm(CCOAlgorithm  *pcAlg)  {pc_alg = pcAlg;};

	private:

		CCOAlgorithm  *pc_alg;
		int  i_selected_param_index;
		bool  b_activated;

		void  v_refresh_params();
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox4 = new System::Windows::Forms::GroupBox();
			this->butCancel = new System::Windows::Forms::Button();
			this->butOk = new System::Windows::Forms::Button();
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->textAlgName = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->label1 = new System::Windows::Forms::Label();
			this->textAlgComments = new System::Windows::Forms::TextBox();
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->groupBox5 = new System::Windows::Forms::GroupBox();
			this->list_params = new System::Windows::Forms::ListView();
			this->columnHeader1 = new System::Windows::Forms::ColumnHeader();
			this->columnHeader2 = new System::Windows::Forms::ColumnHeader();
			this->groupBox3 = new System::Windows::Forms::GroupBox();
			this->but_rem_param = new System::Windows::Forms::Button();
			this->but_edit_param = new System::Windows::Forms::Button();
			this->but_add_param = new System::Windows::Forms::Button();
			this->groupBox4->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox5->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->butCancel);
			this->groupBox4->Controls->Add(this->butOk);
			this->groupBox4->Dock = System::Windows::Forms::DockStyle::Bottom;
			this->groupBox4->Location = System::Drawing::Point(0, 269);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(712, 56);
			this->groupBox4->TabIndex = 31;
			this->groupBox4->TabStop = false;
			// 
			// butCancel
			// 
			this->butCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->butCancel->Location = System::Drawing::Point(624, 24);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 30;
			this->butCancel->Text = S"Cancel";
			// 
			// butOk
			// 
			this->butOk->Location = System::Drawing::Point(536, 24);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 29;
			this->butOk->Text = S"OK";
			this->butOk->Click += new System::EventHandler(this, &CAddEditAlgorithm::butOk_Click);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->textAlgName);
			this->groupBox2->Controls->Add(this->label2);
			this->groupBox2->Controls->Add(this->label1);
			this->groupBox2->Controls->Add(this->textAlgComments);
			this->groupBox2->Dock = System::Windows::Forms::DockStyle::Left;
			this->groupBox2->Location = System::Drawing::Point(0, 0);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(360, 269);
			this->groupBox2->TabIndex = 32;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Algorithm info";
			// 
			// textAlgName
			// 
			this->textAlgName->Location = System::Drawing::Point(40, 48);
			this->textAlgName->Name = S"textAlgName";
			this->textAlgName->Size = System::Drawing::Size(304, 20);
			this->textAlgName->TabIndex = 31;
			this->textAlgName->Text = S"";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(24, 24);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(87, 16);
			this->label2->TabIndex = 30;
			this->label2->Text = S"Algorithm name:";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(24, 88);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(111, 16);
			this->label1->TabIndex = 29;
			this->label1->Text = S"Algorithm comments:";
			// 
			// textAlgComments
			// 
			this->textAlgComments->Location = System::Drawing::Point(40, 112);
			this->textAlgComments->Multiline = true;
			this->textAlgComments->Name = S"textAlgComments";
			this->textAlgComments->Size = System::Drawing::Size(304, 136);
			this->textAlgComments->TabIndex = 32;
			this->textAlgComments->Text = S"";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->groupBox5);
			this->groupBox1->Controls->Add(this->groupBox3);
			this->groupBox1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox1->Location = System::Drawing::Point(360, 0);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(352, 269);
			this->groupBox1->TabIndex = 33;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"Parameters";
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->list_params);
			this->groupBox5->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox5->Location = System::Drawing::Point(104, 16);
			this->groupBox5->Name = S"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(245, 250);
			this->groupBox5->TabIndex = 30;
			this->groupBox5->TabStop = false;
			// 
			// list_params
			// 
			System::Windows::Forms::ColumnHeader* __mcTemp__1[] = new System::Windows::Forms::ColumnHeader*[2];
			__mcTemp__1[0] = this->columnHeader1;
			__mcTemp__1[1] = this->columnHeader2;
			this->list_params->Columns->AddRange(__mcTemp__1);
			this->list_params->Dock = System::Windows::Forms::DockStyle::Fill;
			this->list_params->FullRowSelect = true;
			this->list_params->GridLines = true;
			this->list_params->Location = System::Drawing::Point(3, 16);
			this->list_params->Name = S"list_params";
			this->list_params->Size = System::Drawing::Size(239, 231);
			this->list_params->TabIndex = 29;
			this->list_params->View = System::Windows::Forms::View::Details;
			this->list_params->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CAddEditAlgorithm::list_params_MouseDown);
			this->list_params->DoubleClick += new System::EventHandler(this, &CAddEditAlgorithm::list_params_DoubleClick);
			this->list_params->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CAddEditAlgorithm::list_params_ColumnClick);
			// 
			// columnHeader1
			// 
			this->columnHeader1->Text = S"Name";
			this->columnHeader1->Width = 150;
			// 
			// columnHeader2
			// 
			this->columnHeader2->Text = S"Default value";
			this->columnHeader2->Width = 80;
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->but_rem_param);
			this->groupBox3->Controls->Add(this->but_edit_param);
			this->groupBox3->Controls->Add(this->but_add_param);
			this->groupBox3->Dock = System::Windows::Forms::DockStyle::Left;
			this->groupBox3->Location = System::Drawing::Point(3, 16);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(101, 250);
			this->groupBox3->TabIndex = 29;
			this->groupBox3->TabStop = false;
			// 
			// but_rem_param
			// 
			this->but_rem_param->Location = System::Drawing::Point(13, 88);
			this->but_rem_param->Name = S"but_rem_param";
			this->but_rem_param->TabIndex = 5;
			this->but_rem_param->Text = S"Remove";
			this->but_rem_param->Click += new System::EventHandler(this, &CAddEditAlgorithm::but_rem_param_Click);
			// 
			// but_edit_param
			// 
			this->but_edit_param->Location = System::Drawing::Point(13, 56);
			this->but_edit_param->Name = S"but_edit_param";
			this->but_edit_param->TabIndex = 4;
			this->but_edit_param->Text = S"Edit";
			this->but_edit_param->Click += new System::EventHandler(this, &CAddEditAlgorithm::but_edit_param_Click);
			// 
			// but_add_param
			// 
			this->but_add_param->Location = System::Drawing::Point(13, 24);
			this->but_add_param->Name = S"but_add_param";
			this->but_add_param->TabIndex = 3;
			this->but_add_param->Text = S"Add";
			this->but_add_param->Click += new System::EventHandler(this, &CAddEditAlgorithm::but_add_param_Click);
			// 
			// CAddEditAlgorithm
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(712, 325);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox4);
			this->Name = S"CAddEditAlgorithm";
			this->Text = S"AddEditAlgorithm";
			this->Activated += new System::EventHandler(this, &CAddEditAlgorithm::CAddEditAlgorithm_Activated);
			this->groupBox4->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			this->groupBox1->ResumeLayout(false);
			this->groupBox5->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->ResumeLayout(false);

		}		
	private: System::Void but_add_param_Click(System::Object *  sender, System::EventArgs *  e);
	private: System::Void but_edit_param_Click(System::Object *  sender, System::EventArgs *  e);
	private: System::Void but_rem_param_Click(System::Object *  sender, System::EventArgs *  e);
	
private: System::Void CAddEditAlgorithm_Activated(System::Object *  sender, System::EventArgs *  e);


private: System::Void butOk_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void list_params_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_params_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_params_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

};
};