#include "stdafx.h"
#include "MySqlController.h"
#include "CODb.h"



using namespace  CONetDbTools;


CString  CMySqlControl::sFormatForSQL(CString  sSource)
{
	CString  s_res;
	
	s_res  =  sSource;
	s_res.Replace("\\", "\\\\");
	s_res.Replace("'", "\\'");

	return(s_res);
}//CString  CMySqlControl::sFormatForSQL(CString  sSource)



CMySqlControl::CMySqlControl()
{
	pc_connection = new MySqlConnection();
	s_host_name  =  "";
	s_db_name  =  "";
	s_user  =  "";
	s_passwd  =  "";
}//CMySqlControl::CMySqlControl()




CMySqlControl::~CMySqlControl()
{
	vDisconnect();
}//CMySqlControl::~CMySqlControl()



void  CMySqlControl::vSetAll(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd)
{
	vSetHost(sNewHostName);
	vSetDbName(sNewDbName);
	vSetUser(sNewUser);
	vSetPasswd(sNewPasswd);
}//void  CMySqlControl::vSetAll(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd)



bool  CMySqlControl::bIsConnected()
{
	if  (pc_connection->State  ==  1)
		return(true);
	else
		return(false);
}//bool  CMySqlControl::bIsConnected()



CError  CMySqlControl::eConnect()
{
	CError  c_err;
	CString  s_conn;

	s_conn.Format
		(
		"Database=%s;Data Source=%s;User Id=%s;Password=%s",
		s_db_name,  s_host_name,  s_user,  s_passwd
		);

	pc_connection->ConnectionString  =  s_conn;


	try  {pc_connection->Open();}

	catch(Exception *p_ex)
	{
		CString  s_err;
		s_err.Format("An error occured while trying to connect with an SQL server\nServer: '%s':\nDatabase: '%s'\nUser: '%s'\nError: %s",
			s_host_name,  s_db_name,  s_user, p_ex->Message);

		c_err.vPutError(s_err);	
	}//catch(InvalidOperationException *p_ex)
	


	if  (c_err  ==  false)
	{
		if  (bIsConnected()  ==  false)
		{
			CString  s_err;
			s_err.Format("Unable to connect with SQL server using following setting\nServer: '%s':\nDatabase: '%s'\nUser: '%s'\n",
				s_host_name,  s_db_name,  s_user);

			c_err.vPutError(s_err);
		}//if  (pcConnection->State  !=  1)
	}//if  (c_err  ==  false)

	return(c_err);
}//CError  CMySqlControl::eConnect()





void  CMySqlControl::vDisconnect()
{

	if  (bIsConnected()  ==  false)  return;

	pc_connection->Close();
}//void  CMySqlControl::vDisconnect()




CError  CMySqlControl::eAddDb(vector <CString>  *pvsControlSQL,  vector <CString>  *pvsAddSQL, CString  sGetLastId, int *piLastId)
{
	CError  c_err;

	if  (bIsConnected()  ==  false)
	{
		c_err.vPutError("You are not connected to database");
		return(c_err);
	}//if  (bIsConnected()  ==  false)

	MySqlCommand *pc_comm  =  new MySqlCommand;
	pc_comm->Connection  =  pc_connection;
	MySqlTransaction *pc_trans  =  pc_connection->BeginTransaction();
	pc_comm->Transaction  =  pc_trans;


	try  
	{
		//first we execute the control commands
		if  (pvsControlSQL->empty() == false)
		{
			bool  b_row_found;		
			for  (int  ii = 0;  ii < (int) pvsControlSQL->size(); ii++)
			{
				pc_comm->CommandText  =  pvsControlSQL->at(ii);
				MySqlDataReader *pc_reader  =  pc_comm->ExecuteReader();
				b_row_found  =  pc_reader->HasRows;
				pc_reader->Close();

				if  (b_row_found  ==  true)
				{
					CString  s_buf;
					s_buf.Format("The row already exists:\n\"%s\"", pvsControlSQL->at(ii) );
					c_err.vPutError(s_buf);

					return(c_err);		
				}//if  (b_row_found  ==  false)

			}//for  (int  ii = 0;  ii < pcControlSQL->size(); ii++)
		}//if  (pcControlSQL->bFirst())


		//first we execute the control commands
		if  (pvsAddSQL->empty()  ==  false)
		{
			for  (int  ii = 0;  ii < (int) pvsAddSQL->size(); ii++)
			{
				pc_comm->CommandText  =  pvsAddSQL->at(ii);
				pc_comm->ExecuteNonQuery();
			}//for  (int  ii = 0;  ii < pcRmoveSQL->size(); ii++)
		}//if  (pcControlSQL->bFirst())


		//as the last we execute id get sql
		pc_comm->CommandText  =  sGetLastId;
		MySqlDataReader *pc_reader  =  pc_comm->ExecuteReader();
		if  (pc_reader->Read()  ==  true)
		{
			*piLastId  =  pc_reader->GetInt32(0);
			pc_reader->Close();
		}//if  (pc_reader->Read()  ==  true)
		else
		{
			c_err.vPutError("Can not get last id");

			return(c_err);
		}//else  if  (pc_reader->Read()  ==  true)
			
		pc_trans->Commit();

	}//try
	catch(Exception *p_ex)
	{
		CString  s_err;
		s_err.Format("An error occured while communicating with database\nError: %s",  p_ex->Message);

		bool  b_rolled  =  true;
		try
		{
			pc_trans->Rollback();		
		}//try
		catch (Exception *p_roll_ex)
	    {
			b_rolled  =  false;

			CString  s_roll_err;
			s_roll_err.Format("The rollback trial failed with an error.\nError: %s",  p_roll_ex->Message);

			s_err  =  s_err + "\n" + s_roll_err;
		}//catch (SqlException *p_sql_ex)

		c_err.vPutError(s_err);
	}//catch(InvalidOperationException *p_ex)

	

	return(c_err);
}//CError  CMySqlControl::eAddDb(vector <CString>  *pvsControlSQL,  vector <CString>  *pvsAddSQL)






CError  CMySqlControl::eUpdateDb(vector <CString>  *pvsControlSQL,  vector <CString>  *pvsUpdateSQL,  vector <CString>  *pvsEmptyOkControl)
{
	CError  c_err;

	if  (bIsConnected()  ==  false)
	{
		c_err.vPutError("You are not connected to database");
		return(c_err);	
	}//if  (bIsConnected()  ==  false)

	MySqlCommand *pc_comm  =  new MySqlCommand;
	pc_comm->Connection  =  pc_connection;
	MySqlTransaction *pc_trans  =  pc_connection->BeginTransaction();
	pc_comm->Transaction  =  pc_trans;


	try  
	{
		//first we execute the control commands
		if  (pvsControlSQL->empty()  ==  false)
		{
			bool  b_row_found;		
			for  (int  ii = 0;  ii < (int)  pvsControlSQL->size(); ii++)
			{
				pc_comm->CommandText  =  pvsControlSQL->at(ii);
				MySqlDataReader *pc_reader  =  pc_comm->ExecuteReader();
				b_row_found  =  pc_reader->HasRows;
				pc_reader->Close();

				if  (b_row_found  ==  false)
				{
					CString  s_buf;
					s_buf.Format("The following row has changed or been deleted:\n\"%s\"", pvsControlSQL->at(ii) );
					c_err.vPutError(s_buf);

					return(c_err);				
				}//if  (b_row_found  ==  false)

			}//for  (int  ii = 0;  ii < pcControlSQL->size(); ii++)
		}//if  (pcControlSQL->bFirst())

		if  (pvsEmptyOkControl  !=  NULL)
		{
			bool  b_row_found;		
			for  (int  ii = 0;  ii < (int)  pvsEmptyOkControl->size(); ii++)
			{
				pc_comm->CommandText  =  pvsEmptyOkControl->at(ii);
				MySqlDataReader *pc_reader  =  pc_comm->ExecuteReader();
				b_row_found  =  pc_reader->HasRows;
				pc_reader->Close();

				if  (b_row_found  ==  true)
				{
					CString  s_buf;
					s_buf.Format("Ten obiekt jest wci�� w u�yciu, najpierw skasuj powi�zane z nim obiekty:\n\"%s\"", pvsEmptyOkControl->at(ii) );
					c_err.vPutError(s_buf);

					return(c_err);				
				}//if  (b_row_found  ==  false)
			}//for  (int  ii = 0;  ii < pcControlSQL->size(); ii++)
		}//if  (pvsEmptyOkControl  !=  NULL)


		//first we execute the control commands
		if  (pvsUpdateSQL->empty()  ==  false)
		{
			for  (int  ii = 0;  ii < (int)  pvsUpdateSQL->size(); ii++)
			{
				pc_comm->CommandText  =  pvsUpdateSQL->at(ii);
				pc_comm->ExecuteNonQuery();
				
			}//for  (int  ii = 0;  ii < pcRmoveSQL->size(); ii++)
		}//if  (pcControlSQL->bFirst())
			
		pc_trans->Commit();
	}//try
	catch(Exception *p_ex)
	{
		CString  s_err;
		s_err.Format("An error occured while communicating with database\nError: %s",  p_ex->Message);

		bool  b_rolled  =  true;
		try
		{
			pc_trans->Rollback();		
		}//try
		catch (Exception *p_roll_ex)
	    {
			b_rolled  =  false;

			CString  s_roll_err;
			s_roll_err.Format("The rollback trial failed with an error.\nError: %s",  p_roll_ex->Message);

			s_err  =  s_err + "\n" + s_roll_err;
		}//catch (SqlException *p_sql_ex)

		c_err.vPutError(s_err);
	}//catch(InvalidOperationException *p_ex)

	

	return(c_err);
}//CError  CMySqlControl::eUpdate(CCODb  *pcDb)





CError  CMySqlControl::eSelectComponent(vector <void *>  *pvCODbComponents, CString sSelectSQL, int iCompType)
{
	CError  c_err;

	if  (bIsConnected()  ==  false)
	{
		c_err.vPutError("You are not connected to database");
		return(c_err);
	}//if  (bIsConnected()  ==  false)

	MySqlCommand *pc_comm  =  new MySqlCommand;
	pc_comm->Connection  =  pc_connection;
	MySqlTransaction *pc_trans  =  pc_connection->BeginTransaction();
	pc_comm->Transaction  =  pc_trans;


	try  
	{
		pc_comm->CommandText  =  sSelectSQL;
		MySqlDataReader *pc_reader  =  pc_comm->ExecuteReader();
		
		void  *pc_co_db_component;
		while  (pc_reader->Read())
		{
			pc_co_db_component  =  NULL;

			if  (iCompType  ==  CODB_COMP_TYPE_FDB_ROOT)
			{
				if  (c_err  ==  false)
				{
					pc_co_db_component  = (void*) new  CCOFDbRoot(this);
					c_err  =  ((CCOFDbRoot *)  pc_co_db_component)->eLoad(pc_reader);
				}//if  (c_err  ==  false)
			}//if  (iCompType  ==  CODB_COMP_TYPE_FDB_ROOT)

			if  (iCompType  ==  CODB_COMP_TYPE_NETOWRK)
			{
				if  (c_err  ==  false)
				{
					pc_co_db_component  = (void*) new  CCONet(this);
					c_err  =  ((CCONet *)  pc_co_db_component)->eLoad(pc_reader);
				}//if  (c_err  ==  false)
			}//if  (iCompType  ==  CODB_COMP_TYPE_FDB_ROOT)

			if  (iCompType  ==  CODB_COMP_TYPE_NETOWRK_CONN)
			{
				if  (c_err  ==  false)
				{
					pc_co_db_component  = (void*) new  CCONetConn(this);
					c_err  =  ((CCONetConn *)  pc_co_db_component)->eLoad(pc_reader);
				}//if  (c_err  ==  false)
			}//if  (iCompType  ==  CODB_COMP_TYPE_NETOWRK_CONN)

			if  (iCompType  ==  CODB_COMP_TYPE_ALGORITHM)
			{
				if  (c_err  ==  false)
				{
					pc_co_db_component  = (void*) new  CCOAlgorithm(this);
					c_err  =  ((CCOAlgorithm *)  pc_co_db_component)->eLoad(pc_reader);
				}//if  (c_err  ==  false)
			}//if  (iCompType  ==  CODB_COMP_TYPE_ALGORITHM)

			if  (iCompType  ==  CODB_COMP_TYPE_FIT_FUNC)
			{
				if  (c_err  ==  false)
				{
					pc_co_db_component  = (void*) new  CCOFitFunc(this);
					c_err  =  ((CCOFitFunc *)  pc_co_db_component)->eLoad(pc_reader);
				}//if  (c_err  ==  false)
			}//if  (iCompType  ==  CODB_COMP_TYPE_FIT_FUNC)

			if  (iCompType  ==  CODB_COMP_TYPE_COMPUTER)
			{
				if  (c_err  ==  false)
				{
					pc_co_db_component  = (void*) new  CCOComputer(this);
					c_err  =  ((CCOComputer *)  pc_co_db_component)->eLoad(pc_reader);
				}//if  (c_err  ==  false)
			}//if  (iCompType  ==  CODB_COMP_TYPE_COMPUTER)

			if  (iCompType  ==  CODB_COMP_TYPE_ALGORITHM_PARAMETER)
			{
				if  (c_err  ==  false)
				{
					pc_co_db_component  = (void*) new  CCOAlgorithmParam(this);
					c_err  =  ((CCOAlgorithmParam *)  pc_co_db_component)->eLoad(pc_reader);
				}//if  (c_err  ==  false)
			}//if  (iCompType  ==  CODB_COMP_TYPE_ALGORITHM_PARAMETER)

			if  (iCompType  ==  CODB_COMP_TYPE_RESULT)
			{
				if  (c_err  ==  false)
				{
					pc_co_db_component  = (void*) new  CCOResult(this);
					c_err  =  ((CCOResult *)  pc_co_db_component)->eLoad(pc_reader);
				}//if  (c_err  ==  false)
			}//if  (iCompType  ==  CODB_COMP_TYPE_RESULT)


			if  (iCompType  ==  CODB_COMP_TYPE_ALGORITHM_PARAMETER_VALUE)
			{
				if  (c_err  ==  false)
				{
					pc_co_db_component  = (void*) new  CCOAlgorithmParamValue(this);
					c_err  =  ((CCOAlgorithmParamValue *)  pc_co_db_component)->eLoad(pc_reader);
				}//if  (c_err  ==  false)
			}//if  (iCompType  ==  CODB_COMP_TYPE_RESULT)


			if  (iCompType  ==  CODB_COMP_TYPE_RESULT_SET)
			{
				if  (c_err  ==  false)
				{
					pc_co_db_component  = (void*) new  CCOResultSet(this);
					c_err  =  ((CCOResultSet *)  pc_co_db_component)->eLoad(pc_reader);
				}//if  (c_err  ==  false)
			}//if  (iCompType  ==  CODB_COMP_TYPE_RESULT_SET)




			if  (pc_co_db_component  !=  NULL)
			{
				pvCODbComponents->push_back(pc_co_db_component);	
			}//if  (pc_kdb_component  !=  NULL)
			else
			{
				c_err.vPutError("Unknown data type");			
			}//else  if  (pc_kdb_component  !=  NULL)*/

		}//while  (pc_reader->Read())

		pc_reader->Close();
	
		pc_trans->Commit();
	}//try
	catch(Exception *p_ex)
	{
		CString  s_err;
		s_err.Format("An error occured while communicating with database\nError: %s",  p_ex->Message);

		bool  b_rolled  =  true;
		try
		{
			pc_trans->Rollback();		
		}//try
		catch (Exception *p_roll_ex)
	    {
			b_rolled  =  false;

			CString  s_roll_err;
			s_roll_err.Format("The rollback trial failed with an error.\nError: %s",  p_roll_ex->Message);

			s_err  =  s_err + "\n" + s_roll_err;
		}//catch (SqlException *p_sql_ex)

		c_err.vPutError(s_err);
	}//catch(InvalidOperationException *p_ex)

	

	return(c_err);
};//CError  CMySqlControl::eSelectComponent(vector <void *>  *pvKDbComponents, CString sSelectSQL, int iCompType)
















