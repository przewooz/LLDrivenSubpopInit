#pragma once


//tools
#include  "atlstr.h"  //CString
#include  <gcroot.h>
#include <windows.h>

#using  <mysql.data.dll> //mysql objects


//system tools
#include  "Error.h"
#include  <vector>
#include  <iostream>



using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

using namespace MySql;
using namespace MySql::Data;
using namespace MySql::Data::MySqlClient;
using namespace System::Runtime::InteropServices;

using namespace std;



namespace CONetDbTools
{
	
	class  CKDbPart;//predefinition
	class  CKDbMeasure;//predefinition
	class  CKDbComponent;



	class  CMySqlControl
	{
	public:
		static  CString  sFormatForSQL(CString  sSource);

		CMySqlControl();
		~CMySqlControl();

		CError  eConnect();
		void   vDisconnect();

		bool  bIsConnected();

		//info and set functions
		CString  sGetHost()  {return(s_host_name);};
		CString  sGetDbName()  {return(s_db_name);};
		CString  sGetUser()  {return(s_user);};
		CString  sGetPasswd()  {return(s_passwd);};


		void  vSetAll(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd);

		void  vSetHost(CString  sNewHostName)  {s_host_name  =  sNewHostName;};
		void  vSetDbName(CString  sNewDbName)  {s_db_name  =  sNewDbName;};
		void  vSetUser(CString  sNewUser)  {s_user  =  sNewUser;};
		void  vSetPasswd(CString  sNewPasswd)  {s_passwd  =  sNewPasswd;};


		//data retrieve functions
		CError  eUpdateDb(vector <CString>  *pvsControlSQL,  vector <CString> *pvsUpdateSQL, vector <CString>  *pvsEmptyOkControl = NULL);
		CError  eAddDb(vector <CString>  *pvsControlSQL,  vector <CString>  *pvsAddSQL,  CString  sGetLastId, int *piLastId);

		CError  eSelectComponent(vector <void *>  *pvKDbComponents, CString sSelectSQL, int iCompType);
		
	private:

		CString  s_host_name,  s_db_name, s_user, s_passwd;

		gcroot<MySqlConnection*> pc_connection;

	};//class  CMySqlControl

};//namespace AdalisDbTools

