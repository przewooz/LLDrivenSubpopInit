#include "StdAfx.h"
#include "AddEditResult.h"

using namespace CONetAdmin;
using namespace System::IO;


System::Void CAddEditResult::CAddEditResult_Activated(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (pc_system  ==  NULL)
	{
		c_err.vPutError("No system object!");
		c_err.vShowWindow();
		Close();
		return;
	}//if  (pc_fdb_root  ==  NULL)


	if  (b_activated  ==  false)
	{
		if  (pc_fdb_root  ==  NULL)
		{
			c_err.vPutError("No fdb root given!");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		if  (i_net_index  <  0)
		{
			c_err.vPutError("No net index given!");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		if  (i_conn_index  <  0)
		{
			c_err.vPutError("No connection configuration index given!");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		if  ( (i_net_index  >=  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  <  0) )
		{
			c_err.vPutError("Wrong net index");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		if  ( (i_conn_index  >=  (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->size())&&(i_conn_index  <  0) )
		{
			c_err.vPutError("Wrong conn index");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		int  i_fdb_id;
		CString  s_root_dir, s_fdb_name;

		pc_fdb_root->vGetData
			(
			&i_fdb_id,
			&s_root_dir, &s_fdb_name
			);

		textFDbName->Text  =  (String *)  s_fdb_name;
		textFDbDir->Text  =  (String *)  s_root_dir;

		int  i_net_id;
		int  i_net_root_id;
		int  i_num_nodes,  i_num_edges;
		CString  s_net_name,  s_net_file,  s_net_dir;
		CString  s_net_comments;
		__int64  dt_added;

		pc_fdb_root->pvGetNets()->at(i_net_index)->vGetData
			(
			&i_net_id,
			&i_net_root_id,
			&i_num_nodes,  &i_num_edges,
			&s_net_name,  &s_net_file,  &s_net_dir,
			&s_net_comments,
			&dt_added		
			);

		textNetName->Text  =  (String *)  s_net_name;
		textNetDir->Text  =  (String *)  s_net_dir;


		int  i_conn_id;
		int  i_conn_net_id;
		CString  s_conn_name;
		CString  s_conn_file,  s_conn_dir;

		pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->vGetData
			(
			&i_conn_id,
			&i_conn_net_id,
			&s_conn_name,
			&s_conn_file,  &s_conn_dir
			);

		textConnName->Text  =  (String *)  s_conn_name;
		textConnDir->Text  =  (String *)  s_conn_dir;


		v_refresh_dropdowns();

		if  (i_result_index  >=  0)
		{
			if  ( (i_result_index  <  (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->size())&&(i_result_index  >=  0) )
			{
				int  i_id;
				int i_con_id, i_fit_id, i_alg_id, i_comp_id, i_rset_id;
				CString  s_res_dir, s_res_comments;
				double  d_fit_value;
				double  d_time;
				__int64  dt_generated;


				pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(i_result_index)->vGetData
					(
					&i_id,
					&i_con_id, &i_fit_id, &i_alg_id, &i_comp_id,  &i_rset_id, 
					&s_res_dir, &s_res_comments,
					&d_fit_value,
					&d_time,
					&dt_generated
					);


				int  i_ff_ff_id;
				CString  s_ff_name;
				CString  s_ff_comments;

				int  i_alg_alg_id;
				CString  s_alg_name;
				CString  s_alg_comments;

				int  i_comp_comp_id;
				CString  s_comp_name;
				CString  s_comp_comments;

				int  i_rset_rset_id;
				CString  s_rset_name;
				CString  s_rset_comments;

				bool  b_found;
				CError  c_find_err;
				
			
				b_found  =  false;
				for  (int ij = 0; (ij < (int)  pv_ffuncs->size())&&(b_found ==  false); ij++)
				{
					pv_ffuncs->at(ij)->vGetData
						(
						&i_ff_ff_id, &s_ff_name, &s_ff_comments
						);

					if  (i_ff_ff_id  ==  i_fit_id)
					{
						b_found  =  true;
						comboFFunc->SelectedIndex  =  ij;
					}//if  (i_ff_id  ==  i_fit_id)
				}//for  (int ij = 0; (ij < (int)  v_ffuncs.size())&&(b_found ==  false); ij++)
				if  (b_found  ==  false)
				{
					c_find_err.vPutError("Fitness function not found!");
					c_find_err.vShowWindow();									
				}//if  (b_found  ==  false)


				b_found  =  false;
				for  (int ij = 0; (ij < (int)  pv_algorithms->size())&&(b_found ==  false); ij++)
				{
					pv_algorithms->at(ij)->vGetData
						(
						&i_alg_alg_id, &s_alg_name, &s_alg_comments
						);

					if  (i_alg_alg_id  ==  i_alg_id)
					{
						b_found  =  true;
						comboAlgorithm->SelectedIndex  =  ij;
					}//if  (i_ff_id  ==  i_fit_id)

					CError  c_param_err;
					c_param_err  =  pv_algorithms->at(ij)->eRefreshParamsForResult(i_id);
					if  (c_param_err)  c_param_err.vShowWindow();
				}//for  (int ij = 0; (ij < (int)  v_algorithms.size())&&(b_found ==  false); ij++)
				if  (b_found  ==  false)
				{
					c_find_err.vPutError("Algorithm not found!");
					c_find_err.vShowWindow();									
				}//if  (b_found  ==  false)


				b_found  =  false;
				for  (int ij = 0; (ij < (int)  pv_computers->size())&&(b_found ==  false); ij++)
				{
					pv_computers->at(ij)->vGetData
						(
						&i_comp_comp_id, &s_comp_name, &s_comp_comments
						);

					if  (i_comp_comp_id  ==  i_comp_id)
					{
						b_found  =  true;
						comboComput->SelectedIndex  =  ij;
					}//if  (i_ff_id  ==  i_fit_id)
				}//for  (int ij = 0; (ij < (int)  v_computers.size())&&(b_found ==  false); ij++)
				if  (b_found  ==  false)
				{
					c_find_err.vPutError("Computer not found!");
					c_find_err.vShowWindow();									
				}//if  (b_found  ==  false)



				//CAddEditResult::
				b_found  =  false;
				if  (i_rset_id  >  -1)
				{
					for  (int ij = 0; (ij < (int)  pv_rsets->size())&&(b_found ==  false); ij++)
					{
						pv_rsets->at(ij)->vGetData
							(
							&i_rset_rset_id, &s_rset_name, &s_rset_comments
							);

						if  (i_rset_rset_id  ==  i_rset_id)
						{
							b_found  =  true;
							comboRSets->SelectedIndex  =  ij + 1;
						}//if  (i_ff_id  ==  i_fit_id)
					}//for  (int ij = 0; (ij < (int)  v_computers.size())&&(b_found ==  false); ij++)
				}//if  (i_rset_id  >  -1)
				else
				{
					comboRSets->SelectedIndex  =  0;				
					b_found  =  true;
				}//else  if  (i_rset_id  >  -1)
				if  (b_found  ==  false)
				{
					c_find_err.vPutError("Result set not found!");
					c_find_err.vShowWindow();									
				}//if  (b_found  ==  false)


				System::DateTime  dt_buf;
				dt_buf  =  System::DateTime::FromFileTime(dt_generated);

				dtpDate->Value  =  dt_buf;
				dtpTime->Value  =  dt_buf;
									
				text_comments->Text  =  s_res_comments;

				CString  s_buf;

				s_buf.Format("%.16lf", d_fit_value);
				text_ff_val->Text  =  s_buf;
				s_buf.Format("%lf", d_time);
				textTime->Text  =  s_buf;
				
			}//if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
			else
			{
				c_err.vPutError("Wrong result index!");
				c_err.vShowWindow();
				Close();
				return;
			}//else  if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
		
		}//if  (i_net_index  >=  0)

		v_refresh_parameters();
		v_refresh_files();
		

		b_activated  =  true;
	}//if  (b_activated  ==  false)


};//System::Void CAddEditResult::CAddEditResult_Activated(System::Object *  sender, System::EventArgs *  e)


void  CAddEditResult::v_refresh_files()
{
	CError  c_err;

	i_selected_file_index  =  -1;
	list_files->Items->Clear();

	if  (i_result_index  <  0)
	{
		for  (int ii = 0; ii < (int) pv_files->size(); ii++)
		{
			FileInfo  *pc_fi;
			pc_fi  =  new  FileInfo(pv_files->at(ii));
			
			ListViewItem* item_buf  =  new ListViewItem(pc_fi->Name);
			CString  s_buf;

			s_buf.Format("%d", ii);
			item_buf->SubItems->Add(s_buf);

			list_files->Items->Add(item_buf);

		}//for  (int ii = 0; ii < (int) pv_files->size(); ii++)
		
	}//if  (i_result_index  <  0)
	else
	{
		pv_files->clear();

		c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(i_result_index)->eGetFiles
			(
			pc_fdb_root->sGetRootDir(),
			pc_fdb_root->pvGetNets()->at(i_net_index)->sGetNetDir(),
			pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->sGetConnDir(),
			pv_files
			);

		if  (c_err)
		{
			c_err.vShowWindow();
			return;		
		}//if  (c_err)

					
		for  (int ii = 0; ii < (int) pv_files->size(); ii++)
		{

			ListViewItem* item_buf  =  new ListViewItem(pv_files->at(ii));
			CString  s_buf;

			s_buf.Format("%d", ii);
			item_buf->SubItems->Add(s_buf);

			list_files->Items->Add(item_buf);

		}//for  (int ii = 0; ii < (int) pv_files->size(); ii++)

	}//else  if  (i_result_index  <  0)


}//void  CAddEditResult::v_refresh_files()




System::Void CAddEditResult::but_rem_file_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (i_selected_file_index  <  (int)  pv_files->size())&&(i_selected_file_index  >=  0) )
	{
		CError  c_err;

		FileInfo  *pc_fi;
		pc_fi  =  new  FileInfo(pv_files->at(i_selected_file_index));

		CString  s_buf;
		s_buf  =  pc_fi->Name;
		
		s_buf.Format("Are You sure You want to remove this file:'%s'?", (LPCSTR) s_buf);
		if  (::MessageBox(NULL,  s_buf, "Delete?", MB_YESNO)  ==  IDYES)  
		{
			if  (i_result_index  <  0)
			{
				pv_files->erase(pv_files->begin() + i_selected_file_index);
			}//if  (i_result_index  <  0)
			else
			{
				c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(i_result_index)->eRemoveFile
					(
					pc_fdb_root->sGetRootDir(),
					pc_fdb_root->pvGetNets()->at(i_net_index)->sGetNetDir(),
					pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->sGetConnDir(),
					pv_files->at(i_selected_file_index)
					);
				
			}//else  if  (i_result_index  <  0)

			v_refresh_files();			
		}//if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  

	}//if  (i_selected_index  <  i_fdb_len)
	else
	{
        ::MessageBox(NULL,"Unexpected error caused by wrong selection index."	, "Error", MB_OK);
	}//else  if  (i_selected_index  <  i_fdb_len)

}//System::Void CAddEditResult::but_rem_file_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CAddEditResult::but_add_file_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (File::Exists(text_chosen_file->Text)  ==  false)
	{
		c_err.vPutError("Proposed file does not exist!");
		c_err.vShowWindow();
		return;	
	}//if  (File::Exists(text_chosen_file->Text)  ==  false)

	if  (i_result_index  <  0)
	{
		bool  b_found;
		b_found  =  false;

		for  (int ii = 0; (ii < (int) pv_files->size())&&(b_found == false); ii++)
		{
			if  (pv_files->at(ii)  ==  (CString) text_chosen_file->Text)
				b_found  =  true;
		}//for  (int ii = 0; ii < (int) pv_files->size(); ii++)

		if  (b_found  ==  true)
		{
			c_err.vPutError("File already exist in the list");
			c_err.vShowWindow();
			return;		
		}//if  (b_found  ==  true)
		else
			pv_files->push_back(text_chosen_file->Text);
	}//if  (i_result_index  <  0)
	else
	{
		bool  b_found;
		b_found  =  false;

		FileInfo  *pc_fi;
		pc_fi  =  new  FileInfo(text_chosen_file->Text);

		for  (int ii = 0; (ii < (int) pv_files->size())&&(b_found == false); ii++)
		{
			if  (pv_files->at(ii)  ==  (CString) pc_fi->Name)
				b_found  =  true;
		}//for  (int ii = 0; ii < (int) pv_files->size(); ii++)

		if  (b_found  ==  true)
		{
			c_err.vPutError("File already exist in the list");
			c_err.vShowWindow();
			return;		
		}//if  (b_found  ==  true)
		else
		{
			c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(i_result_index)->eAddFile
				(
				pc_fdb_root->sGetRootDir(),
				pc_fdb_root->pvGetNets()->at(i_net_index)->sGetNetDir(),
				pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->sGetConnDir(),
				text_chosen_file->Text
				);

			if  (c_err)  c_err.vShowWindow();
		
		}//else  if  (b_found  ==  true)
	
	}//else  if  (i_result_index  <  0)

	v_refresh_files();
}//System::Void CAddEditResult::but_add_file_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CAddEditResult::but_find_file_Click(System::Object *  sender, System::EventArgs *  e)
{
	OpenFileDialog* openFileDialog1 = new OpenFileDialog();
 
	openFileDialog1->InitialDirectory = *ps_init_dir;
	openFileDialog1->Filter = "init files (*.ini)|*.ini|ini result (*.ini2)|*.ini2|data files (*.dat)|*.dat|full result (*.ful)|*.ful|short result (*.rep)|*.rep|virtual ways (*.vwd)|*.vwd|virtual ways stats (*.vws)|*.vws|All files (*.*)|*.*";
    openFileDialog1->FilterIndex = 8;
    openFileDialog1->RestoreDirectory = true;
	openFileDialog1->Multiselect  =  true;

    if(openFileDialog1->ShowDialog() == DialogResult::OK)
    {
		CString  s_buf;

		if  (openFileDialog1->FileNames->Count  >  1)
		{
			for  (int  ii = 0;  ii < openFileDialog1->FileNames->Count; ii++)
			{
				s_buf.Format("%s | %s", s_buf, openFileDialog1->FileNames[ii]);
			}//for  (int  ii = 0;  ii < openFileDialog1->FileNames->Count; ii++)
		}//if  (openFileDialog1->FileNames->Count  >  1)
		else
		{
			text_chosen_file->Text  =  openFileDialog1->FileName;

			FileInfo  *pc_fi  =  new  FileInfo(openFileDialog1->FileName);
			*ps_init_dir   =  pc_fi->DirectoryName;

			but_add_file_Click(sender, e);
		}//else  if  (openFileDialog1->FileNames->Count  >  1)

    }//if(openFileDialog1->ShowDialog() == DialogResult::OK)

}//System::Void CAddEditResult::but_find_file_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CAddEditResult::but_param_value_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  ( (comboAlgorithm->SelectedIndex  >=  (int)  pv_algorithms->size())||(comboAlgorithm->SelectedIndex < 0) )
	{
		c_err.vPutError("Wrong selection index");
		c_err.vShowWindow();
		return;	
	}//if  ( (comboAlgorithm->SelectedIndex  >=  (int)  pv_algorithms->size())||(comboAlgorithm->SelectedIndex < 0) )

	if  ( (i_selected_param_index  <  (int) pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->size())&&(i_selected_param_index  >=  0) )
	{
		double  d_param_val;
		CString  s_buf;

		s_buf  =  text_param_value->Text;

		d_param_val  =  atof((LPCSTR)s_buf);
		
		if  (i_result_index  <  0)
		{
			c_err  =  pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->at(i_selected_param_index)
				->eSetParamValue
				(
				d_param_val, -1
				);
		}//if  (i_result_index  <  0)
		else
		{
			c_err  =  pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->at(i_selected_param_index)
				->eSetParamValue
				(
				d_param_val, pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(i_result_index)->iGetId()
				);		
		}//else  if  (i_result_index  <  0)

		if  (c_err)
		{
			c_err.vShowWindow();
			return;		
		}//if  (c_err)

	
	}//if  ( (i_selected_param_index  <  (int) pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->size())&&(i_selected_param_index  >=  0) )
	else
	{
		c_err.vPutError("Wrong parameter index or no parameter selected");
		c_err.vShowWindow();
		return;
	}//else  if  ( (i_selected_param_index  <  (int) pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->size())&&(i_selected_param_index  >=  0) )

	v_refresh_parameters();
}//System::Void CAddEditResult::but_param_value_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CAddEditResult::but_generate_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	
	CString  s_buf;

	if  (i_result_index  <  0)
	{
		bool  b_found  =  false;
		for  (int  ii = 0; ii <  (int) pv_files->size(); ii++)
		{
			if  (pv_files->at(ii).GetLength() > 11)
			{
				if  (pv_files->at(ii).Find("settings.dat", pv_files->at(ii).GetLength() - 12)  >=  0)
				{
					b_found  =  true;
					s_buf  =  pv_files->at(ii);
				}//if  (pv_files->at(ii).Find("settings.dat", pv_files->at(ii).GetLength() - 11)  >=  0)
			}//if  (pv_files->at(ii).GetLength() >= 11)
		}//for  (int  ii = 0; ii <  (int) pv_files->size(); ii++)
		
		if  (b_found  ==  false)
		{
			CError  c_err;
			c_err.vPutError("No settings file");
			c_err.vShowWindow();
			return;		
		}//if  (b_found  ==  false)
	}//if  (i_result_index  <  0)
	else
	{
		s_buf.Format
			(
			"%s\\%s\\%s\\%s\\%s",
			pc_fdb_root->sGetRootDir(),
			pc_fdb_root->pvGetNets()->at(i_net_index)->sGetNetDir(),
			pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->sGetConnDir(),
			pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(i_result_index)->sGetResultDir(),
			"settings.dat"
			);

	}//else  if  (i_result_index  <  0)



	if  (File::Exists(s_buf))
	{
		CCOAlgorithm  *pc_alogrithm;
		
		pc_alogrithm  =  new  CCOAlgorithm(NULL);
		pc_system->vSetSqlConn(pc_alogrithm);
		
		vector <CString>  v_files;

		CCOResult  c_result(NULL);
		pc_system->vSetSqlConn(&c_result);


		c_err  =  pc_system->eLoadResultParamsFromFile
			(
			s_buf,
			pc_fdb_root,
			&v_files,
			pc_alogrithm,
			&c_result
			);

		if  (c_err)
		{
			delete  pc_alogrithm;
			c_err.vShowWindow();
			return;
		}//if  (c_err)
		else
		{
			int  i_id;
			int i_con_id, i_fit_id, i_alg_id, i_comp_id, i_rset_id;
			CString  s_res_dir, s_res_comments;
			double  d_fit_value;
			double  d_time;
			__int64  dt_generated;

			c_result.vGetData
				(
				&i_id,
				&i_con_id, &i_fit_id, &i_alg_id, &i_comp_id, &i_rset_id,
				&s_res_dir, &s_res_comments,
				&d_fit_value,
				&d_time,
				&dt_generated
				);

			if  (
				i_con_id  !=  
				pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->iGetId()
				)
			{
				delete  pc_alogrithm;
				c_err.vPutError("The connection file is different to the current one!");
				c_err.vShowWindow();
				return;			
			}//if  (
	

			//first we set algorithm
			bool  b_found;
			b_found  =  false;
			for  (int ii = 0;  (ii < (int) pv_algorithms->size())&&(b_found  ==  false); ii++)
			{
				if  (pv_algorithms->at(ii)->iGetId()  ==  pc_alogrithm->iGetId())
				{
					comboAlgorithm->SelectedIndex  =  ii;
					delete  pv_algorithms->at(ii);
					pv_algorithms->at(ii)  =  pc_alogrithm;
					v_refresh_parameters();

					b_found  =  true;
				}//if  (pv_algorithms->at(ii)->iGetId()  ==  pc_alogrithm->iGetId())
			
			}//for  (int ii = 0;  (ii < pv_algorithms->size())&&(b_found  ==  false); ii++)

			if  (b_found  ==  false)
			{
				delete  pc_alogrithm;
				c_err.vPutError("returned algorithm not found - reopen the window and try again");
				c_err.vShowWindow();
				return;				
			}//if  (b_found  ==  false)

			//second we add the files from settings file...
			CError  c_file_add_err;

			if  (i_result_index  <  0)
			{
				for  (int  ii = 0; ii < (int) v_files.size(); ii++)
				{
					b_found  =  false;

					for  (int ij = 0; (ij < (int) pv_files->size())&&(b_found == false); ij++)
					{
						if  (v_files.at(ii)  ==  pv_files->at(ij))
							b_found  =  true;
					}//for  (int ij = 0; (ij < (int) pv_files->size())&&(b_found == false); ij++)

					if  (b_found  ==  true)
					{
						s_buf.Format("File already exist in the list (%s)", pv_files->at(ii));
						c_file_add_err.vPutError(s_buf);
					}//if  (b_found  ==  true)
					else
						pv_files->push_back(v_files.at(ii));

					if  (c_file_add_err)  c_file_add_err.vShowWindow();
				}//for  (int  ii = 0; ii < (int) v_files.size(); ii++)
			
			}//if  (i_result_index  <  0)
			else
			{
				for  (int  ii = 0; ii < (int) v_files.size(); ii++)
				{
					c_file_add_err  =  
						pc_fdb_root->pvGetNets()->at(i_net_index)->
						pvGetNetConns()->at(i_conn_index)->
						pvGetResults()->at(i_result_index)->eAddFile
							(
							pc_fdb_root->sGetRootDir(),
							pc_fdb_root->pvGetNets()->at(i_net_index)->sGetNetDir(),
							pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->sGetConnDir(),
							v_files.at(ii)							
							);

					if  (c_file_add_err)  c_file_add_err.vShowWindow();
				}//for  (int  ii = 0; ii < (int) v_files.size(); ii++)
			}//else  if  (i_result_index  <  0)

			v_refresh_files();

			//third - refresh algorithm parameters
			
			b_found  =  false;
			for  (int  ii = 0; ii < (int) pv_ffuncs->size(); ii++)
			{
				if  (pv_ffuncs->at(ii)->iGetId()  ==  i_fit_id)
				{
					comboFFunc->SelectedIndex  =  ii;
					b_found  =  true;
				}//if  (pv_ffuncs->at(ii)->iGetId()  ==  i_fit_id)
			}//for  (int  ii = 0; pv_ffuncs->size(); ii++)

			if  (b_found  ==  false)
			{
				CString  s_buf;
				s_buf.Format("Fitness function with id: %d not found - try reopening the window", i_fit_id);
				c_err.vPutError(s_buf);
				c_err.vShowWindow();			
			}//if  (b_found  ==  false)
			
			s_buf.Format("%.16lf", d_fit_value);
			text_ff_val->Text  =  s_buf;

			s_buf.Format("%.6lf", d_time);
			textTime->Text  =  s_buf;

			System::DateTime  dt_buf;
			dt_buf  =  System::DateTime::FromFileTime(dt_generated);

			dtpDate->Value  =  dt_buf;
			dtpTime->Value  =  dt_buf;


		}//else  if  (c_err)
	}//if  (File::Exists(s_buf))
	else
	{
		c_err.vPutError("settings.dat file not found");
		c_err.vShowWindow();
		return;			
	}//else  if  (File::Exists(s_buf))
	
}//System::Void CAddEditResult::but_generate_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CAddEditResult::butOk_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (pc_fdb_root  ==  NULL)
	{
		c_err.vPutError("No fdb root assigned");
		c_err.vShowWindow();
		return;
	}//if  (pc_fdb_root  ==  NULL)

	if  (i_net_index  <  0)
	{
		c_err.vPutError("No net index given!");
		c_err.vShowWindow();
		Close();
		return;
	}//if  (pc_fdb_root  ==  NULL)

	if  (i_conn_index  <  0)
	{
		c_err.vPutError("No connection configuration index given!");
		c_err.vShowWindow();
		Close();
		return;
	}//if  (pc_fdb_root  ==  NULL)


	if  ( (comboAlgorithm->SelectedIndex  >=  (int)  pv_algorithms->size())||(comboAlgorithm->SelectedIndex < 0) )
	{
		c_err.vPutError("Wrong algorithm selection index or no algorithm selected");
		c_err.vShowWindow();
		return;	
	}//if  ( (comboAlgorithm->SelectedIndex  >=  (int)  pv_algorithms->size())||(comboAlgorithm->SelectedIndex < 0) )

	if  ( (comboComput->SelectedIndex  >=  (int)  pv_computers->size())||(comboComput->SelectedIndex < 0) )
	{
		c_err.vPutError("Wrong computer selection index or no computer selected");
		c_err.vShowWindow();
		return;	
	}//if  ( (comboComput->SelectedIndex  >=  (int)  pv_computers->size())||(comboComput->SelectedIndex < 0) )

	if  ( (comboRSets->SelectedIndex - 1 >=  (int)  pv_rsets->size())||(comboRSets->SelectedIndex < 0) )
	{
		c_err.vPutError("Wrong results set selection index or no results set selected");
		c_err.vShowWindow();
		return;	
	}//if  ( (comboComput->SelectedIndex  >=  (int)  pv_computers->size())||(comboComput->SelectedIndex < 0) )

	if  ( (comboFFunc->SelectedIndex  >=  (int)  pv_ffuncs->size())||(comboFFunc->SelectedIndex < 0) )
	{
		c_err.vPutError("Wrong fitness function selection index or no fitness function selected");
		c_err.vShowWindow();
		return;	
	}//if  ( (comboComput->SelectedIndex  >=  (int)  pv_computers->size())||(comboComput->SelectedIndex < 0) )

	
	//now loading data from window
	int  i_comp_id, i_ff_id, i_rset_id;
	double  d_ff_val;
	double  d_time_in_secs;
	CString  s_comments;
	__int64  dt_generated;

	CString  s_buf;


	i_comp_id  =  pv_computers->at(comboComput->SelectedIndex)->iGetId();
	i_ff_id  =  pv_ffuncs->at(comboFFunc->SelectedIndex)->iGetId();

	if  (comboRSets->SelectedIndex  ==  0)
		i_rset_id  =  -1;
	else
		i_rset_id  =  pv_rsets->at(comboRSets->SelectedIndex - 1)->iGetId();

	
	s_buf  =  text_ff_val->Text;
	d_ff_val  =  atof((LPCSTR)  s_buf);

	s_buf  =  textTime->Text;
	d_time_in_secs  =  atof((LPCSTR)  s_buf);
	s_comments  =  text_comments->Text;


	System::DateTime  dt_buf;
	dt_buf  =  dtpDate->Value.Date;
	dt_buf  =  dt_buf.AddHours(dtpTime->Value.Hour);
	dt_buf  =  dt_buf.AddMinutes(dtpTime->Value.Minute);
	dt_buf  =  dt_buf.AddSeconds(dtpTime->Value.Second);

	dt_generated  =  dt_buf.ToFileTime();

	if  (i_result_index  <  0)
	{
		//ADDING NEW RESULT
		c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->
			eAddResult
			(
			pc_fdb_root->sGetRootDir(), pc_fdb_root->pvGetNets()->at(i_net_index)->sGetNetDir(),
			i_ff_id, i_comp_id, i_rset_id,
			s_comments,
			d_ff_val, 
			d_time_in_secs, dt_generated,
			pv_files, pv_algorithms->at(comboAlgorithm->SelectedIndex)
			);
	}//if  (i_net_index  <  0)
	else
	{
		
		c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(i_result_index)->eUpdate
				(
				pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->iGetId(),
				i_ff_id, pv_algorithms->at(comboAlgorithm->SelectedIndex)->iGetId(), i_comp_id, i_rset_id, 
				pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(i_result_index)->sGetResultDir(),
				text_comments->Text,
				d_ff_val,  d_time_in_secs,
				dt_generated
				);

		if  (c_err  ==  false)
		{
			c_err  =  pv_algorithms->at(comboAlgorithm->SelectedIndex)->eUpdateParamsForResult
				(
				pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(i_result_index)->iGetId()
				);
		}//if  (c_err  ==  false)
			
	}//else  if  (i_net_index  <  0)

	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)

	DialogResult  =  DialogResult::OK;

}//System::Void CAddEditResult::butOk_Click(System::Object *  sender, System::EventArgs *  e)



void  CAddEditResult::v_refresh_parameters()
{
	CError  c_err;

	i_selected_param_index  =  -1;

	if  ( (comboAlgorithm->SelectedIndex  >=  (int)  pv_algorithms->size())||(comboAlgorithm->SelectedIndex < 0) )
	{
		c_err.vPutError("Wrong selection index");
		c_err.vShowWindow();
		return;	
	}//if  ( (comboAlgorithm->SelectedIndex  >=  (int)  pv_algorithms->size())||(comboAlgorithm->SelectedIndex < 0) )


	int  i_id;
	int  i_alg_id;
	CString  s_param_name;
	double  d_param_default;

    list_params->Items->Clear();
	for  (int ii = 0;  ii < (int) pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->size(); ii++)
	{
		pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->at(ii)->vGetData
			(
			&i_id,
			&i_alg_id,
			&s_param_name,
			&d_param_default
			);


		ListViewItem* item_buf  =  new ListViewItem((String *) s_param_name);
		CString  s_buf;

		s_buf.Format("%lf", pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->at(ii)->dGetParamValue());
		item_buf->SubItems->Add(s_buf);

		s_buf.Format("%lf", d_param_default);
		item_buf->SubItems->Add(s_buf);
		
		s_buf.Format("%d", ii);
		item_buf->SubItems->Add(s_buf);

		list_params->Items->Add(item_buf);
		
	}//for  (int ii = 0;  ii < (int) pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->size(); ii++)



}//void  CAddEditResult::v_refresh_parameters()


System::Void CAddEditResult::comboAlgorithm_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  ( (comboAlgorithm->SelectedIndex  >=  (int)  pv_algorithms->size())||(comboAlgorithm->SelectedIndex < 0) )
	{
		c_err.vPutError("Wrong selection index");
		c_err.vShowWindow();
		return;	
	}//if  ( (comboAlgorithm->SelectedIndex  >=  (int)  pv_algorithms->size())||(comboAlgorithm->SelectedIndex < 0) )


	c_err  =  pv_algorithms->at(comboAlgorithm->SelectedIndex)->eRefreshParams();
	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)

	v_refresh_parameters();
	
}//System::Void CAddEditResult::comboAlgorithm_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)



System::Void CAddEditResult::list_files_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_files->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_files->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_files->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_files->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_files->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_files->ListViewItemSorter  !=  NULL)
	else
		list_files->ListViewItemSorter = new list_item_comparer(e->Column);

}//System::Void CAddEditResult::list_files_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)


System::Void CAddEditResult::list_files_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	but_rem_file_Click(sender, e);
}//System::Void CAddEditResult::list_files_DoubleClick(System::Object *  sender, System::EventArgs *  e)


System::Void CAddEditResult::list_files_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	CError  c_err;

	ListViewItem *pc_selected = list_files->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {

		i_selected_file_index
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);

		if  ( (i_selected_file_index  <  (int) pv_files->size())&&(i_selected_file_index  >=  0) )
		{

		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_file_index  =  -1;
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)

}//System::Void CAddEditResult::list_files_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)



System::Void CAddEditResult::list_params_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_params->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_params->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_params->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_params->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_params->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_params->ListViewItemSorter  !=  NULL)
	else
		list_params->ListViewItemSorter = new list_item_comparer(e->Column);

}//System::Void CAddEditResult::list_params_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)



System::Void CAddEditResult::list_params_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	CError  c_err;

	ListViewItem *pc_selected = list_params->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		if  ( (comboAlgorithm->SelectedIndex  >=  (int)  pv_algorithms->size())||(comboAlgorithm->SelectedIndex < 0) )
		{
			c_err.vPutError("Wrong selection index");
			c_err.vShowWindow();
			return;	
		}//if  ( (comboAlgorithm->SelectedIndex  >=  (int)  pv_algorithms->size())||(comboAlgorithm->SelectedIndex < 0) )


		i_selected_param_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);

		if  ( (i_selected_param_index  <  (int) pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->size())&&(i_selected_param_index  >=  0) )
		{
			double  d_param_val;
			CString  s_buf;

			d_param_val  =
				pv_algorithms->at(comboAlgorithm->SelectedIndex)->pvGetParams()->at(i_selected_param_index)->dGetParamValue();

			s_buf.Format("%lf", d_param_val);
			text_param_value->Text  =  (String *) s_buf;
		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_param_index  =  -1;
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)
}//System::Void CAddEditResult::list_params_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)



void  CAddEditResult::v_refresh_dropdowns()
{
	CError  c_err;
	CString  s_select_sql;



	//results sets
	for  (int ii = 0; ii < (int) pv_rsets->size(); ii++)
		delete  pv_rsets->at(ii);
	pv_rsets->clear();
	comboRSets->Items->Clear();

	s_select_sql  =  "Select * from results_sets";
	c_err  =  pc_system->eSelectResultsSets(pv_rsets, s_select_sql);

	if  (c_err)
	{
		c_err.vShowWindow();
        Close();
		return;
	}//if  (c_err)

	int  i_rset_id;
	CString  s_rset_name;
	CString  s_rset_comments;

	comboRSets->Items->Add((String *) NO_RESULTS_SET_SELECTED);	
	for  (int ii = 0; ii < (int) pv_rsets->size(); ii++)
	{
		pv_rsets->at(ii)->vGetData
			(
			&i_rset_id,
			&s_rset_name,
			&s_rset_comments
			);

		comboRSets->Items->Add((String *) s_rset_name);	
	}//for  (int ii = 0; ii < (int) pv_computers->size(); ii++)



	//computers
	for  (int ii = 0; ii < (int) pv_computers->size(); ii++)
		delete  pv_computers->at(ii);
	pv_computers->clear();
	comboComput->Items->Clear();

	s_select_sql  =  "Select * from computers";
	c_err  =  pc_system->eSelectComputers(pv_computers, s_select_sql);

	if  (c_err)
	{
		c_err.vShowWindow();
        Close();
		return;
	}//if  (c_err)

	int  i_comp_id;
	CString  s_comp_name;
	CString  s_comp_comments;

	for  (int ii = 0; ii < (int) pv_computers->size(); ii++)
	{
		pv_computers->at(ii)->vGetData
			(
			&i_comp_id,
			&s_comp_name,
			&s_comp_comments
			);

		comboComput->Items->Add((String *) s_comp_name);	
	}//for  (int ii = 0; ii < (int) pv_computers->size(); ii++)




	//algorithms
	for  (int ii = 0; ii < (int) pv_algorithms->size(); ii++)
		delete  pv_algorithms->at(ii);
	pv_algorithms->clear();
	comboAlgorithm->Items->Clear();

	s_select_sql  =  "Select * from algorithms";
	c_err  =  pc_system->eSelectAlgorithms(pv_algorithms, s_select_sql);

	if  (c_err)
	{
		c_err.vShowWindow();
        Close();
		return;
	}//if  (c_err)

	int  i_alg_id;
	CString  s_alg_name;
	CString  s_alg_comments;

	for  (int ii = 0; ii < (int) pv_algorithms->size(); ii++)
	{
		pv_algorithms->at(ii)->vGetData
			(
			&i_alg_id,
			&s_alg_name,
			&s_alg_comments
			);

		comboAlgorithm->Items->Add((String *) s_alg_name);
	}//for  (int ii = 0; ii < (int) pv_computers->size(); ii++)




	//ffuncs
	for  (int ii = 0; ii < (int) pv_ffuncs->size(); ii++)
		delete  pv_ffuncs->at(ii);
	pv_ffuncs->clear();
	comboFFunc->Items->Clear();

	s_select_sql  =  "Select * from fit_func";
	c_err  =  pc_system->eSelectFitFuncs(pv_ffuncs, s_select_sql);

	if  (c_err)
	{
		c_err.vShowWindow();
        Close();
		return;
	}//if  (c_err)

	int  i_ff_id;
	CString  s_ff_name;
	CString  s_ff_comments;

	for  (int ii = 0; ii < (int) pv_ffuncs->size(); ii++)
	{
		pv_ffuncs->at(ii)->vGetData
			(
			&i_ff_id,
			&s_ff_name,
			&s_ff_comments
			);

		comboFFunc->Items->Add((String *) s_ff_name);
	}//for  (int ii = 0; ii < (int) pv_computers->size(); ii++)


};//void  CAddEditResult::v_refresh_dropdowns()



