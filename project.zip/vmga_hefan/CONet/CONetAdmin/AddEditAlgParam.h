#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for AddEditAlgParam
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CAddEditAlgParam : public System::Windows::Forms::Form
	{
	public: 
		CAddEditAlgParam(void)
		{
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}

	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::Label *  label1;

	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::Button *  butOk;
	public: System::Windows::Forms::TextBox *  textAlgParamName;
	public: System::Windows::Forms::TextBox *  textAlgParamDefault;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->textAlgParamName = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->label1 = new System::Windows::Forms::Label();
			this->textAlgParamDefault = new System::Windows::Forms::TextBox();
			this->butCancel = new System::Windows::Forms::Button();
			this->butOk = new System::Windows::Forms::Button();
			this->SuspendLayout();
			// 
			// textAlgParamName
			// 
			this->textAlgParamName->Location = System::Drawing::Point(32, 40);
			this->textAlgParamName->Name = S"textAlgParamName";
			this->textAlgParamName->Size = System::Drawing::Size(304, 20);
			this->textAlgParamName->TabIndex = 35;
			this->textAlgParamName->Text = S"";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(16, 16);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(92, 16);
			this->label2->TabIndex = 34;
			this->label2->Text = S"Parameter name:";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(16, 80);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(73, 16);
			this->label1->TabIndex = 33;
			this->label1->Text = S"Default value:";
			// 
			// textAlgParamDefault
			// 
			this->textAlgParamDefault->Location = System::Drawing::Point(32, 104);
			this->textAlgParamDefault->Name = S"textAlgParamDefault";
			this->textAlgParamDefault->Size = System::Drawing::Size(304, 20);
			this->textAlgParamDefault->TabIndex = 36;
			this->textAlgParamDefault->Text = S"";
			// 
			// butCancel
			// 
			this->butCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->butCancel->Location = System::Drawing::Point(304, 152);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 38;
			this->butCancel->Text = S"Cancel";
			// 
			// butOk
			// 
			this->butOk->Location = System::Drawing::Point(216, 152);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 37;
			this->butOk->Text = S"OK";
			this->butOk->Click += new System::EventHandler(this, &CAddEditAlgParam::butOk_Click);
			// 
			// CAddEditAlgParam
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(392, 189);
			this->Controls->Add(this->butCancel);
			this->Controls->Add(this->butOk);
			this->Controls->Add(this->textAlgParamDefault);
			this->Controls->Add(this->textAlgParamName);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = S"CAddEditAlgParam";
			this->Text = S"AddEditAlgParam";
			this->ResumeLayout(false);

		}		
	private: System::Void butOk_Click(System::Object *  sender, System::EventArgs *  e)
			 {
				 DialogResult  =  DialogResult::OK;
				 Close();
			 }

};
};//namespace CONetAdmin