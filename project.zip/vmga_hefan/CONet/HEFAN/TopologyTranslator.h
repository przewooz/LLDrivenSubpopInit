#pragma once


//tools
#include  "atlstr.h"  //CString
#include <windows.h>


//system tools
#include  "list.h"

//net components...
#include  "NETsimulator.h"

//vector
#include  <vector>
#include  <iostream>

using namespace std;
using  namespace  NETsimulator;




namespace  TopologyTranslator
{


	class  CTopologyTranslator;



	class  CFOMfunction
	{

	public:

		CFOMfunction() {};
		virtual  ~CFOMfunction() {};


		virtual  CString  sGetName()  {return("no function");};

		virtual  double  dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure)  {return(0);};//penalty is used when we allow for the capacity extending

		double  dEvalNumber()  {return(d_ffe);};

	//	virtual  int     iLoadWeights(CString  sFileName) {return(0);};


	protected:
		double  d_ffe;



	};//class  CFOMfunction






	class  CFOMfunctionWeight  :  public  CFOMfunction
	{

	public:

		CFOMfunctionWeight();
		~CFOMfunctionWeight();

		int     iLoadWeights(CString  sFileName,  CTopologyTranslator  *pcTranslator);




		CString  sGetName()  {return("weight function");};

		double  dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure);
		

	private:

		
		double  *pd_nodes_weights;
		double  *pd_links_weights;	



	};//class  CFOMfunctionWeight











	class  CFOMfunctionLFN  :  public  CFOMfunction
	{

	public:

		CFOMfunctionLFN();
		~CFOMfunctionLFN();

		

		CString  sGetName()  {return("lfn function");};

		double  dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure);
		

	private:

		
	};//class  CFOMfunctionWeight




	class  CFOMfunctionLFL  :  public  CFOMfunction
	{

	public:

		CFOMfunctionLFL();
		~CFOMfunctionLFL();

		

		CString  sGetName()  {return("lfl function");};

		double  dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure);
		

	private:

		
	};//class  CFOMfunctionWeight













	class  CFOMfunctionMinAvaibleCapacity  :  public  CFOMfunction
	{

	public:

		CFOMfunctionMinAvaibleCapacity();
		~CFOMfunctionMinAvaibleCapacity();

		

		CString  sGetName()  {return("min_av_capacity function");};

		double  dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure);
		

	private:

		
		CTopologyTranslator  *pc_translator;


	};//class  CFOMfunctionWeight






	class  CFOMfunctionIncrDemandConstrSatisf  :  public  CFOMfunction
	{

	public:

		CFOMfunctionIncrDemandConstrSatisf();
		~CFOMfunctionIncrDemandConstrSatisf();

		

		CString  sGetName()  {return("constraint_satisfaction increasing demand function");};

		double  dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure);
		

	private:

		
		CTopologyTranslator  *pc_translator;


	};//class  CFOMfunctionWeight
















	class  CTopologyTranslator
	{

	public:


		int  iLoadTopologyFile(CString  sFileName,  CString  *psComment);
		int  iSetFOMfunction(CString  sFuncName,  CString  sFileName = "");
		int  iCreateReportFile(CString  sFileName)  {return(pc_net_model->iPresentNetwork(sFileName));};
		void vPresentNetwork(FILE  *pfDestFile,  bool  bActualState) {pc_net_model->vPresentNetwork(pfDestFile, bActualState);};
		int  iCreateBasicVirtualDatabaseFile(CString  sFileName)  
						{return(pc_net_model->iCreateBasicVirtualDatabaseFile(sFileName));};

		bool  bAllowCapacityOverloading(bool  bAllow)  {return(pc_net_model->bAllowCapacityOverloading(bAllow));};
		void  vTurnConnectionCheck(bool  bOnOff)  {pc_net_model->vTurnConnectionCheck(bOnOff);};


		double  dCountFom(long  lPenalty, bool  *pbCapacityExtending); 


		long  lGetNumberOfNodes()  {return(l_number_of_nodes);};
		long  lTranslateNodeNum(long  lNodeNum);//takes "our" node number and returns modelling system one
		long  lGetNumberOfLinks()  {return(l_number_of_links);};
		long  lTranslateLinkNum(long  lLinkNum);//takes "our" link number and returns modelling system one
		long  lFindLinkIdForNodes(long  lStartNodeId,  long  lFinishNodeId,  bool  bTranslate);
			


		int  iCheckConnection(long  *plWay, int  iWayLength, long  lCapacity, bool bCheckActualCapacity = true)
			{return(pc_net_model->iCheckConnection(plWay, iWayLength, lCapacity, bCheckActualCapacity));};

		long  lSetUpConnection(long  *plWay, int  iWayLength, long  lCapacity)
			{return(pc_net_model->lSetUpConnection(plWay, iWayLength, lCapacity));};

		int   iRemoveConnection(long  lConnectionId)
			{return(pc_net_model->iRemoveConnection(lConnectionId));};
		int   iRemoveAllConnections()
			{return(pc_net_model->iRemoveAllConnections());};


		long  lGetActNodeCapacity(long  lNodeId)  {return(pc_net_model->lGetActNodeCapacity(lNodeId));};
		long  lGetActLinkCapacity(long  lLinkId)  {return(pc_net_model->lGetActLinkCapacity(lLinkId));};
		long  lGetMaxNodeCapacity(long  lNodeId)  {return(pc_net_model->lGetMaxNodeCapacity(lNodeId));};
		long  lGetMaxLinkCapacity(long  lLinkId)  {return(pc_net_model->lGetMaxLinkCapacity(lLinkId));};


		double  dCountNodeLFN(long  lNodeId,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure)  {return(pc_net_model->dCountNodeLFN(lNodeId,  lPenalty, pbCapacityExtending, pdFitnessPure, pdPenaltyPure));};
		double  dCountNodeLFL(long  lNodeId,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure)  {return(pc_net_model->dCountNodeLFL(lNodeId,  lPenalty, pbCapacityExtending, pdFitnessPure, pdPenaltyPure));};

		
		
		CTopologyTranslator();
		~CTopologyTranslator();
	
		//new methods for CONetAdmin
		CNETsimulator  *pcGetSim()  {return(pc_net_model);};


		static  long  lReadComments(CString  sFileName, FILE **pfFile, CString  *psComments);

		int  iGetShortestWays(int  iShortestWaysNumber, vector <long *> *pvWays, vector <long> *pvWaysLenghts)
			{return(pc_net_model->iGetShortestWays(iShortestWaysNumber, pvWays, pvWaysLenghts));};
		int  iGetShortestWaysForNodes(int iStartNodeId, int iFinishNodeId, int  iShortestWaysNumber, vector <long *> *pvWays, vector <long> *pvWaysLenghts)
			{return(pc_net_model->iGetShortestWaysForNodes(iStartNodeId, iFinishNodeId, iShortestWaysNumber, pvWays, pvWaysLenghts));};

		CFOMfunction  *pcGetFittnesCounter()  {return(pcFOMcounter);};


	private:

		
		//tool method for node and link inputation
		int   i_read_one_node(FILE  *pfSource,  long *plActualLinkNumber);
		long  l_count_number_of_links(CString  sFileName);
		

		long  l_number_of_nodes;
		long  *pl_nodes_rename_table;//contains pairs [TFinderNodeNumber, NETsimulatorNumber]
		double  *pd_nodes_weights;


		long  l_number_of_links;
		long  *pl_links_rename_table;//contains pairs [TFinderLinkNumber, NETsimulatorNumber]
		double  *pd_links_weights;
		

		CNETsimulator  *pc_net_model;

		CFOMfunction  *pcFOMcounter;

	};//class  CTopologyTranslator

};//namespace  TopologyTranslator