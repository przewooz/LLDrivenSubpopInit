

#include  "stdafx.h"
#include  "TopologyTranslator.h"


using namespace TopologyTranslator;


#pragma warning(disable:4996)






CTopologyTranslator::CTopologyTranslator()
{

	pl_nodes_rename_table  =  NULL;
	pl_links_rename_table  =  NULL;

	pd_nodes_weights  =  NULL;
	pd_links_weights  =  NULL;


	pcFOMcounter  =  NULL;

	pc_net_model  =  new  CNETsimulatorSimplyfied;


}//CTopologyTranslator::CTopologyTranslator()







CTopologyTranslator::~CTopologyTranslator()
{

	if  (pl_nodes_rename_table  !=  NULL)
		delete  []  pl_nodes_rename_table;

	if  (pl_links_rename_table  !=  NULL)
		delete  []  pl_links_rename_table;

	if  (pd_nodes_weights  !=  NULL)
		delete  []  pd_nodes_weights;

	if  (pd_links_weights  !=  NULL)
		delete  []  pd_links_weights;


	if  (pc_net_model  !=  NULL)  delete  pc_net_model; 
	
	if  (pcFOMcounter  !=  NULL)  delete  pcFOMcounter;

}//CTopologyTranslator::~CTopologyTranslator()






/*
returned values:
1  -  ok
0  -  file not found
-1 -  unexpected end of file
-2 -  memory allocation problems
-3 -  node creation unsuccessfull
-4 - not enough nodes or wrong file format
*/
int  CTopologyTranslator::iLoadTopologyFile(CString  sFileName,  CString  *psComments)
{

	FILE  *pf_source;

	


	//before we really start we have to count the number of links in the net
	l_number_of_links  =  l_count_number_of_links(sFileName);

	if  (l_number_of_links  <=  0)  return(-4);

	
	//if the number of links is properly found we create the links rename table
	if  (pl_links_rename_table  !=  NULL)  delete  []  pl_links_rename_table;
	pl_links_rename_table  =  new  long[l_number_of_links * 2];

	if  (pl_links_rename_table  ==  NULL)  return(-2);


	


	if  (lReadComments(sFileName,  &pf_source,  psComments) == -1)  return(0);


	if  (feof(pf_source)  ==  0)
		fscanf(pf_source,"%ld", &l_number_of_nodes);
	else
		return(10);



	
	//now when we have the number of nodes we input them into the web and
	//create the nodes rename table
	if  (pl_nodes_rename_table  !=  NULL)  delete  [] pl_nodes_rename_table;

	pl_nodes_rename_table  =  new  long[l_number_of_nodes * 2];
	if  (pl_nodes_rename_table  ==  0)  return(-2);


	for  (long  li = 0; li < l_number_of_nodes; li++)
	{

		pl_nodes_rename_table[li * 2]  =  li + 1;
		pl_nodes_rename_table[li * 2 + 1]  =  pc_net_model->lAddNewNode(0,"");

		if  (pl_nodes_rename_table[li * 2 + 1]  ==  -1)  return(-3);

	}//for  (long  li = 0; li < l_number_of_nodes; li++)





	//before we start to create links we must create a tool for enumarating them...
	long  l_link_number = 1;

	for  (long  li = 0; li < l_number_of_nodes; li++)
	{

		if  (i_read_one_node(pf_source, &l_link_number)  ==  10)  return(-1);
	
	}//for  (long  li = 0; li < l_number_of_nodes)




	fclose(pf_source);


	//pc_net_model->iPresentNetwork("networkCheck.dat");


	return(1);

}//int  CTopologyTranslator::iLoadTopologyFile(CString  sFileName)







long  CTopologyTranslator::lReadComments(CString  sFileName, FILE **pfFile, CString  *psComments)
{
	
	char  c_buf;
	int  i_num_of_comm_lines  =  0;
	bool  b_comment;
	

	*pfFile  =  fopen( (LPCSTR)  sFileName, "r+");
	if  (*pfFile  ==  NULL)  return(-1);

	b_comment  =  true;

	while  (b_comment  ==  true)
	{
		b_comment  =  false;

		fscanf(*pfFile,"%c", &c_buf);
		if  (c_buf  ==  '/')
		{
			fscanf(*pfFile,"%c", &c_buf);
			if  (c_buf  ==  '/')
			{
				b_comment  =  true;
				i_num_of_comm_lines++;

				for  (;c_buf  !=  '\n';)
				{
					fscanf(*pfFile,"%c", &c_buf);
					if  (c_buf  !=  '\n')  
						*psComments  +=  c_buf;
					else
					{
						c_buf  =  13;
						*psComments  +=  c_buf;
						c_buf  =  10;
						*psComments  +=  c_buf;					
					}//else  if  (c_buf  !=  '\n')  

				}//for  (;c_buf  !=  '\n';)
			
			}//if  (c_buf  ==  '/')	
		}//if  (c_buf  ==  '/')
	}//while  (b_comment  ==  true)

	fclose(*pfFile);

	*pfFile  =  fopen( (LPCSTR)  sFileName, "r+");
	while  (i_num_of_comm_lines  >  0)
	{
		c_buf  =  'a';
		for  (;c_buf  !=  '\n';)  fscanf(*pfFile,"%c", &c_buf);
		i_num_of_comm_lines--;	
	}//while  (i_num_of_comm_lines  >  0)
	
}//void  CTopologyTranslator::v_read_comments(CString  *psComments)


/*
returned values:
1  -  ok
10 -  unexpected end of file
-3 - link creation process unsuccessfull
-4 - node capacity setting unsuccessfull
-5 - node number for link creation is not valid
-6 - unexpected link number (link number is too big)
*/
int  CTopologyTranslator::i_read_one_node(FILE  *pfSource,  long *plActualLinkNumber)
{
	
	long  l_node_number;
	int   i_connected_nodes;

	long  l_connected_node_num;
	long  l_link_capacity;

	long  l_new_link_id;




	//initialization of data
	if  (feof(pfSource)  ==  0)
		fscanf(pfSource, "%ld",  &l_node_number);
	else
		return(10);


	if  (feof(pfSource)  ==  0)
		fscanf(pfSource, "%d",  &i_connected_nodes);
	else
		return(10);


//	printf("Node number:%ld\n", l_node_number);
//	printf("Number of connected nodes:%d\n",i_connected_nodes);

	
	//node and link creating
	long  l_summary_capacity = 0;
	for  (int  ii = 0; ii < i_connected_nodes; ii++)
	{

		if  (feof(pfSource)  ==  0)
			fscanf(pfSource, "%ld",  &l_connected_node_num);
		else
			return(10);


//		printf("Connected node num:%ld\n",l_connected_node_num);



		if  (feof(pfSource)  ==  0)
			fscanf(pfSource, "%ld",  &l_link_capacity);
		else
			return(10);


//		printf("Connected node link capacity:%ld\n",l_link_capacity);


		
		//now we create a proper links
		if  (
			(l_node_number - 1  <  l_number_of_nodes)&&
			(l_connected_node_num - 1  <  l_number_of_nodes)
			)
		{
			l_new_link_id  =  
				pc_net_model->lCreateLink(
					pl_nodes_rename_table[(l_node_number - 1) * 2 + 1],
					pl_nodes_rename_table[(l_connected_node_num - 1) * 2 + 1],
					l_link_capacity);

			if  (l_new_link_id  <  0)  return(-3);

			if  (*plActualLinkNumber - 1 >=  l_number_of_links)  return(-6);

			pl_links_rename_table[(*plActualLinkNumber - 1)* 2]  =  *plActualLinkNumber;
			pl_links_rename_table[(*plActualLinkNumber - 1)* 2 + 1]  =  l_new_link_id;

			(*plActualLinkNumber)++;

		}//if
		else
			return(-5);

		
		l_summary_capacity  +=  l_link_capacity;

	
	}//for  (int  ii = 0; ii < i_connected_nodes; ii++)


	l_summary_capacity  *=  2;


	//now we must set the node capactiy so this is able to maintain all links
	if  (
		pc_net_model->iSetNodeCapacity(
			pl_nodes_rename_table[(l_node_number - 1) * 2 + 1],
			l_summary_capacity)
		!=
		1
		)
		return(-4);



//	printf("\n\n");



	return(1);

}//int  CTopologyTranslator::i_read_one_node(FILE  pfSource)












/*
returnde values:
1  -  ok
0  -  couldn't open the given file
-1 -  unexpected end of file
-2 -  bad number of nodes
-3 -  memory allocation problems
-4 -  bad FOM function name 
*/
int  CTopologyTranslator::iSetFOMfunction(CString  sFuncName,  CString  sFileName)
{
	
	if  (pcFOMcounter  !=  NULL)  delete  pcFOMcounter;



	if  (sFuncName  ==  "weight")
	{
		pcFOMcounter  =  new  CFOMfunctionWeight();

		if  (pcFOMcounter  ==  NULL)  return(-3);

		return( ((CFOMfunctionWeight *)  pcFOMcounter)->iLoadWeights(sFileName, this) );

	}//if  (sFuncName  ==  "weight")




	if  (sFuncName  ==  "LFN")
	{

		pcFOMcounter  =  new  CFOMfunctionLFN();

		if  (pcFOMcounter  ==  NULL)  return(-3);

		return(1);
	
	}//if  (sFuncName  ==  "lfn")


	if  (sFuncName  ==  "LFL")
	{

		pcFOMcounter  =  new  CFOMfunctionLFL();

		if  (pcFOMcounter  ==  NULL)  return(-3);

		return(1);
	
	}//if  (sFuncName  ==  "lfn")




	if  (sFuncName  ==  "MWP")
	{

		pcFOMcounter  =  new  CFOMfunctionMinAvaibleCapacity();

		if  (pcFOMcounter  ==  NULL)  return(-3);

		return(1);
	
	}//if  (sFuncName  ==  "lfn")




	if  (sFuncName  ==  "ConstSatIncrDemand")
	{

		pcFOMcounter  =  new  CFOMfunctionIncrDemandConstrSatisf();
		pc_net_model->vSetConstSatIncrDemands(true);

		if  (pcFOMcounter  ==  NULL)  return(-3);

		return(1);
	
	}//if  (sFuncName  ==  "lfn")


	
	return(-4);

}//int  CTopologyTranslator::iLoadPrices(CString  sFileName)













double  CTopologyTranslator::dCountFom(long  lPenalty,  bool  *pbCapacityExtending)
{
	double  d_buf, d_buf2;

	if  (pcFOMcounter  !=  NULL)
		return(pcFOMcounter->dCountFOM(pc_net_model,  lPenalty, pbCapacityExtending, &d_buf, &d_buf2));
	else
		return(0);
}//double  CTopologyTranslator::dCountFom()















/*
returned values:
0 and more - number of links in the topology
-1 -  file not found
-2 -  unexpected end of file

*/
long  CTopologyTranslator::l_count_number_of_links(CString  sFileName)
{

	FILE  *pf_source;
	CString  s_buf;

	
	long  l_buf;
	long  l_num_of_conn_nodes;
	long  l_result;



	if  (lReadComments(sFileName,  &pf_source,  &s_buf)  ==  -1)  return(-1);



	//first we have to read the number of nodes
	long  l_nodes_num;

	fscanf(pf_source,"%ld", &l_nodes_num);



	l_result  =  0;

	//now we count the number of links
	long  li,lj;
	for  (li = 0; li < l_nodes_num; li++)
	{
		//now we read in the node number
		if  (feof(pf_source)  ==  0)
			fscanf(pf_source, "%ld",  &l_buf);
		else
		{
			fclose(pf_source);
			return(-2);
		}


		//now it is the number of connected nodes (which means links in this case)
		if  (feof(pf_source)  ==  0)
			fscanf(pf_source, "%ld",  &l_num_of_conn_nodes);
		else
		{
			fclose(pf_source);
			return(-2);
		}


		l_result  +=  l_num_of_conn_nodes;


		for  (lj = 0; lj < l_num_of_conn_nodes * 2; lj++)
		{
			if  (feof(pf_source)  ==  0)
				fscanf(pf_source, "%ld",  &l_buf);
			else
			{
				fclose(pf_source);
				return(-2);
			}
		}//for  (long  lj = 0; lj < l_num_of_conn_nodes; lj++)


	}//for  (long  li = 0; li < l_nodes_num; li++)




	fclose(pf_source);



	return(l_result);
	
}//long  CTopologyTranslator::l_count_number_of_links(CString  sFileName)













/*
returned values:
1..n  -  modeling system node num
-2    -  node num too small
-1    -  node num too high
*/
long  CTopologyTranslator::lTranslateNodeNum(long  lNodeNum)
{

	if  (lNodeNum  <  1)  return(-2);
	if  (l_number_of_nodes  <  lNodeNum)  return(-1);

	return(pl_nodes_rename_table[(lNodeNum - 1) * 2 + 1]);

}//long  CTopologyTranslator::lTranslateNodeNum(long  lNodeNum)




/*
returned values:
1..n  -  modeling system link num
-2    -  link num too small
-1    -  link num too high
*/
long  CTopologyTranslator::lTranslateLinkNum(long  lLinkNum)
{

	if  (lLinkNum  <  1)  return(-2);
	if  (l_number_of_links  <  lLinkNum)  return(-1);

	return(pl_links_rename_table[(lLinkNum - 1) * 2 + 1]);

}//long  CTopologyTranslator::lTranslateNodeNum(long  lNodeNum)






/*
returned values:
0 or more - link id
-1  -  link not found
-2  -  link table empty
*/
long  CTopologyTranslator::lFindLinkIdForNodes(long  lStartNodeId,  long  lFinishNodeId,  bool  bTranslate)
{
	if  (bTranslate  ==  false)
		return(pc_net_model->lFindLinkIdForNodes(lStartNodeId,lFinishNodeId));
	else
		return
			(
			pc_net_model->lFindLinkIdForNodes
				(
				lTranslateNodeNum(lStartNodeId),
				lTranslateNodeNum(lFinishNodeId)
				)
			);

};















//------------------------------------------------------------------------------------------
//------------------implementation of  CFOMfunctionWeight-----------------------------------


CFOMfunctionWeight::CFOMfunctionWeight()
{

	pd_links_weights  =  NULL;
	pd_nodes_weights  =  NULL;

	d_ffe = 0;

}//CFOMfunctionWeight::CFOMfunctionWeight()





CFOMfunctionWeight::~CFOMfunctionWeight()
{

//	printf("dupa!!!\n");

	if  (pd_links_weights  !=  NULL)  delete  []  pd_links_weights;
	if  (pd_nodes_weights  !=  NULL)  delete  []  pd_nodes_weights;

}//CFOMfunctionWeight::~CFOMfunctionWeight()






double  CFOMfunctionWeight::dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure)
{
	d_ffe++;

	double  d_result;
	double  d_buf;


	if  (pd_nodes_weights  ==  NULL)  return(0);
	if  (pd_links_weights  ==  NULL)  return(0);




	d_result  =  0;
	long  l_max, l_act;
	
	for  (long  li = 0; li < pcSimulator->lGetNodesNum(); li++)
	{
		l_max  =  pcSimulator->lGetMaxNodeCapacity(li);
		l_act  =  pcSimulator->lGetActNodeCapacity(li);

		if  ( (l_max  <  0)||(l_act  <  0) ) return(0);
		

		d_buf  =  l_max - l_act;

		d_buf  *=  pd_nodes_weights[li];


		d_result  +=  d_buf;

	}//for  (long  li = 0; li < l_number_of_nodes; li++)



	*pbCapacityExtending  =  false;

	for  (long  li = 0; li < pcSimulator->lGetLinksNum(); li++)
	{
		l_max  =  pcSimulator->lGetMaxLinkCapacity(li);
		l_act  =  pcSimulator->lGetActLinkCapacity(li);

		if  (l_act  <  0)  *pbCapacityExtending  =  true;

		if  ( (l_max  <  0)||(l_act  <  0) )  return(0);
		

		d_buf  =  l_max - l_act;

		d_buf  *=  pd_links_weights[li];


		d_result  +=  d_buf;

	}//for  (long  li = 0; li < l_number_of_nodes; li++)



	d_result  =  1.0 / d_result;

	
	
	return(d_result);


}//double  CFOMfunctionWeight::dCountFOM(CTopologyTranslator  *pcTranslator)












int  CFOMfunctionWeight::iLoadWeights(CString  sFileName,  CTopologyTranslator  *pcTranslator)
{

	FILE  *pf_source;


	pf_source  =  fopen( (LPCSTR)  sFileName, "r+");


	long  l_num_of_nodes;



	if  (feof(pf_source)  ==  0)
		fscanf(pf_source,"%ld", &l_num_of_nodes);
	else
	{
		fclose(pf_source);
		return(-1);
	}



	if  (l_num_of_nodes  !=  pcTranslator->lGetNumberOfNodes())  
	{
		fclose(pf_source);
		return(-2);
	}//if  (l_num_of_nodes  !=  l_number_of_nodes)


	
	if  (pd_nodes_weights  !=  NULL)  delete []  pd_nodes_weights;
	pd_nodes_weights  =  new  double[l_num_of_nodes];
	if  (pd_nodes_weights  ==  NULL)
	{
		fclose(pf_source);
		return(-3);	
	}//if  (pd_nodes_weights  ==  NULL)

	
	
	//now, if the number of nodes is ok we input all nodes and their weights
	long  l_node_num;
	double  d_node_weight;


	long  li;
	for  (li = 0; li < pcTranslator->lGetNumberOfNodes(); li++)
	{

		if  (feof(pf_source)  ==  0)
			fscanf(pf_source,"%ld", &l_node_num);
		else
		{

			delete  []  pd_nodes_weights;
			pd_nodes_weights  =  NULL;
			fclose(pf_source);
			return(-1);
		}//



		if  (feof(pf_source)  ==  0)
			fscanf(pf_source,"%lf", &d_node_weight);
		else
		{
			delete  []  pd_nodes_weights;
			pd_nodes_weights  =  NULL;
			fclose(pf_source);
			return(-1);
		}//


		pd_nodes_weights[pcTranslator->lTranslateNodeNum(l_node_num)]  =  d_node_weight;

		
		
		//printf("node num: %ld node weight: %lf  trans num:%ld\n",l_node_num, d_node_weight, lTranslateNodeNum(l_node_num));

	
	}//for  (long li = 0; li < l_number_of_nodes; li++)









	//now we input the weights of links
	long  l_num_of_links;



	if  (feof(pf_source)  ==  0)
		fscanf(pf_source,"%ld", &l_num_of_links);
	else
	{
		delete  []  pd_nodes_weights;
		pd_nodes_weights  =  NULL;
		fclose(pf_source);
		return(-1);
	}



	if  (l_num_of_links  !=  pcTranslator->lGetNumberOfLinks())  
	{
		delete  []  pd_nodes_weights;
		pd_nodes_weights  =  NULL;
		fclose(pf_source);
		return(-2);
	}//if  (l_num_of_nodes  !=  l_number_of_nodes)


	
	if  (pd_links_weights  !=  NULL)  delete []  pd_links_weights;
	pd_links_weights  =  new  double[pcTranslator->lGetNumberOfLinks()];
	if  (pd_links_weights  ==  NULL)
	{
		delete  []  pd_nodes_weights;
		pd_nodes_weights  =  NULL;
		fclose(pf_source);
		return(-3);	
	}//if  (pd_nodes_weights  ==  NULL)

	
	
	//now, if the number of nodes is ok we input all nodes and their weights
	long  l_link_num;
	double  d_link_weight;


	for  (li = 0; li < pcTranslator->lGetNumberOfLinks(); li++)
	{

		if  (feof(pf_source)  ==  0)
			fscanf(pf_source,"%ld", &l_link_num);
		else
		{
			delete  []  pd_nodes_weights;
			pd_nodes_weights  =  NULL;

			delete  []  pd_links_weights;
			pd_links_weights  =  NULL;

			fclose(pf_source);
			return(-1);
		}//



		if  (feof(pf_source)  ==  0)
			fscanf(pf_source,"%lf", &d_link_weight);
		else
		{
			delete  []  pd_nodes_weights;
			pd_nodes_weights  =  NULL;

			delete  []  pd_links_weights;
			pd_links_weights  =  NULL;

			fclose(pf_source);
			return(-1);
		}//


		pd_links_weights[pcTranslator->lTranslateLinkNum(l_link_num)]  =  d_link_weight;



		//printf("link num: %ld link weight: %lf  trans num:%ld\n",l_link_num, d_link_weight,lTranslateNodeNum(l_link_num));

	
	}//for  (long li = 0; li < l_number_of_links; li++)




	fclose(pf_source);

	return(1);

}//int  CFOMfunctionWeight::iLoadWeights(CString  sFileName)











//------------------------------------------------------------------------------------------
//------------------implementation of  CFOMfunctionLFN-----------------------------------

CFOMfunctionLFN::CFOMfunctionLFN()
{
	d_ffe = 0;
}//CFOMfunctionLFN::CFOMfunctionLFN(CTopologyTranslator)



CFOMfunctionLFN::~CFOMfunctionLFN()
{

}//CFOMfunctionLFN::~CFOMfunctionLFN()









double  CFOMfunctionLFN::dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure)
{
	d_ffe++;

	double  d_result;


	
	d_result  =  0;
	*pbCapacityExtending  =  false;

	bool  b_capacity_ext;
	*pdPenaltyPure = 0;
	*pdFitnessPure = 0;

	for  (long  li = 0; li < pcSimulator->lGetNodesNum(); li++)
	{
		d_result  +=  pcSimulator->dCountNodeLFN(li, lPenalty, &b_capacity_ext, pdFitnessPure, pdPenaltyPure);
		if  (b_capacity_ext)  *pbCapacityExtending  =  true;
	}//for  (long  li = 0; li < l_number_of_nodes; li++)


	d_result = d_result + *pdPenaltyPure;
	d_result  =  1.0 / (d_result + 1.0);

	
	
	return(d_result);
}//double  CFOMfunctionWeight::dCountFOM(CTopologyTranslator  *pcTranslator)






//------------------------------------------------------------------------------------------
//------------------implementation of  CFOMfunctionLFL-----------------------------------

CFOMfunctionLFL::CFOMfunctionLFL()
{
	d_ffe = 0;
}//CFOMfunctionLFL::CFOMfunctionLFL(CTopologyTranslator)



CFOMfunctionLFL::~CFOMfunctionLFL()
{

}//CFOMfunctionLFL::~CFOMfunctionLFL()









double  CFOMfunctionLFL::dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure)
{
	d_ffe++;

	double  d_result;


	
	d_result  =  0;
	*pbCapacityExtending  =  false;

	bool  b_capacity_ext;
	*pdPenaltyPure = 0;
	*pdFitnessPure = 0;

	for  (long  li = 0; li < pcSimulator->lGetNodesNum(); li++)
	{
		d_result  +=  pcSimulator->dCountNodeLFL(li, lPenalty, &b_capacity_ext, pdFitnessPure, pdPenaltyPure);
		if  (b_capacity_ext)  *pbCapacityExtending  =  true;
	}//for  (long  li = 0; li < l_number_of_nodes; li++)


	d_result = d_result + *pdPenaltyPure;
	d_result  =  1.0 / (d_result + 1.0);

	
	
	return(d_result);


}//double  CFOMfunctionLFL::dCountFOM(CTopologyTranslator  *pcTranslator)












//------------------------------------------------------------------------------------------
//------------------implementation of  CFOMfunctionMinAvaibleCapacity-----------------------------------

CFOMfunctionMinAvaibleCapacity::CFOMfunctionMinAvaibleCapacity()
{
	d_ffe = 0;
}//CFOMfunctionLFN::CFOMfunctionLFN(CTopologyTranslator)



CFOMfunctionMinAvaibleCapacity::~CFOMfunctionMinAvaibleCapacity()
{

}//CFOMfunctionLFN::~CFOMfunctionLFN()









double  CFOMfunctionMinAvaibleCapacity::dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure)
{
	d_ffe++;

	double  d_result  =  0;
	
	

	long  l_buf;
	
/*	for  (long  li = 0; li < pc_translator->lGetNumberOfNodes(); li++)
	{

		l_buf  =  pc_translator->lGetActNodeCapacity(li);


		//for the first round we must input at least any value as already found
		if  (li  ==  0)
			d_result  =  l_buf;
		else
		{
			//after the first round we replace the result value only if the new one is smaller
			if  (l_buf  <  d_result)  d_result  =  l_buf;
		
		}//else  if  (li  ==  0)

	}//for  (long  li = 0; li < l_number_of_nodes; li++)*/


//asdasdasd

	*pbCapacityExtending  =  false;

	for  (long  li = 0; li < pcSimulator->lGetLinksNum(); li++)
	{

		l_buf  =  pcSimulator->lGetActLinkCapacity(li);

		if  (l_buf  <  0)  *pbCapacityExtending  =  true;

		if  ( (l_buf  <  d_result)||(li  ==  0) )  d_result  =  l_buf;
		
	}//for  (long  li = 0; li < l_number_of_nodes; li++)


	//if  (*pbCapacityExtending == false)  ::MessageBox(NULL, "o2k", "o2k", MB_OK);

	//now we must change the value so this is bigger then 0
	if  (lPenalty  >  0)
	{
		if  (d_result  ==  0)  d_result  =  0.75;
		if  (d_result  <  0)
		{
			d_result  *=  (-1.0);
			d_result  =  1.0 / d_result;	
		}//if  (d_result  <  0)
	}//if  (bPenalty  ==  true)

	
	return(d_result);


}//double  CFOMfunctionMinAvaibleCapacity::dCountFOM(CTopologyTranslator  *pcTranslator)









//------------------------------------------------------------------------------------------
//------------------implementation of  CFOMfunctionIncrDemandConstrSatisf-----------------------------------

CFOMfunctionIncrDemandConstrSatisf::CFOMfunctionIncrDemandConstrSatisf()
{
	d_ffe = 0;
}//CFOMfunctionIncrDemandConstrSatisf::CFOMfunctionIncrDemandConstrSatisf()



CFOMfunctionIncrDemandConstrSatisf::~CFOMfunctionIncrDemandConstrSatisf()
{

}//CFOMfunctionIncrDemandConstrSatisf::~CFOMfunctionIncrDemandConstrSatisf()









double  CFOMfunctionIncrDemandConstrSatisf::dCountFOM(CNETsimulator  *pcSimulator,  long  lPenalty, bool  *pbCapacityExtending, double *pdFitnessPure, double *pdPenaltyPure)
{
	d_ffe++;

	double  d_result  =  0;
	
	

	long  l_buf;
	
	*pbCapacityExtending  =  false;

	for  (long  li = 0; li < pcSimulator->lGetLinksNum(); li++)
	{

		l_buf  =  pcSimulator->lGetActLinkCapacity(li);

		if  (l_buf  <  0)  *pbCapacityExtending  =  true;

		if  ( (l_buf  <  d_result)||(li  ==  0) )  d_result  =  l_buf;
		
	}//for  (long  li = 0; li < l_number_of_nodes; li++)


	//if  (*pbCapacityExtending == false)  ::MessageBox(NULL, "o2k", "o2k", MB_OK);

	//now we must change the value so this is bigger then 0
	if  (lPenalty  >  0)
	{
		if  (d_result  ==  0)  d_result  =  0.75;
		if  (d_result  <  0)
		{
			d_result  *=  (-1.0);
			d_result  =  1.0 / d_result;	
		}//if  (d_result  <  0)
	}//if  (bPenalty  ==  true)

	if  (((CNETsimulatorSimplyfied *) pcSimulator)->iGetMinimumAllowedDemandIncrease() > 0)
		d_result +=  ((CNETsimulatorSimplyfied *) pcSimulator)->iGetMinimumAllowedDemandIncrease();

	
	return(d_result);
};//double  CFOMfunctionIncrDemandConstrSatisf::dCountFOM(CTopologyTranslator  *pcTranslator)


