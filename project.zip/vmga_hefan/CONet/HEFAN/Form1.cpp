#include "stdafx.h"
#include "Form1.h"
#include <windows.h>

using namespace HEFAN;

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	System::Threading::Thread::CurrentThread->ApartmentState = System::Threading::ApartmentState::STA;
	//::MessageBox(NULL, lpCmdLine, lpCmdLine, MB_OK);

	/*FILE  *pf_test;
	CString  s_out_test_name;
	s_out_test_name.Format("%s_out.txt", lpCmdLine);
	pf_test = fopen(s_out_test_name, "w+");
	fprintf(pf_test, "out  %s", lpCmdLine);
	fclose(pf_test);//*/

	CString  s_in_data;	
	s_in_data.Format("%s", lpCmdLine);
	Application::Run(new CMainHefanForm(s_in_data));
	return 0;
};




System::Void CMainHefanForm::but_load_1file_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;
	CString  s_buf;

	/*OpenFileDialog* openFileDialog1 = new OpenFileDialog();
 
    //openFileDialog1->InitialDirectory = S"D:\\praca dyplomowa - nowy interfejs\\publikacja\\FD_init" ;
	openFileDialog1->Filter = "All files (*.*)|*.*";
    openFileDialog1->FilterIndex = 0;
    openFileDialog1->RestoreDirectory = true;
	openFileDialog1->Multiselect  =  false;

    if(openFileDialog1->ShowDialog() == DialogResult::OK)
    {
		Refresh();

		if  (File::Exists(openFileDialog1->FileNames[0])  ==  false)
		{
			s_buf  =  (CString) openFileDialog1->FileNames[0];
			s_buf.Format("The file does not exist (%s)", (LPCSTR) s_buf);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
			return;
		}//if  (File::Exists(openFileDialog1->FileNames[ii])  ==  false)


		c_err  =  pc_system->eRunFile(openFileDialog1->FileNames[0], list_params, list_comm);*/
		c_err  =  pc_system->eRunFile("D:\\zzz comparer test\\aa\\settings.dat", list_params, list_comm);
	
		if  (c_err)
		{
			c_err.vShowWindow();
			return;		
		}//if  (c_err)

	//}//if(openFileDialog1->ShowDialog() == DialogResult::OK)


}//System::Void CMainHefanForm::but_load_1file_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CMainHefanForm::but_load_set_of_files_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;
	CString  s_buf;

	/*OpenFileDialog* openFileDialog1 = new OpenFileDialog();
 
    //openFileDialog1->InitialDirectory = S"D:\\praca dyplomowa - nowy interfejs\\publikacja\\FD_init" ;
	openFileDialog1->Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
    openFileDialog1->FilterIndex = 0;
    openFileDialog1->RestoreDirectory = true;
	openFileDialog1->Multiselect  =  false;

    if(openFileDialog1->ShowDialog() == DialogResult::OK)*/
	try
	{
		CString  s_set_of_files_name;
		int  i_header_type;
		//s_set_of_files_name  =  (CString)  openFileDialog1->FileNames[0];
		//s_set_of_files_name  =  "D:\\co vmea gen pop tuning\\part1.txt";

		s_set_of_files_name = ::Application::ExecutablePath;
		s_set_of_files_name.Replace("HEFAN.exe", "");
		s_set_of_files_name += "serie.txt";

		//::MessageBox(NULL, s_set_of_files_name, s_set_of_files_name, MB_OK);

		c_err  =  pc_system->eCheckHeader(s_set_of_files_name,  &i_header_type);
		if  (i_header_type  !=  HEADER_TYPE_HEFAN_2_0)
		{
			s_buf.Format("Script version type different from %s", SCRIPT_VER_1_0);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
			return;		
		}//if  (i_header_type  !=  HEADER_TYPE_HEFAN_2_0)


		FILE  *pf_set_of_files;
		pf_set_of_files  =  fopen((LPCSTR)  s_set_of_files_name, "r+");

		if  (pf_set_of_files  ==  NULL)
		{
			s_buf.Format("Can not open file %s", (LPCSTR) s_set_of_files_name);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
			return;
		}//if  (pf_set_of_files  ==  NULL)


		CString  s_buf2;
		CHefanSystem::vReadLine(pf_set_of_files, &s_buf, &s_buf2);//script version...


		CString  s_mother_dir;
		c_err  =  CHefanSystem::eReadValue(pf_set_of_files, "root dir", &s_mother_dir);
		if  (c_err)
		{
			fclose(pf_set_of_files);
			c_err.vShowWindow();
			return;		
		}//if  (c_err)

		
		vector  <CString>  v_settings_files_to_run;
		CString  s_settings_file;
		while  (!feof(pf_set_of_files))
		{
			CHefanSystem::vReadLine(pf_set_of_files, &s_settings_file, &s_buf);
			v_settings_files_to_run.push_back(s_settings_file);
		}//while  (!feof(pf_settings_file))

		fclose(pf_set_of_files);

		//now we execute run 1 file for all stored settings files...
		for  (int  ii = 0; ii < (int) v_settings_files_to_run.size(); ii++)
		{
			c_err  =  pc_system->eRunFile(s_mother_dir  + v_settings_files_to_run.at(ii), list_params, list_comm);
			if  (c_err)
			{
				c_err.vShowWindow();
				return;		
			}//if  (c_err)
		
		}//for  (int  ii = 0; ii < (int) v_settings_files_to_run.size(); ii++)

	}//try
	catch(Exception *pex)
	{
		CError  c_err;
		s_buf = pex->ToString();
		s_buf = s_buf + "\nGeneral run serie exception";
		c_err.vPutError(s_buf);
		c_err.vShowWindow();
	}//catch(Exception *pex)

};//System::Void CMainHefanForm::but_load_set_of_files_Click(System::Object *  sender, System::EventArgs *  e)



void  v_create_single_config_islang_ga_tune
  (
  CString  sCaseName, int iRunNumber, CString  sSerieName, int iCTStrategy, bool  bStartSolution, 
  int  iLinkageGenerationWay, int iMigrationFreq,
  int iPop, 
  double  dHighCross, double dHighMut, double dLowCross, double dLowMut, 
  double dUniformCrossover,
  int  iNewCtDisturbedCopy, int  iNewCtDdisturbed_LLDSI, double  dNewCtDisturbedGeneDisturbedProb
  )
{
	CString  s_buf;
	CString  s_settings_name;

	FILE  *pf_settings;
	//s_settings_name.Format("settings_%s_%.3d.txt", sCaseName, iPop);
	//s_settings_name.Format("settings_%s_%d.txt", sCaseName, (int) (dLowMut * 100));
	s_settings_name.Format("settings_%s.txt", sCaseName);

	pf_settings = fopen(s_settings_name, "w+");
	if  (pf_settings  ==  NULL)
	{
		CError  c_err;

		s_buf.Format("unable to open (%s)", s_settings_name);
		c_err.vPutError(s_buf);
		return;
	}//if  (pf_settings  ==  NULL)





	int  i_gen, i_pop;
	double  d_cut, d_splice;
	double  d_pop_red;
	double  d_mut;
	int  i_pattern_pool_size, i_the_same_pattern_check, i_minimal_pattern_len, i_virginity_rounds;
	int  i_time;
	int  i_ct_strategy;
	double  d_low_cross, d_low_mut;

	i_pop = iPop;
	d_pop_red = 1;
	i_pattern_pool_size = 500;
	i_the_same_pattern_check = 0;
	i_minimal_pattern_len = 3;
	i_virginity_rounds = 100;
	d_low_cross = dLowCross;//0.5;
	d_low_mut = dLowMut;//0.4
	i_time = 10800;
	i_ct_strategy = iCTStrategy;//CT number strategy (positive-static number of CTs -1=classic -2=active -3=memo)


	s_buf.Format("%s\n", SCRIPT_VER_1_0);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%s%s\n", ISLAND_MODEL_NAME, "//algorithm"); 
	fprintf(pf_settings, s_buf);
	s_buf = "LFL//cost function\n";
	fprintf(pf_settings, s_buf);

	s_buf.Format("/../../data/%s/%s.net//topology\n",sCaseName,sCaseName);
	fprintf(pf_settings, s_buf);
	s_buf.Format("/../../data/%s/%s.con//connections\n",sCaseName,sCaseName);
	fprintf(pf_settings, s_buf);
	
	if  (bStartSolution  ==  true)
		s_buf.Format("/../../data/%s/%s.lfl//start solution\n",sCaseName,sCaseName);
	else
		s_buf.Format("//start solution\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("//VWaysDb\n");
	fprintf(pf_settings, s_buf);
	
	s_buf.Format("%s_res//result files\n",sCaseName);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%s_res//fitness tracking file\n",sCaseName);
	fprintf(pf_settings, s_buf);


	s_buf.Format("2//Clone repetations\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("4//Init shortest ways\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("1//Top individuals\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("allowed//Allow exceed link capacity\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("10.000000//Exceed link capacity penalty\n");
	fprintf(pf_settings, s_buf);
	

	s_buf.Format("%d//%s\n", i_time, VGA_PARAM_MAX_TIME);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", iLinkageGenerationWay, VGA_PARAM_IM_LINKAGE_GEN);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", i_pattern_pool_size, VGA_PARAM_PATTERN_POOL_SIZE);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", i_minimal_pattern_len, VGA_PARAM_MINIMAL_PATTERN_LEN);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", iMigrationFreq, VGA_PARAM_IM_MIGRATION_FREQ);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", iPop, VGA_PARAM_POP_SIZE);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%.8lf//High level crossing\n", dHighCross);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.8lf//High level mutation\n", dHighMut);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.8lf//Low level crossing\n", dLowCross);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.8lf//Low level mutation\n", dLowMut);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%.8lf//High level crossing unordered\n", dUniformCrossover);
	fprintf(pf_settings, s_buf);


	s_buf.Format("%d//%s\n", i_ct_strategy, VGA_PARAM_VIR_CT_STRATEGY);
	fprintf(pf_settings, s_buf);


	s_buf.Format("%d//%s\n", iNewCtDisturbedCopy, VGA_PARAM_NEW_CT_IS_A_DISTURBED_COPY);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", iNewCtDdisturbed_LLDSI, VGA_PARAM_NEW_CT_LLDSI);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%.4lf//%s\n", dNewCtDisturbedGeneDisturbedProb, VGA_PARAM_NEW_CT_GENE_DISTURB_PROB);
	fprintf(pf_settings, s_buf);

	

	fclose(pf_settings);

	s_buf.Format("%s\\\\%d",s_settings_name, iRunNumber);
	Tools::vRepInFile(sSerieName, s_buf);
}//void  v_create_single_config_islang_ga_tune



void  v_create_single_config_mup_tune
  (
  CString  sCaseName, int iRunNumber, CString  sSerieName, int iCTStrategy, bool  bStartSolution, 
  int iGen, int iPop, double  dCut, double  dSplice, double dMut, double dLowCross, double dLowMut, 
  int iParentSelection,
  int  iNewCtDisturbedCopy, int  iNewCtDdisturbed_LLDSI, double  dNewCtDisturbedGeneDisturbedProb
  )
{
	CString  s_buf;
	CString  s_settings_name;

	FILE  *pf_settings;
	//s_settings_name.Format("settings_%s_%.3d.txt", sCaseName, iPop);
	//s_settings_name.Format("settings_%s_%d.txt", sCaseName, (int) (dLowMut * 100));
	s_settings_name.Format("settings_%s.txt", sCaseName);

	pf_settings = fopen(s_settings_name, "w+");
	if  (pf_settings  ==  NULL)
	{
		CError  c_err;

		s_buf.Format("unable to open (%s)", s_settings_name);
		c_err.vPutError(s_buf);
		return;
	}//if  (pf_settings  ==  NULL)





	int  i_gen, i_pop;
	double  d_cut, d_splice;
	double  d_pop_red;
	double  d_mut;
	int  i_pattern_pool_size, i_the_same_pattern_check, i_minimal_pattern_len, i_virginity_rounds;
	int  i_time;
	int  i_ct_strategy;
	double  d_low_cross, d_low_mut;

	i_gen = iGen;
	i_pop = iPop;
	d_mut = dMut;//0.1;
	d_cut = dCut;//0.09;
	d_splice = dSplice;//0.15;
	d_pop_red = 1;
	i_pattern_pool_size = 500;
	i_the_same_pattern_check = 0;
	i_minimal_pattern_len = 3;
	i_virginity_rounds = 100;
	d_low_cross = dLowCross;//0.5;
	d_low_mut = dLowMut;//0.4
	i_time = 10800;
	i_ct_strategy = iCTStrategy;//CT number strategy (positive-static number of CTs -1=classic -2=active -3=memo)


	s_buf.Format("%s\n", SCRIPT_VER_1_0);
	fprintf(pf_settings, s_buf);
	s_buf = "VMEA HEFAN//algorithm\n";
	fprintf(pf_settings, s_buf);
	s_buf = "LFL//cost function\n";
	fprintf(pf_settings, s_buf);

	s_buf.Format("/../../data/%s/%s.net//topology\n",sCaseName,sCaseName);
	fprintf(pf_settings, s_buf);
	s_buf.Format("/../../data/%s/%s.con//connections\n",sCaseName,sCaseName);
	fprintf(pf_settings, s_buf);
	
	if  (bStartSolution  ==  true)
		s_buf.Format("/../../data/%s/%s.lfl//start solution\n",sCaseName,sCaseName);
	else
		s_buf.Format("//start solution\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("//VWaysDb\n");
	fprintf(pf_settings, s_buf);
	
	s_buf.Format("%s_res//result files\n",sCaseName);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%s_res//fitness tracking file\n",sCaseName);
	fprintf(pf_settings, s_buf);


	s_buf.Format("2//Clone repetations\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("4//Init shortest ways\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("1//Top individuals\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("allowed//Allow exceed link capacity\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("10.000000//Exceed link capacity penalty\n");
	fprintf(pf_settings, s_buf);
	

	s_buf.Format("%d//%s\n", i_time, VGA_PARAM_MAX_TIME);
	fprintf(pf_settings, s_buf);
	s_buf.Format("1.000000//glue infections\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("1.000000//template fitness check\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", i_pattern_pool_size, VGA_PARAM_PATTERN_POOL_SIZE);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", i_the_same_pattern_check, VGA_PARAM_SAME_PATTERN_CHECK);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%d//%s\n", i_the_same_pattern_check, VGA_PARAM_PREFERRED_PATTERN_LENGTH);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%d//%s\n", i_minimal_pattern_len, VGA_PARAM_MINIMAL_PATTERN_LEN);
	fprintf(pf_settings, s_buf);
	s_buf.Format("0.000000//length or entrophy at pattern number check\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("1.000000//use templates at virus init\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", i_gen, VGA_PARAM_VIR_GENERATIONS);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%d//%s\n", i_pop, VGA_PARAM_VIR_POP);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_pop_red, VGA_PARAM_VIR_POP_RED);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_cut, VGA_PARAM_VIR_PROB_CUT);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_splice, VGA_PARAM_VIR_PROB_SPLICE);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_mut, VGA_PARAM_VIR_PROB_MUT);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_mut, VGA_PARAM_VIR_REM_GENE);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_mut, VGA_PARAM_VIR_ADD_GENE);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%.4lf//virus prob low cross\n", d_low_cross, VGA_PARAM_VIR_ADD_GENE);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//virus prob low mut\n", d_low_mut, VGA_PARAM_VIR_ADD_GENE);
	fprintf(pf_settings, s_buf);

	s_buf.Format("0.000000//virus prob init mut\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("10//virus virginity rounds\n");
	fprintf(pf_settings, s_buf);


	s_buf.Format("%d//%s\n", i_ct_strategy, VGA_PARAM_VIR_CT_STRATEGY);
	fprintf(pf_settings, s_buf);


	s_buf.Format("%d//%s\n", iParentSelection, VGA_PARAM_PARENT_SELECTION_STRATEGY);
	fprintf(pf_settings, s_buf);


	s_buf.Format("%d//%s\n", iNewCtDisturbedCopy, VGA_PARAM_NEW_CT_IS_A_DISTURBED_COPY);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", iNewCtDdisturbed_LLDSI, VGA_PARAM_NEW_CT_LLDSI);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%.4lf//%s\n", dNewCtDisturbedGeneDisturbedProb, VGA_PARAM_NEW_CT_GENE_DISTURB_PROB);
	fprintf(pf_settings, s_buf);

	

	fclose(pf_settings);

	s_buf.Format("%s\\\\%d",s_settings_name, iRunNumber);
	Tools::vRepInFile(sSerieName, s_buf);
}//void  v_create_single_config_mup_active(CString  sCaseName, CString  sSerieName)






void  v_create_single_config_mup(CString  sCaseName, int iRunNumber, CString  sSerieName, int iCTStrategy, bool  bStartSolution)
{
	CString  s_buf;
	CString  s_settings_name;

	FILE  *pf_settings;
	s_settings_name = "settings_" + sCaseName + ".txt";
	pf_settings = fopen(s_settings_name, "w+");
	if  (pf_settings  ==  NULL)
	{
		CError  c_err;

		s_buf.Format("unable to open (%s)", s_settings_name);
		c_err.vPutError(s_buf);
		return;
	}//if  (pf_settings  ==  NULL)





	int  i_gen, i_pop;
	double  d_cut, d_splice;
	double  d_pop_red;
	double  d_mut;
	int  i_pattern_pool_size, i_the_same_pattern_check, i_minimal_pattern_len, i_virginity_rounds;
	int  i_time;
	int  i_ct_strategy;
	double  d_low_cross, d_low_mut;

	i_gen = 30;
	i_pop = 30;
	d_mut = 0.1;
	d_cut = 0.09;
	d_splice = 0.15;
	d_pop_red = 0.97;
	i_pattern_pool_size = 500;
	i_the_same_pattern_check = 0;
	i_minimal_pattern_len = 3;
	i_virginity_rounds = 100;
	d_low_cross = 0.5;
	d_low_mut = 0.4;
	i_time = 3600;
	i_ct_strategy = iCTStrategy;//CT number strategy (positive-static number of CTs -1=classic -2=active -3=memo)


	s_buf.Format("%s\n", SCRIPT_VER_1_0);
	fprintf(pf_settings, s_buf);
	s_buf = "VMEA HEFAN//algorithm\n";
	fprintf(pf_settings, s_buf);
	s_buf = "LFL//cost function\n";
	fprintf(pf_settings, s_buf);

	s_buf.Format("%s/%s.net//topology\n",sCaseName,sCaseName);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%s/%s.con//connections\n",sCaseName,sCaseName);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%s/%s.lfl//start solution\n",sCaseName,sCaseName);
	fprintf(pf_settings, s_buf);
	s_buf.Format("//VWaysDb\n");
	fprintf(pf_settings, s_buf);
	if  (bStartSolution  ==  true)
		s_buf.Format("%s/%s.lfl//start solution\n",sCaseName,sCaseName);
	else
		s_buf.Format("//start solution\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("%s_res//result files\n",sCaseName);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%s_res//fitness tracking file\n",sCaseName);
	fprintf(pf_settings, s_buf);


	s_buf.Format("2//Clone repetations\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("4//Init shortest ways\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("1//Top individuals\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("allowed//Allow exceed link capacity\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("10.000000//Exceed link capacity penalty\n");
	fprintf(pf_settings, s_buf);
	

	s_buf.Format("%d//%s\n", i_time, VGA_PARAM_MAX_TIME);
	fprintf(pf_settings, s_buf);
	s_buf.Format("1.000000//glue infections\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("1.000000//template fitness check\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", i_pattern_pool_size, VGA_PARAM_PATTERN_POOL_SIZE);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", i_the_same_pattern_check, VGA_PARAM_SAME_PATTERN_CHECK);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%d//%s\n", i_the_same_pattern_check, VGA_PARAM_PREFERRED_PATTERN_LENGTH);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%d//%s\n", i_minimal_pattern_len, VGA_PARAM_MINIMAL_PATTERN_LEN);
	fprintf(pf_settings, s_buf);
	s_buf.Format("0.000000//length or entrophy at pattern number check\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("1.000000//use templates at virus init\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//%s\n", i_gen, VGA_PARAM_VIR_GENERATIONS);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%d//%s\n", i_pop, VGA_PARAM_VIR_POP);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_pop_red, VGA_PARAM_VIR_POP_RED);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_cut, VGA_PARAM_VIR_PROB_CUT);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_splice, VGA_PARAM_VIR_PROB_SPLICE);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_mut, VGA_PARAM_VIR_PROB_MUT);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_mut, VGA_PARAM_VIR_REM_GENE);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//%s\n", d_mut, VGA_PARAM_VIR_ADD_GENE);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%.4lf//virus prob low cross\n", d_low_cross, VGA_PARAM_VIR_ADD_GENE);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.4lf//virus prob low mut\n", d_low_mut, VGA_PARAM_VIR_ADD_GENE);
	fprintf(pf_settings, s_buf);

	s_buf.Format("0.000000//virus prob init mut\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("10//virus virginity rounds\n");
	fprintf(pf_settings, s_buf);


	s_buf.Format("%d//%s\n", i_ct_strategy, VGA_PARAM_VIR_CT_STRATEGY);
	fprintf(pf_settings, s_buf);

	fclose(pf_settings);

	s_buf.Format("%s//%d",s_settings_name, iRunNumber);
	Tools::vRepInFile(sSerieName, s_buf);
}//void  v_create_single_config_mup_active(CString  sCaseName, CString  sSerieName)





void  v_create_single_config_hefan(CString  sCaseName, int iRunNumber, CString  sSerieName, bool  bStartSolution, int iPop, double  dHighCross, double  dHighMut, double dLowCross, double dLowMut, double dUniformCrossover)
{
	CString  s_buf;
	CString  s_settings_name;

	FILE  *pf_settings;
	//s_settings_name.Format("settings_%s_%.3d.txt", sCaseName, iCTStrategy*(-1));
	//s_settings_name.Format("settings_%s_%d.txt", sCaseName, (int) (dUniformCrossover * 100));
	s_settings_name.Format("settings_%s.txt", sCaseName);

	pf_settings = fopen(s_settings_name, "w+");
	if  (pf_settings  ==  NULL)
	{
		CError  c_err;

		s_buf.Format("unable to open (%s)", s_settings_name);
		c_err.vPutError(s_buf);
		return;
	}//if  (pf_settings  ==  NULL)






	int  i_time;
	i_time = 43200;
	

	s_buf.Format("%s\n", SCRIPT_VER_1_0);
	fprintf(pf_settings, s_buf);
	s_buf = "HEFAN 2.2//algorithm\n";
	fprintf(pf_settings, s_buf);
	s_buf = "LFL//cost function\n";
	fprintf(pf_settings, s_buf);

	s_buf.Format("/../../data/%s/%s.net//topology\n",sCaseName,sCaseName);
	fprintf(pf_settings, s_buf);
	s_buf.Format("/../../data/%s/%s.con//connections\n",sCaseName,sCaseName);
	fprintf(pf_settings, s_buf);
	
	if  (bStartSolution  ==  true)
		s_buf.Format("/../../data/%s/%s.lfl//start solution\n",sCaseName,sCaseName);
	else
		s_buf.Format("//start solution\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("//VWaysDb\n");
	fprintf(pf_settings, s_buf);
	
	s_buf.Format("%s_res//result files\n",sCaseName);
	fprintf(pf_settings, s_buf);
	s_buf.Format("summary.txt//fitness tracking file\n");
	fprintf(pf_settings, s_buf);


	s_buf.Format("2//Clone repetations\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("4//Init shortest ways\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("1//Top individuals\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("allowed//Allow exceed link capacity\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("10.000000//Exceed link capacity penalty\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("0.000000//Flow increase\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("0.000000//Flow increase every x generations\n");
	fprintf(pf_settings, s_buf);


	s_buf.Format("%.8lf//High level crossing\n", dHighCross);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.8lf//High level mutation\n", dHighMut);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.8lf//Low level crossing\n", dLowCross);
	fprintf(pf_settings, s_buf);
	s_buf.Format("%.8lf//Low level mutation\n", dLowMut);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%.8lf//High level crossing unordered\n", dUniformCrossover);
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//Population size\n", iPop);
	fprintf(pf_settings, s_buf);

	s_buf.Format("0.000000//Generation number\n");
	fprintf(pf_settings, s_buf);

	s_buf.Format("%d//Time restriction\n", i_time);
	fprintf(pf_settings, s_buf);

	s_buf.Format("0.000000//Brainstorm radius\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("0.000000//Brainstorm turn on perc\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("0.000000//Brainstorm duration\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("0.000000//Brainstorm turning off\n");
	fprintf(pf_settings, s_buf);
	s_buf.Format("5000.000000//Brainstorm min break\n");
	fprintf(pf_settings, s_buf);



	fclose(pf_settings);

	s_buf.Format("%s\\\\%d",s_settings_name, iRunNumber);
	Tools::vRepInFile(sSerieName, s_buf);
}//void  v_create_single_config_mup_active(CString  sCaseName, CString  sSerieName)







System::Void CMainHefanForm::v_create_test_config_muppets(bool  bTuning)
{
	CString  s_dir;

	s_dir = ::Application::ExecutablePath;
	s_dir.Replace("HEFAN.exe", "");
	
	CString  s_serie_name;
	s_serie_name = s_dir + "serie.txt";


	CString  s_buf;
	Tools::vRepInFile(s_serie_name, "#SCRIPT VER. 1.0");
	s_buf.Format("%s//root dir", s_dir);
	Tools::vRepInFile(s_serie_name, s_buf);



	

	//v_create_single_config_mup_tune(v_case_names.at(ii), 2, s_serie_name, -1, false, 70);//classic
	//v_create_single_config_mup_tune(v_case_names.at(ii), 2, s_serie_name, -2, false, 45);//active
	//v_create_single_config_mup_tune(v_case_names.at(ii), 2, s_serie_name, -3, false, 30);//memo

	vector<CString>  v_case_names;
	v_get_case_names(&v_case_names, bTuning);

	vector<double> v_parameter_values;
	//v_parameter_values.push_back(0);
	/*v_parameter_values.push_back(0.01);
	v_parameter_values.push_back(0.02);
	v_parameter_values.push_back(0.03);
	/*v_parameter_values.push_back(0.04);
	v_parameter_values.push_back(0.06);
	v_parameter_values.push_back(0.09);
	v_parameter_values.push_back(0.14);
	v_parameter_values.push_back(0.21);
	v_parameter_values.push_back(0.3);
	v_parameter_values.push_back(0.45);
	v_parameter_values.push_back(0.7);
	/*v_parameter_values.push_back(0.8);
	v_parameter_values.push_back(0.9);
	v_parameter_values.push_back(1);
	//v_parameter_values.push_back(0.07);
	/*v_parameter_values.push_back(0.1);
	v_parameter_values.push_back(0.15);//*/
	//v_parameter_values.push_back(0.1);
	v_parameter_values.push_back(0.2);
	/*v_parameter_values.push_back(0.3);
	v_parameter_values.push_back(0.4);
	v_parameter_values.push_back(0.5);
	v_parameter_values.push_back(0.6);
	v_parameter_values.push_back(0.7);//*/
	/*v_parameter_values.push_back(0.8);
	v_parameter_values.push_back(0.9);
	//*/
	//v_parameter_values.push_back(0.7);
	

	/*v_parameter_values.push_back(15);
	v_parameter_values.push_back(20);
	v_parameter_values.push_back(30);
	v_parameter_values.push_back(45);
	v_parameter_values.push_back(70);
	v_parameter_values.push_back(100);
	v_parameter_values.push_back(150);
	v_parameter_values.push_back(225);
	v_parameter_values.push_back(350);
	/*v_parameter_values.push_back(500);
	v_parameter_values.push_back(750);
	v_parameter_values.push_back(1100);
	v_parameter_values.push_back(1600);
	v_parameter_values.push_back(2400);
	v_parameter_values.push_back(3600);
	v_parameter_values.push_back(5600);
	v_parameter_values.push_back(8100);
	//*/

	/*v_parameter_values.push_back(0.045);
	v_parameter_values.push_back(0.07);
	v_parameter_values.push_back(0.1);
	v_parameter_values.push_back(0.15);
	v_parameter_values.push_back(0.2);
	v_parameter_values.push_back(0.3);
	v_parameter_values.push_back(0.4);
	/*v_parameter_values.push_back(225);
	v_parameter_values.push_back(350);
	v_parameter_values.push_back(500);
	v_parameter_values.push_back(750);
	v_parameter_values.push_back(1100);
	v_parameter_values.push_back(1600);
	v_parameter_values.push_back(2400);
	v_parameter_values.push_back(3600);
	v_parameter_values.push_back(5600);
	v_parameter_values.push_back(8100);*/



	int i_strategy_temp = 1;

	/*s_buf.Format("C:\\z_mine\\research\\MEMO muppets\\program\\hefan.exe\\\\PROGRAM");
	Tools::vRepInFile(s_serie_name, s_buf);

	s_buf.Format("C:\\z_mine\\research\\MEMO muppets\\eff_test\\\\DIR");
	Tools::vRepInFile(s_serie_name, s_buf);*/
	

	for (int i_param = 0; i_param < v_parameter_values.size(); i_param++)
	{
		s_buf.Format("summary.txt\\\\SUMMFILE", (int) (v_parameter_values.at(i_param) * 100));
		Tools::vRepInFile(s_serie_name, s_buf);

		for  (int  ii = 0; ii < v_case_names.size(); ii++)
		{
			//ct initialization driven by linkage learning
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, 1,  false, 5600, 30, 0.09, 0.2, 0.045, 0.4, 0.5);//single
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -2, true, 1100, 30, 0.3, 0.15, 0.2, 0.5, 0.4);//Active
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -1, true, 8100, 100, 0.09, 0.15, 0.15, 0.3, 0.4);//classic
			
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -3, true, 3600, 30, 0.14, 0.3, 0.2, 0.6, 0.2);//memo
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -4, true, 8100, 100, 0.21, 0.15, 0.1, 0.4, 0.4);//total memo
			
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -5, true, 2400, 30, 0.14, 0.15, 0.15, 0.5, 0.5);//memo total refresh


			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, 1,  true, 5600, 30, 0.09, 0.2, 0.045, 0.4, 0.5, 3, 0, 0, 0);//single
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -2, true, 100, 100, 0.21, 0.3, 0.2, 0.6, 0.2, 3, 0, 0, 0);//Active
			


			//random ct initialization

			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, 1,  false, 5600, 30, 0.09, 0.2, 0.045, 0.4, 0.5, 1);//single
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, 1,  false, 150, 45, 0.3, 0.06, 0.2, 0.4, 0.5, 1, 0, 0, 0);//single ritu

			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -2, false, 100, 100, 0.21, 0.3, 0.2, 0.6, 0.2, 0, 0, 0, 0);//Active

			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -2, false, 750, 70, 0.09, 0.02, 0.2, 0.4, 0.6, 3, 1, 1, 0);//Active switch (cost divided)


			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -1, false, 45, 70, 0.21, 0.21, 0.15, 0.5, 0.2);//classic
			
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -3, false, 500, 70, 0.09, 0.21, 0.07, 0.4, 0.5);//memo
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -4, false, 350, 20, 0.14, 0.3, 0.2, 0.6, 0.4);//total memo
			
			//v_create_single_config_mup_tune(v_case_names.at(ii), 1, s_serie_name, -5, false, 150, 70, 0.21, 0.3, 0.1, 0.4, 0.2);//memo total refresh


			v_create_single_config_hefan(v_case_names.at(ii), 1, s_serie_name, true, 1000, 0.9, 0, 0.1, 0.4, 0.5);//HEFAN 2.2

			//v_create_single_config_islang_ga_tune(v_case_names.at(ii), 1, s_serie_name, -2,  false, 0, 20, 200, 0.5, 0.2, 0.5, 0.4, 0.5, 1, 0, 0.3);//iland ga dynamic
		}//for  (int  ii = 0; ii < v_case_names.size; ii+)
	}//for (int i_gen = 0; i_gen < v_parameter_values.size(); i_gen++)*/





	/*for  (int  ii = 0; ii < v_case_names.size(); ii++)
	{
		v_create_single_config_mup_tune(v_case_names.at(ii), 2, s_serie_name, -1, false, 30, 30);//classic
	}//for  (int  ii = 0; ii < v_case_names.size; ii+)*/



	/*for  (int  ii = 0; ii < v_case_names.size(); ii++)
	{
		v_create_single_config_mup_tune(v_case_names.at(ii), 2, s_serie_name, 1, false, 150, 30);//single
	}//for  (int  ii = 0; ii < v_case_names.size; ii+)*/




	/*for  (int  ii = 0; ii < v_case_names.size(); ii++)
	{
		v_create_single_config_mup_tune(v_case_names.at(ii), 2, s_serie_name, -4, false, 2400, 20);//total memo
	}//for  (int  ii = 0; ii < v_case_names.size; ii+)*/


	/*for  (int  ii = 0; ii < v_case_names.size(); ii++)
	{
		v_create_single_config_mup_tune(v_case_names.at(ii), 2, s_serie_name, -4, false, 2400, 45);//total memo
	}//for  (int  ii = 0; ii < v_case_names.size; ii+)*/


	/*for  (int  ii = 0; ii < v_case_names.size(); ii++)
	{
		v_create_single_config_mup_tune(v_case_names.at(ii), 2, s_serie_name, -5, false, 8100, 30);//total memo refresh
	}//for  (int  ii = 0; ii < v_case_names.size; ii+)*/
	
	Tools::vShow("ok");
}//System::Void CMainHefanForm::v_create_test_config_muppets()


System::Void CMainHefanForm::v_get_case_names(vector<CString>  *pvCaseNames, bool  bTuning)
{

	if  (bTuning == true)
	{
		pvCaseNames->push_back("114d07");
		pvCaseNames->push_back("162b05");
		pvCaseNames->push_back("104059");
		pvCaseNames->push_back("128083");
		pvCaseNames->push_back("144088");
		pvCaseNames->push_back("g120080");
	}//if  (bTuning == true)
	else
	{
		pvCaseNames->push_back("104b00");
		pvCaseNames->push_back("104b01");
		pvCaseNames->push_back("104b02");
		pvCaseNames->push_back("104b03");
		pvCaseNames->push_back("104b04");
		pvCaseNames->push_back("104b05");
		pvCaseNames->push_back("104b06");
		pvCaseNames->push_back("104b07");
		pvCaseNames->push_back("104b08");
		pvCaseNames->push_back("104b09");
		pvCaseNames->push_back("104d00");
		pvCaseNames->push_back("104d01");
		pvCaseNames->push_back("104d02");
		pvCaseNames->push_back("104d03");
		pvCaseNames->push_back("104d04");
		pvCaseNames->push_back("104d05");
		pvCaseNames->push_back("104d06");
		pvCaseNames->push_back("104d07");
		pvCaseNames->push_back("104d08");
		pvCaseNames->push_back("104d09");
		pvCaseNames->push_back("114b00");
		pvCaseNames->push_back("114b01");
		pvCaseNames->push_back("114b02");
		pvCaseNames->push_back("114b03");
		pvCaseNames->push_back("114b04");
		pvCaseNames->push_back("114b05");
		pvCaseNames->push_back("114b06");
		pvCaseNames->push_back("114b07");
		pvCaseNames->push_back("114b08");
		pvCaseNames->push_back("114b09");
		pvCaseNames->push_back("114d00");
		pvCaseNames->push_back("114d01");
		pvCaseNames->push_back("114d02");
		pvCaseNames->push_back("114d03");
		pvCaseNames->push_back("114d04");
		pvCaseNames->push_back("114d05");
		pvCaseNames->push_back("114d06");
		pvCaseNames->push_back("114d07");
		pvCaseNames->push_back("114d08");
		pvCaseNames->push_back("114d09");
		pvCaseNames->push_back("128b00");
		pvCaseNames->push_back("128b01");
		pvCaseNames->push_back("128b02");
		pvCaseNames->push_back("128b03");
		pvCaseNames->push_back("128b04");
		pvCaseNames->push_back("128b05");
		pvCaseNames->push_back("128b06");
		pvCaseNames->push_back("128b07");
		pvCaseNames->push_back("128b08");
		pvCaseNames->push_back("128b09");
		pvCaseNames->push_back("128d00");
		pvCaseNames->push_back("128d01");
		pvCaseNames->push_back("128d02");
		pvCaseNames->push_back("128d03");
		pvCaseNames->push_back("128d04");
		pvCaseNames->push_back("128d05");
		pvCaseNames->push_back("128d06");
		pvCaseNames->push_back("128d07");
		pvCaseNames->push_back("128d08");
		pvCaseNames->push_back("128d09");
		pvCaseNames->push_back("144b00");
		pvCaseNames->push_back("144b01");
		pvCaseNames->push_back("144b02");
		pvCaseNames->push_back("144b03");
		pvCaseNames->push_back("144b04");
		pvCaseNames->push_back("144b05");
		pvCaseNames->push_back("144b06");
		pvCaseNames->push_back("144b07");
		pvCaseNames->push_back("144b08");
		pvCaseNames->push_back("144b09");
		pvCaseNames->push_back("144d00");
		pvCaseNames->push_back("144d01");
		pvCaseNames->push_back("144d02");
		pvCaseNames->push_back("144d03");
		pvCaseNames->push_back("144d04");
		pvCaseNames->push_back("144d05");
		pvCaseNames->push_back("144d06");
		pvCaseNames->push_back("144d07");
		pvCaseNames->push_back("144d08");
		pvCaseNames->push_back("144d09");
		pvCaseNames->push_back("162b00");
		pvCaseNames->push_back("162b01");
		pvCaseNames->push_back("162b02");
		pvCaseNames->push_back("162b03");
		pvCaseNames->push_back("162b04");
		pvCaseNames->push_back("162b05");
		pvCaseNames->push_back("162b06");
		pvCaseNames->push_back("162b07");
		pvCaseNames->push_back("162b08");
		pvCaseNames->push_back("162b09");
		pvCaseNames->push_back("162d00");
		pvCaseNames->push_back("162d01");
		pvCaseNames->push_back("162d02");
		pvCaseNames->push_back("162d03");
		pvCaseNames->push_back("162d04");
		pvCaseNames->push_back("162d05");
		pvCaseNames->push_back("162d06");
		pvCaseNames->push_back("162d07");
		pvCaseNames->push_back("162d08");
		pvCaseNames->push_back("162d09");
		pvCaseNames->push_back("104050");
		pvCaseNames->push_back("104051");
		pvCaseNames->push_back("104052");
		pvCaseNames->push_back("104053");
		pvCaseNames->push_back("104054");
		pvCaseNames->push_back("104055");
		pvCaseNames->push_back("104056");
		pvCaseNames->push_back("104057");
		pvCaseNames->push_back("104058");
		pvCaseNames->push_back("104059");
		pvCaseNames->push_back("114052");
		pvCaseNames->push_back("114053");
		pvCaseNames->push_back("114054");
		pvCaseNames->push_back("114055");
		pvCaseNames->push_back("114056");
		pvCaseNames->push_back("114057");
		pvCaseNames->push_back("114058");
		pvCaseNames->push_back("114059");
		pvCaseNames->push_back("114060");
		pvCaseNames->push_back("114061");
		pvCaseNames->push_back("128078");
		pvCaseNames->push_back("128079");
		pvCaseNames->push_back("128080");
		pvCaseNames->push_back("128081");
		pvCaseNames->push_back("128082");
		pvCaseNames->push_back("128083");
		pvCaseNames->push_back("128084");
		pvCaseNames->push_back("128085");
		pvCaseNames->push_back("128086");
		pvCaseNames->push_back("128087");
		pvCaseNames->push_back("144079");
		pvCaseNames->push_back("144080");
		pvCaseNames->push_back("144081");
		pvCaseNames->push_back("144082");
		pvCaseNames->push_back("144083");
		pvCaseNames->push_back("144084");
		pvCaseNames->push_back("144085");
		pvCaseNames->push_back("144086");
		pvCaseNames->push_back("144087");
		pvCaseNames->push_back("144088");
		pvCaseNames->push_back("162093");
		pvCaseNames->push_back("162094");
		pvCaseNames->push_back("162095");
		pvCaseNames->push_back("162096");
		pvCaseNames->push_back("162097");
		pvCaseNames->push_back("162098");
		pvCaseNames->push_back("162099");
		pvCaseNames->push_back("162100");
		pvCaseNames->push_back("162101");
		pvCaseNames->push_back("162102");
		pvCaseNames->push_back("g120b00");
		pvCaseNames->push_back("g120b01");
		pvCaseNames->push_back("g120b02");
		pvCaseNames->push_back("g120b03");
		pvCaseNames->push_back("g120b04");
		pvCaseNames->push_back("g120b05");
		pvCaseNames->push_back("g120b06");
		pvCaseNames->push_back("g120b07");
		pvCaseNames->push_back("g120b08");
		pvCaseNames->push_back("g120b09");
		pvCaseNames->push_back("g120d00");
		pvCaseNames->push_back("g120d01");
		pvCaseNames->push_back("g120d02");
		pvCaseNames->push_back("g120d03");
		pvCaseNames->push_back("g120d04");
		pvCaseNames->push_back("g120d05");
		pvCaseNames->push_back("g120d06");
		pvCaseNames->push_back("g120d07");
		pvCaseNames->push_back("g120d08");
		pvCaseNames->push_back("g120d09");
		pvCaseNames->push_back("g120074");
		pvCaseNames->push_back("g120075");
		pvCaseNames->push_back("g120076");
		pvCaseNames->push_back("g120077");
		pvCaseNames->push_back("g120078");
		pvCaseNames->push_back("g120079");
		pvCaseNames->push_back("g120080");
		pvCaseNames->push_back("g120081");
		pvCaseNames->push_back("g120082");
		pvCaseNames->push_back("g120083");

	
	}//else  if  (bTuning == true)
	

}//System::Void CMainHefanForm::v_get_case_names(vector<CString>  *pvCaseNames, bool  bTuning)





CError  e_extract_from_summary(System::Windows::Forms::ListBox *  listComm, FILE  *pfSource, vector<CString> *pvPaths)
{
	CError  c_err;

	CString  s_line;
	CString  s_path;

	//int  i_path_word = 21;LFL
	int  i_path_word = 19; //EONs
	int  i_last_index;

	while  (!feof(pfSource))
	{
		s_line = Tools::sReadLine(pfSource);

		i_last_index = 0;
		s_path = "";
		for  (int  i_word = 0; i_word < i_path_word; i_word++)
		{
			s_path = Tools::sExtractFromString(s_line, i_last_index, &i_last_index);
		}//for  (int  i_word = 0; i_word < i_path_word; i_word++)

		pvPaths->push_back(s_path);

		
		/*listComm->Items->Add( (System::String *) s_line);
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
		listComm->Items->Add( (System::String *) s_path);
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();//*/
	}//while  (!feof(pfSource))
	
	return(c_err);
}//CError  e_extract_from_summary(FILE  *pfSource)




CError  e_extract_from_expriment(System::Windows::Forms::ListBox *  listComm, CString  sExpPath, int *piNewCTsCreated)
{
	CError  c_err;

	*piNewCTsCreated = 0;

	FILE  *pf_exp_run_file;

	//::Tools::vShow(sExpPath);

	//sExpPath.Replace(".txt", ".txt_RUN.txt");//LFL
	sExpPath = sExpPath.Mid(0, sExpPath.GetLength() - 5);
	sExpPath += "_RUN.txt";


	//::Tools::vShow(sExpPath);
	CString s_dir;
	s_dir = ::Tools::sGetDirectory(sExpPath);
	sExpPath.Replace(s_dir, "");
	//::Tools::vShow(sExpPath);

	/*FILE  *pf_test;
	pf_test = fopen("zzzz_test.txt", "w+");
	fprintf(pf_test,sExpPath);
	fclose(pf_test);//*/

	/*listComm->Items->Add( (System::String *) sExpPath);
	listComm->SelectedIndex  =  listComm->Items->Count - 1;
	listComm->Refresh();//*/


	pf_exp_run_file = fopen(sExpPath, "r");
	
	if  (pf_exp_run_file  !=  NULL)
	{
		CString  s_line;
		int  i_index;
		while(!feof(pf_exp_run_file))
		{
			s_line = Tools::sReadLine(pf_exp_run_file);
			//i_index = Tools::iSearch(s_line, "increase CT number");//LFL
			i_index = Tools::iSearch(s_line, "removing virginity start fitness");//EONs

			if  (i_index >= 0)  (*piNewCTsCreated)++;
		}//while(!feof(pf_exp_run_file))

		fclose(pf_exp_run_file);
	}//if  (pf_exp_run_file  !=  NULL)
	else
		c_err.vPutError("File not found");

	return(c_err);
};//CError  e_extract_from_expriment(System::Windows::Forms::ListBox *  listComm, CString  sExpPath, int *piNewCTsCreated)







class CNumber
{
    public:
        CNumber();
        CNumber(CNumber &otherNumber);
        ~CNumber();
        void operator= (CNumber &secondNumber);
        void operator= (int value);
        CNumber operator+ (CNumber &secondNumber);

    private:
        int* p_number;
};


void  v_generate(CString  sSettSource, CString  sSettDest, int iSeed)
{
	FILE  *pf_source;

	pf_source = fopen(sSettSource, "r");

	if  (pf_source != NULL)
	{
		FILE  *pf_dest;
		CString  s_info,  s_comment;

		pf_dest = fopen(sSettDest, "w+");

		while (!feof(pf_source))
		{
			CHefanSystem::vReadLine(pf_source, &s_info,  &s_comment);

			//::MessageBox(NULL, s_info, s_info, MB_OK);


			if  (s_comment == "evaluation_problem_seed")
			{
				CString  s_buf;

				//::MessageBox(NULL, "none", "none", MB_OK);

				s_buf.Format("%d", iSeed);
				fprintf(pf_dest, s_buf + "\\\\" + s_comment + "\n");
			
			}//if  (s_comment == "evaluation_problem_seed")
			else
			{
				if  ( (s_info != "")&&(s_info != "a") )
					fprintf(pf_dest, s_info + "\\\\" + s_comment + "\n");
			}//else if  (s_comment == "evaluation_problem_seed")			
		}//while (!feof(pf_source))

		fprintf(pf_dest, "\n");
		fclose(pf_dest);
		fclose(pf_source);

		return;
	}//if  (pf_source != NULL)
}//void  v_generate(CString  sSettSource, CString  sSettDest)



void  v_gen_sett()
{
	CString  s_templ;
	int  i_seed_num = 30;
	s_templ = "settings_mpdsmga2";

	CString  s_templ_file;
	s_templ_file = s_templ + ".txt";

	CString  s_dest;

	FILE  *pf_serie;
	pf_serie = fopen("zzz_serie.txt", "w+");
	for  (int  i_seed = 0; i_seed < i_seed_num; i_seed++)
	{
		s_dest.Format("%s_%d.txt", (LPCSTR) s_templ, i_seed);
		v_generate(s_templ_file, s_dest, i_seed);

		fprintf(pf_serie, s_dest + "\\\\1\n");
	}//for  (int  i_seed = 0; i_seed < i_seed_num; i_seed++)

	fclose(pf_serie);
	//::MessageBox(NULL, "none", "none", MB_OK);
}//void  v_gen_sett()


bool  b_gen_test_file(CString  sDestFile)
{

	double  d_x, d_y, d_fun;
	double  d_noise;

	FILE  *pf_test;

	pf_test = fopen(sDestFile, "w+");
	if  (pf_test == NULL)  return(false);

	for  (int  ii = 0; ii < 300; ii++)
	{
		d_x = MyMath::dRand();
		d_y = MyMath::dRand();
		//d_sin = ::sin(d_x*d_y);
		
		d_noise = MyMath::dRand() * 0.1;
		d_noise = d_noise - 0.05;

		d_fun = d_x*d_y + d_x*d_x + d_noise;

		fprintf(pf_test, "%.4lf; %.4lf; %.4lf;\n", d_x, d_y, d_fun);
	}//for  (int  ii = 0; ii < 100; ii++)
	
	fclose(pf_test);
	return(true);
}//void  v_gen_test_file(CString  sDestFile)


/*#define  DEF_NUM 11

class  CNum
{
public:
	//to add
	CNum() {pi_num = new int; *pi_num = DEF_NUM;}
	CNum(CNum &cOther) 
	{
		pi_num = new int;
		*pi_num = *(cOther.pi_num);
	}//CNum(CNum &cOther) 

	CNum  operator+(CNum &cOther) 
	{
		CNum  c_res;

		*(c_res.pi_num) = *pi_num + *(cOther.pi_num);
			
		return(c_res);
	};//CNum  operator+(CTab &cOther) 

	void  operator=(CNum &cOther)
	{
		*pi_num = *(cOther.pi_num);
	}//void  operator=(CNum &cOther)

	void  operator=(int iVal)
	{
		*pi_num = iVal;
	}//void  operator=(int iVal)

	//to add end



	~CNum()  {if  (pi_num != NULL) delete pi_num;}
	int  iGetVal() {return(*pi_num);}


private:
	int  *pi_num;
};//class  CNum


void  v_print(int iVal)
{
	CString  s_buf;

	s_buf.Format("%d", iVal);
	::MessageBox(NULL, s_buf, s_buf, MB_OK);
}//void  v_print(int iVal)


void  v_test()
{
	CNum c_t0, c_t1, c_t2;

	v_print(c_t2.iGetVal());//wypisze 11

	c_t0 = 2;
	c_t1 = 3;

	CNum c_sum;

	c_t0 + c_t1;
	c_sum = c_t0 + c_t1;

	v_print(c_sum.iGetVal());
}//void  v_test()*/


void  v_print2(int iVal)
{
	CString  s_buf;

	s_buf.Format("%d", iVal);
	::MessageBox(NULL, s_buf, s_buf, MB_OK);
}//void  v_print(int iVal)




/*class  CNode
{
public:
	//to add
	CNode()  {pi_val = new int;}
	void  vPrint(){v_print(*pi_val);  for  (int ii = 0; ii < v_kids.size(); ii++) v_kids.at(ii)->vPrint();};
	

	CNode(int  iVal)  {pi_val = new int(iVal);}
	void  vAdd(CNode  *pcKid)  {v_kids.push_back(pcKid);}
	void  vSetVal(int iVal)  {*pi_val = iVal;}
private:
	int  *pi_val;
	vector<CNode  *>  v_kids;
};//class  CNode


class  CTree
{
public:
	//to add
	CTree()  {pc_root = new CNode();}

	CNode  *pcGetRoot() {return(pc_root);}
	void  vPrint()  {pc_root->vPrint();}
private:
	CNode  *pc_root;
};//class  CTree*/


/*class  CNode
{
public:
	CNode(int  iVal)  {pi_val = new int(iVal);}
	void  vAdd(CNode  *pcKid)  {v_kids.push_back(pcKid);}
	void  vSetVal(int iVal)  {*pi_val = iVal;}
private:
	int  *pi_val;
	vector<CNode  *>  v_kids;
};//class  CNode


class  CTree
{
public:
	CNode  *pcGetRt() {return(pc_root);}
	void  vPrint()  {pc_root->vPrint();}
private:
	CNode  *pc_root;
};//class  CTree




void  v_test()
{
	CTree c_tree_0;
	c_tree_0.pcGetRt()->vSetVal(1);
	c_tree_0.pcGetRt()->vAdd(new CNode(2));

	CNode  *pc_buf;
	pc_buf = new CNode(3);
	pc_buf->vAdd(new CNode(4));
	c_tree_0.pcGetRt()->vAdd(pc_buf);

	CTree *pc_copy = new CTree(c_tree_0);

	c_tree_0.vPrint();
	pc_copy->vPrint();
	delete  pc_copy;
}//void  v_test()*/

/*
void  v_alloc(int  iX, int iY, int  ***piTab) {};
void  v_delete(int  ***piTab) {};

void  v_test()
{
	int  **pi_tab;

	v_alloc(6,5, &pi_tab);
	for  (int ix = 0; ix < 6; ix++)
	{
		for  (int iy = 0; iy < 5; iy++)
		{
			pi_tab[ix][iy] = ix*iy;
		}//for  (int iy = 0; iy < 5; iy++)
	}//for  (int ix = 0; ix < 6; ix++)

	v_delete(&pi_tab);
}//void  v_test()*/


/*class  CTab
{
public:
	~CTab()  {if (pi_tab != NULL) delete pi_tab;}
	void  vSetSize(int iSize)  {pi_tab = new int[iSize];}

	int  *pi_tab;
};//class  CTab


void  v_test()
{
	CTab  c_t0, c_t1;

	c_t0.vSetSize(2);
	c_t1.vSetSize(1);
	c_t0.pi_tab[0] = 0;
	c_t0.pi_tab[1] = 1;
	c_t1.pi_tab[0] = 4;

	CTab  c_sum;
	//c_sum = c_t0 + c_t1;
}//void  v_test()*/

/*template <class T>
class  CTab
{
public:
	CTab()  {pi_tab = new T[1];}
	~CTab()  {if (pi_tab != NULL) delete pi_tab;}
	void  vSetSize(int iSize)  {pi_tab = new int[iSize];}
	T  tGetSum();

	T  *pi_tab;
};//class  CTab


void  v_test()
{
	CTab<int>  c_t0;
}//void  v_test()*/


/*void  v_print(int  A)
{
	v_print2(A);
}//void  v_print(int  A)


void  v_print(int  *A)
{
	v_print2(*A);
}//void  v_print(int  A)*/


/*

class CBaseOp
{
public:
	virtual CString sToStr() = 0;
	virtual void vDoOp() = 0;
private:
	int i_val;
};//class CBaseOp

class CAddOp : public CBaseOp
{
public:
	void vDoOp(){i_val++;}
};//class CAddOp : public CBaseOp


void  v_test()
{
	CBaseOp  **pi_ops;
	pi_ops = new CBaseOp*[2];

	CAddOp c_add;
	pi_ops[0] = &c_add;
	CSubOp c_sub;
	pi_ops[1] = &c_sub;
}//void  v_test()*/



System::Void CMainHefanForm::but_get_ct_create_num_Click(System::Object*  sender, System::EventArgs*  e)
{
//	v_test();
	//return;
	//b_gen_test_file("ZMPO_lista_4_03_sin_x.txt");  return;
	//b_gen_test_file("ZMPO_lista_4_04_sin_x_y.txt");  return;
	//b_gen_test_file("ZMPO_lista_4_05_x_y_pl_x_x.txt");  return;
	//b_gen_test_file("ZMPO_lista_4_05_x_y_pl_x_x_noise.txt");  return;

	
	CError  c_err;

	CString  s_name, s_buf;

	s_name = "z_summary_2.txt";
	FILE  *pf_summary;

	pf_summary = fopen(s_name, "r");
	int  i_ct_creations;

	if  (pf_summary  != NULL)
	{
		FILE  *pf_result;

		pf_result = fopen("zz_ctCreated.txt", "w+");
		vector<CString>  v_paths;
		c_err = e_extract_from_summary(list_comm, pf_summary, &v_paths);

		if  (!c_err)
		{
			for  (int  ii = 0; ii < v_paths.size(); ii++)
			{
				//::MessageBox(NULL, v_paths.at(ii), v_paths.at(ii), MB_OK);
				c_err = e_extract_from_expriment(list_comm, v_paths.at(ii), &i_ct_creations);

				if  (c_err)
					s_buf = "NOT succ: " + v_paths.at(ii);
				else
				{
					s_buf.Format("%d \t %s\n", i_ct_creations, v_paths.at(ii));
					fprintf(pf_result, s_buf);
					s_buf.Format("OK: %d  %s", i_ct_creations, v_paths.at(ii));
				}//else  if

				list_comm->Items->Add( (System::String *) s_buf);
				list_comm->SelectedIndex  =  list_comm->Items->Count - 1;
				list_comm->Refresh();
			}//for  (int  ii = 0; ii < v_paths->size(); ii++)
		}//if  (!c_err)

		fclose(pf_result);
		fclose(pf_summary);
	}//if  (pf_summary  != NULL)

	



}//System::Void CMainHefanForm::but_get_ct_create_num_Click(System::Object*  sender, System::EventArgs*  e)



System::Void CMainHefanForm::but_run_graph_Click(System::Object*  sender, System::EventArgs*  e)
{
	v_gen_sett();
	//v_create_test_config_muppets(false);

	return;

	CError  c_err;
	CString  s_buf;

	OpenFileDialog* openFileDialog1 = new OpenFileDialog();
 
    //openFileDialog1->InitialDirectory = S"D:\\praca dyplomowa - nowy interfejs\\publikacja\\FD_init" ;
	openFileDialog1->Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
    openFileDialog1->FilterIndex = 0;
    openFileDialog1->RestoreDirectory = true;
	openFileDialog1->Multiselect  =  false;

    if(openFileDialog1->ShowDialog() == DialogResult::OK)
	{
		CString  s_run_file, s_graph_file;
		s_run_file  =  (CString)  openFileDialog1->FileNames[0];
		s_graph_file  =  s_run_file + "_graph.txt";
		//s_set_of_files_name  =  "D:\\co vmea gen pop tuning\\part1.txt";


		FILE  *pf_run_file;
		pf_run_file  =  fopen((LPCSTR)  s_run_file, "r+");

		if  (pf_run_file  ==  NULL)
		{
			s_buf.Format("Can not open file %s", (LPCSTR) s_run_file);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
			return;
		}//if  (pf_run_file  ==  NULL)

		
		FILE  *pf_run_file_graph;
		pf_run_file_graph  =  fopen((LPCSTR)  s_graph_file, "w+");

		if  (pf_run_file_graph  ==  NULL)
		{
			s_buf.Format("Can not open file %s", (LPCSTR) s_graph_file);
			fclose(pf_run_file);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
			return;
		}//if  (pf_run_file_graph  ==  NULL)


		CString  s_GEN = "Generation: ";
		CString  s_CT = " ct number: ";
		CString  s_BEST = " (best fitness: ";
		CString  s_AVR = ") average: ";
		CString  s_AVR_END = " best - average:";
		CString  s_TIME = "[time passed:";
		CString  s_TIME_END = "]";


		CString  s_line;
		CString  s_number;
		int  i_mark_start, i_mark_end;
		int  i_buf;
		double  d_buf;

		fprintf(pf_run_file_graph, "Generation\tCT number\tBest\tAverage\tTime\n\n ");

		bool  b_end = false;
		bool  b_debug = false;
		while  ( (!feof(pf_run_file))&&(b_end  ==  false) )
		{
			CHefanSystem::vReadLine(pf_run_file, &s_line, &s_buf);

						
			if  (s_line.Find(s_GEN)  ==  0)
			{
				i_mark_start = s_line.Find(s_GEN) + s_GEN.GetLength();
				i_mark_end = s_line.Find(s_CT, i_mark_start);
				s_number = s_line.Mid(i_mark_start, i_mark_end - i_mark_start);
				if  (b_debug) ::MessageBox(NULL, s_number, "", MB_OK);
				i_buf  =  atoi(s_number);
				fprintf(pf_run_file_graph, "%d\t", i_buf);
				



				i_mark_start = i_mark_end + s_CT.GetLength();
				i_mark_end = s_line.Find(s_BEST, i_mark_start);
				s_number = s_line.Mid(i_mark_start, i_mark_end - i_mark_start);
				if  (b_debug) ::MessageBox(NULL, s_number, "", MB_OK);
				i_buf  =  atoi(s_number);
				fprintf(pf_run_file_graph, "%d\t", i_buf);


				i_mark_start = i_mark_end + s_BEST.GetLength();
				i_mark_end = s_line.Find(s_AVR, i_mark_start);
				s_number = s_line.Mid(i_mark_start, i_mark_end - i_mark_start);
				if  (b_debug) ::MessageBox(NULL, s_number, "", MB_OK);
				d_buf  =  atof(s_number);
				fprintf(pf_run_file_graph, "%.16lf\t", d_buf);


				i_mark_start = i_mark_end + s_AVR.GetLength();
				i_mark_end = s_line.Find(s_AVR_END, i_mark_start);
				s_number = s_line.Mid(i_mark_start, i_mark_end - i_mark_start);
				if  (b_debug) ::MessageBox(NULL, s_number, "", MB_OK);
				d_buf  =  atof(s_number);
				fprintf(pf_run_file_graph, "%.16lf\t", d_buf);


				
				i_mark_start = s_line.Find(s_TIME, i_mark_end) + s_TIME.GetLength();
				i_mark_end = s_line.Find(s_TIME_END, i_mark_start);
				s_number = s_line.Mid(i_mark_start, i_mark_end - i_mark_start);
				if  (b_debug) ::MessageBox(NULL, s_number, "", MB_OK);
				d_buf  =  atof(s_number);
				fprintf(pf_run_file_graph, "%.8lf\n", d_buf);
				
				if  (b_debug) b_end  =  true;
			}//if  (s_line.Find("Generation: ")  ==  0)

		}//while  (!feof(pf_set_of_files))

		::MessageBox(NULL, "Done", "Info", MB_OK);
		

		fclose(pf_run_file);
		fclose(pf_run_file_graph);

	}//if(openFileDialog1->ShowDialog() == DialogResult::OK)

};//System::Void CMainHefanForm::but_run_graph_Click(System::Object*  sender, System::EventArgs*  e)




System::Void CMainHefanForm::CMainHefanForm_Shown(System::Object*  sender, System::EventArgs*  e)
{
	if  (pc_system->sInParameters  !=  "")
	{
		CString  s_file_name, s_buf;
		FILE  *pf_in_file;

		s_file_name.Format("%s_entry.txt", pc_system->sInParameters);
		pf_in_file = fopen(s_file_name, "r");
		if  (pf_in_file  ==  NULL)
		{
			s_buf.Format("Reading data input from in file (%s) unscuccessfull", s_file_name);
			list_comm->Items->Add((String *)s_buf);
			list_comm->Items->Add(S"Closing the system");
			list_comm->Refresh();
			
			System::Threading::Thread::Sleep(5000);
			Close();
		}//if  (pf_in_file  ==  NULL)

		
		CString  s_in_data;
		s_in_data = Tools::sReadLine(pf_in_file);
		fclose(pf_in_file);

		s_buf.Format("In parameters read: %s", s_in_data);
		list_comm->Items->Add((String *)s_buf);
		list_comm->Refresh();


		CError  c_err;		
		c_err  =  pc_system->eRunFile(s_in_data, list_params, list_comm);
		if  (c_err)
		{
			list_comm->Items->Add(S"An error occured");
			list_comm->Items->Add((String *)c_err.csMessage);
			
			list_comm->Refresh();			
		}//if  (c_err)

		System::Threading::Thread::Sleep(5000);
		Close();

	}//if  (pc_system->sInParameters  !=  "")

};//System::Void CMainHefanForm::CMainHefanForm_Shown(System::Object*  sender, System::EventArgs*  e)
