#include  "stdafx.h"
#include  "TrajectorySetsFinder.h"


using  namespace  TopologyTranslator;
using  namespace  TrajectorySetsFinder;
using namespace  MyMath;
using namespace System::IO;


#pragma warning(disable:4996)





//-------------------------------------------------------------------------------------------
//--------------------------implementation of class CSingleIslandPopulation--------------------------


CSingleIslandPopulation::CSingleIslandPopulation(CTrajectorySetsFinder  *pcParent)
{
	pc_parent = pcParent;
	i_pop_size = 0;
	pc_island_pop = NULL;
}//CSingleIslandPopulation::CSingleIslandPopulation(CTrajectorySetsFinder  *pcParent)


CSingleIslandPopulation::~CSingleIslandPopulation()
{
	if  (pc_island_pop == NULL)  delete  [] pc_island_pop;
	delete pc_best;
}//CSingleIslandPopulation::~CSingleIslandPopulation()




CError  CSingleIslandPopulation::eCreatePop
	(long lPopulationNumberDiv4, long lPenalty, double dNewCtDisturbedGeneDisturbedProb, vector  <CSingleIslandPopulation  *>  *pvIslands)
{
	CError  c_err;


	if  (pc_parent == NULL)
	{
		c_err.vPutError("No CTrajectorySetsFinder defined for a subpopulation in Island Model");
		return(c_err);
	}//if  (pc_parent == NULL)

	i_pop_size = lPopulationNumberDiv4 * 4;

	pc_island_pop = new CSingleTrajectorySet[i_pop_size];
	pc_parent->b_init_population(pc_island_pop, i_pop_size, lPenalty);

	pc_best = new CSingleTrajectorySet();
	pc_parent->b_init_population(pc_best, 1, lPenalty);

	pc_best->dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty);


	b_best_improved = false;


	int  i_selected_istland;
	//i_selected_istland = lRand(pvIslands->size());


	CSingleTrajectorySet  *pc_template_individual;
	int  i_template_island;
	for  (int ii = 0; ii < i_pop_size; ii++)
	{
		i_selected_istland = lRand(pvIslands->size());
		pc_template_individual = pvIslands->at(i_selected_istland)->pc_best;

		pc_island_pop[ii].vCopy(pc_template_individual);
		pc_island_pop[ii].vRandomize(pc_parent->pl_capacities, dNewCtDisturbedGeneDisturbedProb);
		pc_island_pop[ii].pc_net_sim->iRemoveAllConnections();
		pc_island_pop[ii].b_set_all_conns(pc_parent->pl_capacities);
		pc_island_pop[ii].dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty);
	}//for  (int ii = 0; ii < i_pop_size; ii++)



	return(c_err);
}//CError  CSingleIslandPopulation::eCreatePop



CError  CSingleIslandPopulation::eCreatePop
	(long lPopulationNumberDiv4, long lPenalty, vector  <CMessyPattern  *>  *pvPatternPool, vector  <CSingleIslandPopulation  *>  *pvIslands)
{
	CError  c_err;


	if  (pc_parent == NULL)
	{
		c_err.vPutError("No CTrajectorySetsFinder defined for a subpopulation in Island Model");
		return(c_err);
	}//if  (pc_parent == NULL)

	i_pop_size = lPopulationNumberDiv4 * 4;

	pc_island_pop = new CSingleTrajectorySet[i_pop_size];
	pc_parent->b_init_population(pc_island_pop, i_pop_size, lPenalty);

	pc_best = new CSingleTrajectorySet();
	pc_parent->b_init_population(pc_best, 1, lPenalty);

	pc_best->dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty);


	b_best_improved = false;


	int  i_selected_istland;
	i_selected_istland = lRand(pvIslands->size());


	CSingleTrajectorySet  *pc_template_individual;
	int  i_template_island;
	for  (int ii = 0; ii < i_pop_size; ii++)
	{
		//i_selected_istland = lRand(pvIslands->size());
		pc_template_individual = pvIslands->at(i_selected_istland)->pc_best;

		pc_island_pop[ii].vCopy(pc_template_individual);
		pc_island_pop[ii].vRandomize_LLDSI(pc_parent);
		pc_island_pop[ii].pc_net_sim->iRemoveAllConnections();
		pc_island_pop[ii].b_set_all_conns(pc_parent->pl_capacities);
		pc_island_pop[ii].dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty);
	}//for  (int ii = 0; ii < i_pop_size; ii++)

	return(c_err);
}//CError  CSingleIslandPopulation::eCreatePop




CError  CSingleIslandPopulation::eCreatePop(long lPopulationNumberDiv4, long lPenalty)
{
	CError  c_err;

	if  (pc_parent == NULL)
	{
		c_err.vPutError("No CTrajectorySetsFinder defined for a subpopulation in Island Model");
		return(c_err);
	}//if  (pc_parent == NULL)

	i_pop_size = lPopulationNumberDiv4 * 4;

	pc_island_pop = new CSingleTrajectorySet[i_pop_size];
	pc_parent->b_init_population(pc_island_pop, i_pop_size, lPenalty);

	pc_best = new CSingleTrajectorySet();
	pc_parent->b_init_population(pc_best, 1, lPenalty);

	pc_best->dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty);

	b_best_improved = false;

	return(c_err);
}//CError  CSingleIslandPopulation::eCreatePop(long lPopulationNumberDiv4, long lPenalty)



CError  CSingleIslandPopulation::eRunPop
	(
	System::Windows::Forms::ListBox *  listComm,
	int  iIsland, 
	long  lPenalty,
	double  dCrossPossibility,  double  dMutatePossibility,
	double  dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
	double  dRandomCrossPossibility,
	int  iLinkageGenWay,
	long lGenNum
	)
{
	CError  c_err;

	if  (pc_parent == NULL)
	{
		c_err.vPutError("No CTrajectorySetsFinder defined for a subpopulation in Island Model");
		return(c_err);
	}//if  (pc_parent == NULL)

	CSingleTrajectorySet *pc_best_buf;
	
	pc_parent->v_execute_evolution_for_single_pop
		(
		listComm,
		&pc_best_buf, &d_avr_fit,
		&pc_island_pop, i_pop_size/4,
		iIsland,
		lPenalty,
		dCrossPossibility,  dMutatePossibility,
		dCrossPossibilityLowLevel,  dMutatePossibilityLowLevel,
		dRandomCrossPossibility,
		lGenNum
		);

	if  (pc_best->dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty)  <  pc_best_buf->dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty))  
	{
		CString  s_buf;

		s_buf.Format("Best improvement: (%.8lf)->(%.8lf)", pc_best->dGetFOMLevel(), pc_best_buf->dGetFOMLevel());
		listComm->Items->Add((System::String *) s_buf);
		listComm->SelectedIndex  =  listComm->Items->Count - 1;
		listComm->Refresh();	


		if  (iLinkageGenWay == VGA_PARAM_IM_LINKAGE_GEN_NO_AT_BEST_IMPROVEMENT)
		{
			CMessyPattern  *pc_new_pattern;
			pc_new_pattern = pc_best->pcGetPatternByDifference(pc_best_buf);
			if  (pc_new_pattern  !=  NULL)  pc_parent->pv_pattern_pool->push_back(pc_new_pattern);
			pc_parent->v_pattern_number_control_new(true);
		}//if  (iLinkageGenWay == VGA_PARAM_IM_LINKAGE_GEN_NO_AT_BEST_IMPROVEMENT)

		pc_best->vCopy(pc_best_buf);
		b_best_improved = true;
	}//if  (pc_best->dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty)  <  pc_best_buf->dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty))  


	return(c_err);
}//CError  CSingleIslandPopulation::eRunPop


//-------------------------------------------------------------------------------------------
//--------------------------implementation of class CTrajectorySetsFinder--------------------------


CTrajectorySetsFinder::CTrajectorySetsFinder()
{

	i_number_of_pairs  =  0;

	pc_population  = NULL;
	pc_new_population  =  NULL;
	
//	pd_fom_values  =  NULL;
	pc_best_species  =  NULL;

	pl_capacities  =  NULL;

	pl_start_finish_pairs  =  NULL;

	l_penalty = 0;

	pv_pattern_pool = NULL;
	pv_population = NULL;
	
	
}//CTrajectorySetsFinder::CTrajectorySetsFinder()






CTrajectorySetsFinder::~CTrajectorySetsFinder()
{

	
	if  (pc_population  !=  NULL)
		delete  []  pc_population;


//	if  (pc_new_population  !=  NULL)
//		delete  []  pc_new_population;


/*	if  (pd_fom_values !=  NULL)
		delete  []  pd_fom_values;*/

	if  (pc_best_species  !=  NULL)
		delete  []  pc_best_species;

	if  (pl_capacities  !=  NULL)
		delete  []  pl_capacities;


	if	(pl_start_finish_pairs  !=  NULL)
		delete  []  pl_start_finish_pairs;



	if  (pv_population  !=  NULL)
	{
		for  (int  ii = 0; ii < (int) pv_population->size(); ii++)
			delete  pv_population->at(ii);
		delete  pv_population;
	}//if  (pv_population  !=  NULL)


	for  (int  ii = 0; ii < (int) v_memo_cts.size(); ii++)
		delete  v_memo_cts.at(ii);
	v_memo_cts.clear();


	if  (pv_pattern_pool  != NULL)
	{
		for  (int  ii = 0; ii < (int) pv_pattern_pool->size(); ii++)
			delete  pv_pattern_pool->at(ii);
		delete  pv_pattern_pool;
	}//if  (pv_pattern_pool  != NULL)

	
}//CTrajectorySetsFinder::~CTrajectorySetsFinder()





int  CTrajectorySetsFinder::iGetShortestWays(int  iShortestWaysNumber, System::Windows::Forms::ListBox *  listComm)
{
	vector  <long *>  v_virt_ways;
	vector  <long>  v_virt_ways_lengths;

	if  (
		c_translator.iGetShortestWays(iShortestWaysNumber, &v_virt_ways, &v_virt_ways_lengths)
		!=  1
		)
	{
		for  (int  ii = 0; ii < (int) v_virt_ways.size(); ii++)
			delete  []  v_virt_ways.at(ii);

		return(-1);
	}//if  (


	CVirtualWay  *pc_new_vw, *pc_vw_buf;
	int  i_vw_input_res;

	for  (int  ii = 0; ii < (int) v_virt_ways.size(); ii++)
	{
		//now we create the proper virtual way and try to insert it into the virtual way database
		pc_new_vw  =  new  CVirtualWay;

		if  (pc_new_vw->bSetWay(v_virt_ways.at(ii), v_virt_ways_lengths.at(ii))  ==  false)
		{
			for  (int  ii = 0; ii < (int) v_virt_ways.size(); ii++)
				delete  []  v_virt_ways.at(ii);

			return(-1);
		}//if  (pc_new_vw->bSetWay(v_virt_ways.at(ii), v_virt_ways_lengths.at(ii))  ==  false)

		i_vw_input_res  =  c_virtual_ways.iInputNewVirtWay
			(
			pc_new_vw,  v_virt_ways.at(ii)[0],  v_virt_ways.at(ii)[v_virt_ways_lengths.at(ii) - 1],
			&pc_vw_buf, true
			);


		//virtual way not inserted because it already exists
		if  (i_vw_input_res  !=  1)
		{
			delete  pc_new_vw;
		}//if  (i_vw_input_res  ==  2)

	}//for  (int  ii = 0; ii < (int) v_virt_ways.size(); ii++)

	for  (int  ii = 0; ii < (int) v_virt_ways.size(); ii++)
		delete  []  (long *)  v_virt_ways.at(ii);

	return(1);
}//int  CTrajectorySetsFinder::iGetShortestWays(int  iShortestWaysNumber)





/*
returned values:
1  -  ok
0  -  memory allocation problem
*/
int   CTrajectorySetsFinder::iInputTrajectorySetToFind
	(long  *plNodePairs,  long  *plCapacities,  int  iNumberOfPairs)
{

	i_number_of_pairs  =  0;

	if  (pl_start_finish_pairs  !=  NULL)  
		delete []  pl_start_finish_pairs;

//	if  (pc_population  !=  NULL)
//		delete []  pc_population;


	if  (pl_capacities  !=  NULL)
		delete []  pl_capacities;

	

	pl_start_finish_pairs  =  new  long[iNumberOfPairs * 2];
	if  (pl_start_finish_pairs  ==  NULL)  return(0);


	pl_capacities  =  new  long  [iNumberOfPairs];
	if  (pl_capacities  ==  NULL)  return(0);



	i_number_of_pairs  =  iNumberOfPairs;

	for  (int  ii = 0; ii < i_number_of_pairs * 2;  ii++)
		pl_start_finish_pairs[ii]  =  c_translator.lTranslateNodeNum(plNodePairs[ii]);


	for  (int ii = 0; ii < i_number_of_pairs ;  ii++)
		pl_capacities[ii]  =  plCapacities[ii];
		


	return(1);
	

}//int   CTrajectorySetsFinder::iInputTrajectorySetToFind(long  *plNodePairs,  int  iNumberOfPairs)






/*
returned values:
1  -  ok
0  -  memory allocation problem

-5 - cannot open result file
*/
int  CTrajectorySetsFinder::iResultsCompare
		(
		System::Windows::Forms::ListBox *  listComm,
		CString  sReportFileName,
		CString  sTopologyFile, CString  sConFile, CString  sConName, CString  sFOMFuncMain, CString  sFOMFunc2,

		CString  sAlg1Name, CString  sAlg1File,
		CString  sAlg2Name, CString  sAlg2File,
		long  lPenalty
		)
{
	
	CSingleTrajectorySet  cDefinedSpecie1, cDefinedSpecie2;

	
	if  (
		cDefinedSpecie1.bInit
		(pl_start_finish_pairs, i_number_of_pairs, &c_virtual_ways, c_translator.pcGetSim(),  c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty)
		==
		false
		)
		return(-1);

	if  (
		cDefinedSpecie2.bInit
		(pl_start_finish_pairs, i_number_of_pairs, &c_virtual_ways, c_translator.pcGetSim(),  c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty)
		==
		false
		)
		return(-1);
	

	if  (b_input_defined_specie(&cDefinedSpecie1, sAlg1File, true)  !=  true)  return(-6);
	if  (b_input_defined_specie(&cDefinedSpecie1, sAlg1File, true)  !=  true)  return(-6);
	if  (b_input_defined_specie(&cDefinedSpecie2, sAlg2File, true)  !=  true)  return(-6);
	if  (b_input_defined_specie(&cDefinedSpecie2, sAlg2File, true)  !=  true)  return(-6);


	int  i_different_ways, i_the_same_ways;
	i_different_ways = 0;
	i_the_same_ways = 0;

	for  (int  ii = 0; ii < cDefinedSpecie1.i_number_of_pairs; ii++)
	{
		if  (
			cDefinedSpecie1.pc_trajectories[ii]
			==
			cDefinedSpecie2.pc_trajectories[ii]
			)
			i_the_same_ways++;
		else
			i_different_ways++;
	
	}//for  (int  ii = 0; ii < cDefinedSpecie1.i_number_of_pairs; ii++)




	FILE  *pf_report_file;
	
	if  (sReportFileName  !=  "")
	{
		if  (File::Exists(sReportFileName))
		{
			pf_report_file  =  fopen( (LPCSTR) sReportFileName, "a");
			if  (pf_report_file  ==  NULL)  
				return(-5);
		}//if  (File::Exists(sReportFileName))
		else
		{
			pf_report_file  =  fopen( (LPCSTR) sReportFileName, "w");
			if  (pf_report_file  ==  NULL)  
				return(-5);
		
			fprintf(pf_report_file, "connection name\t fittness 1\t fittness 2 \t total pairs \t common pairs \t diff pairs \t common pairs % \t diff pairs % \t fit value 1 \t fit value 2 \t fit change \t fit ch./ different pairs \n\n\n");
		}//else  if  (File::Exists(sReportFileName))

	}//if  (sPopulationFOMtrackingFile  !=  "")  
	else
	{
		return(-5);
	}//else if  (sPopulationFOMtrackingFile  !=  "")  


	CString  s_buf;
	double  d_perc_diffrent;
	d_perc_diffrent = i_different_ways;
	d_perc_diffrent = d_perc_diffrent / (i_different_ways + i_the_same_ways);

	double  d_fit_1, d_fit_2;
	d_fit_1  =  cDefinedSpecie1.dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty);
	d_fit_2  =  cDefinedSpecie2.dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty);

	double  d_fit_change;

	/*if  (d_fit_1  >  d_fit_2)
		d_fit_change = d_fit_2 / d_fit_1;
	else
	{*/
		if  (d_fit_2 == 0)
			d_fit_change = 0;
		else
			d_fit_change = (d_fit_1 - d_fit_2)/ d_fit_2;
	//}//else if  (d_fit_1  >  d_fit_2)
	//d_fit_change = 1.0  -  d_fit_change;


	CString  s_report_line;
	s_report_line.Format
		(
		"%s\t%s\t%s\t%d\t%d\t%d\t%.2lf\t%.2lf\t%.8lf\t%.8lf\t%.8lf\t", 
		sConName, sFOMFuncMain, sFOMFunc2,
		i_number_of_pairs, i_the_same_ways, i_different_ways, 1.0 - d_perc_diffrent,  d_perc_diffrent, 

		d_fit_1, d_fit_2,

		d_fit_change /*,d_fit_change/d_perc_diffrent*/
		);

	if  (i_different_ways  !=  0)
	{
		s_buf.Format("%.8lf \n", d_fit_change/d_perc_diffrent);
	}//if  (i_different_ways  !=  0)
	else
	{
		double  d_buf = 0;
		s_buf.Format("%.8lf \n", d_buf);	
	}//else if  (i_different_ways  !=  0)

	s_report_line = s_report_line + s_buf;


	fprintf(pf_report_file, s_report_line);


	//cDefinedSpecie1.vReport(pf_report_file, false, pl_capacities, l_penalty);
	//fprintf(pf_report_file,"\n\n\n\n\n\n\n\n");
	//cDefinedSpecie2.vReport(pf_report_file, false, pl_capacities, l_penalty);
	
	
	fclose(pf_report_file);


	return(1);
}//int  CTrajectorySetsFinder::iResultsCompare




/*
returned values:
1  -  ok
0  -  memory allocation problem
-1 -  bad population number
-2 -  bad number of generations
-3 -  possiblity badly inputted
-4 -  number of species to report is too high
-5 -  couldn't open population fom tracking file
-6 -  wrong defined species file filename or format asdasd
*/
CError  CTrajectorySetsFinder::eFindBestSet_IslandGa
		(
		System::Windows::Forms::ListBox *  listComm,
			long  lPenalty,
			CString  sIniFile,
			CString  sReportFileName,
			CString  sFileSummarize,

			double dTimeRestriction, 

			int  iPatternPoolSize, int  iMinimalTemplateLength,

			int  iCtStrategy,
			int  iLinkageGenWay, int iMigrationFreq, 
			long lPopulationNumberDiv4, 
			double dCrossPossibility,  double  dMutatePossibility,
			double dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
			double dRandomCrossPossibility,//it affects high level crossing way

			int  iNewCtDisturbedCopy, int iNewCtDisturbedLLDSI,
			double  dNewCtDisturbedGeneDisturbedProb
		)
{
	CError  c_err;

	i_max_infections_considered_at_crossing = iPatternPoolSize;

	i_new_ct_disturbed_copy = iNewCtDisturbedCopy;
	i_new_ct_disturbed_LLDSI = iNewCtDisturbedLLDSI;
	d_new_ct_disturbed_gene_disturbed_prob = dNewCtDisturbedGeneDisturbedProb;


	double d_best_fitness = 0;
	double d_time_until_best, d_ffe_until_best;
	double  d_buf;
	CTimeCounter  c_time_counter;

	
	FILE  *pf_report;
	pf_report  =  fopen(sReportFileName,  "w+");
	vSaveParameters(pf_report);
	double  d_time_passed;
	int  i_gen_since_last_migration;

	d_time_until_best = 0;
	d_ffe_until_best = 0;

	CString  s_buf;
	c_time_counter.vSetStartNow();
	d_time_passed = 0;
	i_gen_since_last_migration = 0;

	if  (pc_best_species  != NULL)  delete [] pc_best_species;
	pc_best_species  =  new  CSingleTrajectorySet[1];
	b_init_population(pc_best_species, 1, lPenalty);
	pc_best_species[0].dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty);

	pv_pattern_pool  =  new  vector  <CMessyPattern  *>;

	CSingleTrajectorySet *pc_single_pop_best;
	double d_avr_fit;

	if  (listComm  !=  NULL)  listComm->Items->Add(S"Started..");
	v_islands_number_manage(iCtStrategy, lPopulationNumberDiv4, lPenalty);//to initialize any subpopulation...

	for (int  i_cur_gen = 0; (d_time_passed < dTimeRestriction)&&(d_best_fitness  <  1.0);  i_cur_gen++)//prw remove
	{
		i_gen_since_last_migration++;

		for  (int  i_island = 0; i_island < v_islands.size(); i_island++)
		{
			v_islands.at(i_island)->eRunPop
				(
				listComm,
				i_island,
				lPenalty,
				dCrossPossibility,  dMutatePossibility,
				dCrossPossibilityLowLevel,  dMutatePossibilityLowLevel,
				dRandomCrossPossibility,
				iLinkageGenWay,
				i_cur_gen
				);

			d_buf = v_islands.at(i_island)->pc_best->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);
			if  (d_best_fitness < d_buf)
			{
				d_best_fitness = d_buf;

				c_time_counter.bGetTimePassed(&d_time_passed);
				d_time_until_best = d_time_passed;
				d_ffe_until_best = c_translator.pcGetFittnesCounter()->dEvalNumber();			
			}//if  (d_best_fitness < d_buf)
		}//for  (int  i_island = 0; i_island < v_islands.size(); i_island++)

		
		if  (i_gen_since_last_migration >= iMigrationFreq)
		{
			/*FILE  *pf_report;
			s_buf.Format("zz_patterns_%.3d.txt", i_cur_gen);
			pf_report = fopen(s_buf, "w+");
			for  (int  ii = 0;  ii < (int) pv_pattern_pool->size();  ii++)
			{
				pv_pattern_pool->at(ii)->eReportSimple(pf_report);
			}//for  (int  ii = 0;  ii < (int) v_best_found.size();  ii++)
			fclose(pf_report);*/

			v_islands_number_manage(iCtStrategy, lPopulationNumberDiv4, lPenalty);

			i_gen_since_last_migration = 0;
			v_standard_migration(listComm, lPopulationNumberDiv4 * 4, lPenalty, iLinkageGenWay);

			for  (int i_pop = 0; i_pop < v_islands.size(); i_pop++)
				v_islands.at(i_pop)->b_best_improved = false;
		}//if  (i_gen_since_last_migration >= iMigrationFreq)



		c_time_counter.bGetTimePassed(&d_time_passed);

		s_buf.Format("Islands: %d  Best:%.8lf to migration: %d  patterns: %d [time:%.8lf] ", v_islands.size(), pc_best_species[0].dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty), iMigrationFreq - i_gen_since_last_migration, pv_pattern_pool->size(), d_time_passed);
		listComm->Items->Add((System::String *) s_buf);
		listComm->SelectedIndex  =  listComm->Items->Count - 1;
		listComm->Refresh();	

		System::Windows::Forms::Application::DoEvents();
	}//for (int  i_cur_gen = 0; (d_time_passed < i_gen)/*&&(d_best_fitness  <  1.0)*/);  i_cur_gen++)




	for  (int  ii = 0; ii < (int) pv_pattern_pool->size();  ii++)
		delete  pv_pattern_pool->at(ii);
	pv_pattern_pool->clear();



	FILE  *pf_run_save;
	CString  s_effective_file_name;
	s_effective_file_name.Format("%s_RUN.txt", sReportFileName);
	pf_run_save  =  fopen(s_effective_file_name,  "w+");
	if  (pf_run_save  !=  NULL)
	{
		for  (int  ii = 0; ii  <  listComm->Items->get_Count();  ii++)
		{
			s_buf  =  listComm->Items->get_Item(ii)->ToString();		
			fprintf(pf_run_save,  "%s\n", s_buf);
		}//for  (int  ii = 0; ii  <  listInfo->Items->get_Count();  ii++)
		fclose(pf_run_save);
	}//if  (pf_run_save  !=  NULL)


	int  i_best_island = 0;
	
	for  (int  ii = 0; ii < (int) v_islands.size();  ii++)
	{
		d_buf  =  v_islands.at(ii)->pc_best->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);
		
		if  (d_buf  >  d_best_fitness)
		{
			d_best_fitness  =  d_buf;
			i_best_island = ii;
		}//if  (d_buf  >  d_best_fitness)
	}//for  (int  ii = 0; ii  <  listInfo->Items->get_Count();  ii++)


	FILE  *pf_full_report;
	s_effective_file_name.Format("%s.ful", sReportFileName);
	pf_full_report  =  fopen(s_effective_file_name,  "w+");
	if  (pf_full_report  !=  NULL)
	{
		v_islands.at(i_best_island)->pc_best->vReport(pf_full_report, true, pl_capacities, l_penalty);
		fclose(pf_full_report);
	}//if  (pf_run_save  !=  NULL)



	if  (sFileSummarize  !=  "")
	{
		FILE  *pf_summarized_rep;
		pf_summarized_rep  =  fopen(sFileSummarize, "a");

		double  d_optimized_func_val;
		d_optimized_func_val =  Math::Round(((double) 1.0) / d_best_fitness  -1);
		

		double  d_path_len_avr;
		int i_path_len_min, i_path_len_max;

		v_islands.at(i_best_island)->pc_best->vGetPathStats(&d_path_len_avr, &i_path_len_min, &i_path_len_max);

		CString  s_path_lens;
		v_islands.at(i_best_island)->pc_best->sReportPathLens(20);

		//TUTAJ DOLOZYC SREDNIA SLUGOSC SCIEZKI I MINIMALNA/MAKSYMALNA DLUGOSC SCIEZKI, EWENTUALNIE LICZBE SCEIZEK O DLUGOSCI 1,2,3,4,5,...,20, 20<
		fprintf
			(pf_summarized_rep, 
			"%.8lf \t %.0lf \t %.4lf \t %d \t %d \t %.0lf \t %.2lf \t %lf \t %lf \t %d \t %.2lf \t %lf \t \t %s \t %s \n", 

			d_best_fitness, d_optimized_func_val,
			d_path_len_avr, i_path_len_min, i_path_len_max,
			c_translator.pcGetFittnesCounter()->dEvalNumber(),
			d_time_passed, 0,0 , i_gen, 
			d_time_until_best, d_ffe_until_best,
			sReportFileName,
			s_path_lens
			);
		fclose(pf_summarized_rep);		
	}//if  (sFileSummarize  !=  "")
	



	fprintf(pf_report,  "\n\n\nTEMPLATES: %d (%d)\n", pv_pattern_pool->size(), i_max_infections_considered_at_crossing);
	for  (int  ii = 0;  ii < (int) pv_pattern_pool->size();  ii++)
	{
		fprintf(pf_report,  "\n\n\nTEMPLATES: %d\n", ii);
		/*if  (pi_pattern_genes_freq  !=  NULL)
		{
			fprintf(pf_report, "template entrophy fitness: %.8lf\n", pv_pattern_pool->at(ii)->dGetPatternEntrophyFittnes(pi_pattern_genes_freq));
		}//if  (pi_pattern_genes_freq  !=  NULL)*/
		pv_pattern_pool->at(ii)->eReport(pf_report,  true);	


		
	}//for  (int  ii = 0;  ii < (int) v_best_found.size();  ii++)


	fprintf(pf_report,  "\n\n\n");
	/*if  (pi_pattern_genes_freq  !=  NULL)
	{
		fprintf(pf_report, "\n\ngene pattern freq table: \n\t");

		for  (int  ii = 0; ii < i_templ_length; ii++)
			fprintf(pf_report, "%d\t", pi_pattern_genes_freq[ii]);
	}//if  (pi_pattern_genes_freq  !=  NULL)*/

	fprintf(pf_report,  "\n\nFITNESS EVALUATIONS: 0\n\n\n\n");

	
	
	for  (int  ii = 0; ii < (int) v_islands.size();  ii++)
		v_islands.at(ii)->pc_best->vReport(pf_report, false, pl_capacities, l_penalty);

	
	fclose(pf_report);

	return(c_err);
}//int  CTrajectorySetsFinder::eFindBestSet_IslandGa




void  CTrajectorySetsFinder::v_islands_number_manage(int  iCtStrategy, long lPopulationNumberDiv4, long lPenalty)
{
	CSingleIslandPopulation  *pc_pop_buf;

	l_population_number  =  lPopulationNumberDiv4 * 4;
	if  (iCtStrategy > 0)
	{
		while (v_islands.size() < iCtStrategy)
		{
			
			l_population_number  =  0;
			pc_pop_buf  =  new  CSingleIslandPopulation(this);
			pc_pop_buf->eCreatePop(lPopulationNumberDiv4, lPenalty);

			//b_init_population(pc_pop_buf, l_population_number, lPenalty);

			/*double  d_avr;
			b_count_fom(pc_pop_buf, l_population_number, &d_avr, lPenalty);
			CString  s_buf;
			s_buf.Format("islands: %d  %.8lf  %ld  FIRST: %.8lf", v_islands.size(), d_avr, l_population_number, pc_pop_buf[0].dGetFOMLevel());
			::MessageBox(NULL, s_buf, s_buf, MB_OK);*/

			

			v_islands.push_back(pc_pop_buf);
		}//while (v_islands.size() < iIslandNumber)

		return;
	}//if  (iIslandNumber > 0)


	bool  b_any_pop_improved;
	b_any_pop_improved = false;
	for  (int i_pop = 0; i_pop < v_islands.size(); i_pop++)
	{
		if  (v_islands.at(i_pop)->b_best_improved == true)  b_any_pop_improved = true;
	}//for  (int i_pop = 0; i_pop < v_islands.size(); i_pop++)


	if  (iCtStrategy == -1)//classic
	{
		for  (int i_pop_0 = 0; i_pop_0 < v_islands.size(); i_pop_0++)
		{
			for  (int i_pop_1 = i_pop_0 + 1; i_pop_1 < v_islands.size(); i_pop_1++)
			{
				if  (
						(
						v_islands.at(i_pop_0)->pc_best->bIsTheSame(v_islands.at(i_pop_1)->pc_best)
						==
						true
						)
						&&
						(i_pop_0 < i_pop_1)
					)
				{
					delete  v_islands.at(i_pop_1);
					v_islands.erase(v_islands.begin() + i_pop_1);
					i_pop_1--;
				}//if  (
			}//for  (int i_pop_1 = 0; i_pop_1 < v_islands.size(); i_pop_1++)
		}//for  (int i_pop_0 = 0; i_pop_0 < v_islands.size(); i_pop_0++)
	
	}//if  (iCtStrategy == -1)//classic




	if  (iCtStrategy == -2)//active
	{
		//check if the best has improved
		CSingleIslandPopulation  *pc_best_pop;

		if  (v_islands.size() > 0)
		{
			pc_best_pop = v_islands.at(0);
			for  (int i_pop = 0; i_pop < v_islands.size(); i_pop++)
			{
				if  (
					pc_best_pop->pc_best->dGetFOMLevel()
					<
					v_islands.at(i_pop)->pc_best->dGetFOMLevel()
					)
				{
					pc_best_pop = v_islands.at(i_pop);
				}//if  (


				if  (
						(
						pc_best_pop->pc_best->dGetFOMLevel()
						==
						v_islands.at(i_pop)->pc_best->dGetFOMLevel()
						)
						&&
						(
						v_islands.at(i_pop)->b_best_improved == false
						)
					)
				{
					pc_best_pop = v_islands.at(i_pop);
				}//if  (		
			}//for  (int i_pop = 0; i_pop < v_islands.size(); i_pop++)	
		
			//best has improved - we delete the other subpopulations
			if  (pc_best_pop->b_best_improved == true)
			{
				for  (int i_pop = 0; i_pop < v_islands.size(); i_pop++)
				{
					if  (v_islands.at(i_pop) != pc_best_pop)  delete  v_islands.at(i_pop);
				}//for  (int i_pop = 0; i_pop < v_islands.size(); i_pop++)

				v_islands.clear();
				v_islands.push_back(pc_best_pop);			
			}//if  (pc_best_pop->b_best_improved == true)
		}//if  (v_islands.size() > 0)
	}//if  (iCtStrategy == -2)//active

	if  (b_any_pop_improved  ==  false)
	{
		pc_pop_buf  =  new  CSingleIslandPopulation(this);

		if  (pv_pattern_pool->size() > 0)
		{
			if  (i_new_ct_disturbed_copy == 1)
			{
				if  (i_new_ct_disturbed_LLDSI == 1)
				{
					pc_pop_buf->eCreatePop(lPopulationNumberDiv4, lPenalty, pv_pattern_pool, &v_islands);
				}//if  (i_new_ct_disturbed_LLDSI == 1)
				else
				{
					//CString  s_buf;
					//s_buf.Format("disturb with random %.2lf", d_new_ct_disturbed_gene_disturbed_prob);
					//::Tools::vShow(s_buf);

					pc_pop_buf->eCreatePop(lPopulationNumberDiv4, lPenalty, d_new_ct_disturbed_gene_disturbed_prob, &v_islands);
					::Tools::vShow("pc_pop_buf->eCreatePop(lPopulationNumberDiv4, lPenalty, d_new_ct_disturbed_gene_disturbed_prob, &v_islands);");
				}//else  if  (i_new_ct_disturbed_LLDSI == 1)
			}//if  (i_new_ct_disturbed_copy == 1)
			else
				pc_pop_buf->eCreatePop(lPopulationNumberDiv4, lPenalty);
			
		}//if  (pv_pattern_pool->size() > 0)
		else
			pc_pop_buf->eCreatePop(lPopulationNumberDiv4, lPenalty);


		v_islands.push_back(pc_pop_buf);
	}//if  (b_any_pop_improved  ==  false)
}//void  CTrajectorySetsFinder::v_islands_number_manage(int  iIslandNumber)



CSingleTrajectorySet*  CTrajectorySetsFinder::pc_get_random_best(CSingleTrajectorySet  *pcPopulation, int  iPopSize, long lPenalty)
{
	double  d_best_fitness, d_buf;

	d_best_fitness = 0;
	for (int ii = 0; ii < iPopSize; ii++)
	{
		d_buf = pcPopulation[ii].dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty);
		if  (d_best_fitness  <  d_buf)  d_best_fitness  =  d_buf;
	}//for (int ii = 0; ii < iPopSize; ii++)


	vector<int>  v_bests;
	for (int ii = 0; ii < iPopSize; ii++)
	{
		d_buf = pcPopulation[ii].dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty);
		if  (d_best_fitness  ==  d_buf)  v_bests.push_back(ii);
	}//for (int ii = 0; ii < iPopSize; ii++)


	int  i_chosen_best;
	i_chosen_best = v_bests.at(lRand(v_bests.size()));


	return(&(pcPopulation[i_chosen_best]));
}//CSingleTrajectorySet*  CTrajectorySetsFinder::pc_get_random_best(CSingleTrajectorySet  *pcPopulation, int  iPopSize)



void  CTrajectorySetsFinder::v_im_get_linkage_at_migration(System::Windows::Forms::ListBox *  listComm)
{
	CMessyPattern  *pc_new_pattern;
	CSingleTrajectorySet  *pc_best_0, *pc_best_1;

	for  (int i_island_0 = 0; i_island_0 < v_islands.size();  i_island_0++)
	{
		pc_best_0 = v_islands.at(i_island_0)->pc_best;

		for  (int i_island_1 = i_island_0+1; i_island_1 < v_islands.size();  i_island_1++)
		{
			pc_best_1 = v_islands.at(i_island_1)->pc_best;
			pc_new_pattern = pc_best_0->pcGetPatternByDifference(pc_best_1);

			if  (pc_new_pattern  !=  NULL)  pv_pattern_pool->push_back(pc_new_pattern);
		}//for  (int i_island_1 = i_island_0+1; i_island_1 < v_islands.size();  i_island_1++)	
	}//for  (int i_island_0 = 0; i_island_0 < v_islands.size();  i_island_0++)

	v_pattern_number_control_new(true);
}//void  CTrajectorySetsFinder::v_im_get_linkage_at_migration(System::Windows::Forms::ListBox *  listComm)




void  CTrajectorySetsFinder::v_standard_migration(System::Windows::Forms::ListBox *  listComm, int  iPopSize, long lPenalty, int iLinkageGenWay)
{
	CString  s_buf;
	CSingleTrajectorySet  *pc_receiver_ind, *pc_donator_ind;

	if  (iLinkageGenWay == VGA_PARAM_IM_LINKAGE_GEN_NO_AT_MIGRATION)  v_im_get_linkage_at_migration(listComm);


	for  (int  i_receiver = 0; i_receiver < v_islands.size(); i_receiver++)
	{
		if  (v_islands.at(i_receiver)->b_best_improved == false)
		{
			for  (int  i_donator = 0; i_donator < v_islands.size(); i_donator++)
			{
				if  (i_receiver != i_donator)
				{
					pc_receiver_ind = &(v_islands.at(i_receiver)->pc_island_pop[lRand(iPopSize)]);

					pc_donator_ind = pc_get_random_best(v_islands.at(i_donator)->pc_island_pop, iPopSize, lPenalty);

					pc_receiver_ind->vCopy(pc_donator_ind);
				
				}//if  (i_receiver != i_donator)		
			}//for  (int  i_donator = 0; i_donator < v_islands.size(); i_donator++)	
		}//if  (v_islands.at(i_receiver)->b_best_improved == false)
	}//for  (int  i_receiver = 0; i_receiver < v_islands.size(); i_receiver++)


	s_buf = "STANDARD MIGRATION";
	listComm->Items->Add((System::String *) s_buf);
	listComm->SelectedIndex  =  listComm->Items->Count - 1;
	listComm->Refresh();	
}//void  CTrajectorySetsFinder::v_standard_migration()




void  CTrajectorySetsFinder::v_execute_evolution_for_single_pop
	(
	System::Windows::Forms::ListBox *  listComm,
	CSingleTrajectorySet **pcBest, double *pdPopAvrFitness,
	CSingleTrajectorySet **pcPopulation, long lPopulationSizeDiv4,
	int  iIsland, 
	long  lPenalty,
	double  dCrossPossibility,  double  dMutatePossibility,
	double  dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
	double  dRandomCrossPossibility,
	long lGenNum
	)
{
	CString  s_buf;


	b_count_fom(*pcPopulation, lPopulationSizeDiv4*4, pdPopAvrFitness, lPenalty);
	b_select_best_species(*pcPopulation, lPopulationSizeDiv4*4, 1, pcBest);

	b_cross_population_tournament(pcPopulation, lPopulationSizeDiv4*4, dCrossPossibility, dRandomCrossPossibility, lGenNum, lPenalty);
	b_count_fom(*pcPopulation, lPopulationSizeDiv4*4, pdPopAvrFitness, lPenalty);
	b_select_best_species(*pcPopulation, lPopulationSizeDiv4*4, 1, pcBest);

	b_mutate_population(*pcPopulation, lPopulationSizeDiv4*4, dMutatePossibility, lGenNum);
	b_count_fom(*pcPopulation, lPopulationSizeDiv4*4, pdPopAvrFitness, lPenalty);
	b_select_best_species(*pcPopulation, lPopulationSizeDiv4*4, 1, pcBest);

	b_cross_population_low_level_2_1_tournament(pcPopulation, lPopulationSizeDiv4*4, dCrossPossibilityLowLevel, lGenNum);
	b_count_fom(*pcPopulation, lPopulationSizeDiv4*4, pdPopAvrFitness, lPenalty);
	b_select_best_species(*pcPopulation, lPopulationSizeDiv4*4, 1, pcBest);
	
	
	b_mutate_population_low_level(*pcPopulation, lPopulationSizeDiv4*4, dMutatePossibilityLowLevel, lGenNum);
	b_count_fom(*pcPopulation, lPopulationSizeDiv4*4, pdPopAvrFitness, lPenalty);
	b_select_best_species(*pcPopulation, lPopulationSizeDiv4*4, 1, pcBest);


	s_buf.Format("Island: %d  best: %.8lf (avr: %.8lf)", iIsland, (*pcBest)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty), *pdPopAvrFitness);
	listComm->Items->Add((System::String *) s_buf);
	listComm->SelectedIndex  =  listComm->Items->Count - 1;
	listComm->Refresh();	
}//void  CTrajectorySetsFinder::v_execute_evolution_for_single_pop




bool  CTrajectorySetsFinder::b_cross_population_tournament
	(CSingleTrajectorySet  **pcPopulation, long lPopSize, double  dCrossPossibility,  double  dRandomCrossPossibility, long lGenNum, long  lPenalty)
{

	pc_new_population  =  new  CSingleTrajectorySet[lPopSize];
	if  (pc_new_population  ==  NULL)  return(false);

	long  l_mother, l_father;

	for  (long  li = 0; li < lPopSize / 2; li++)
	{

		v_find_parents_tournament(*pcPopulation, lPopSize, &l_mother, &l_father);

		pc_new_population[li * 2].vCopy(&((*pcPopulation)[l_mother]));
		pc_new_population[li * 2 + 1].vCopy(&((*pcPopulation)[l_father]));


		if  (dRand()  <  dCrossPossibility)
		{

			((*pcPopulation)[l_mother]).bCross
				(
				&((*pcPopulation)[l_father]),
				&(pc_new_population[li * 2]),
				&(pc_new_population[li * 2 + 1]),
				dRandomCrossPossibility,
				pl_capacities
				);

			pc_new_population[li * 2].vSetWhenCreated(lGenNum);
			pc_new_population[li * 2 + 1].vSetWhenCreated(lGenNum);

					
		}//if  (dRand()  <  dCrossPossibility)*/
		


	}//for  (li = 0; li < l_population_number; li++)

    delete  []  *pcPopulation;

	*pcPopulation  =  pc_new_population;

	return(true);
}//bool  CTrajectorySetsFinder::b_cross_population_1_1



/*
returned values:
1  -  ok
0  -  memory allocation problem
-1 -  bad population number
-2 -  bad number of generations
-3 -  possiblity badly inputted
-4 -  number of species to report is too high
-5 -  couldn't open population fom tracking file
-6 -  wrong defined species file filename or format
*/
int  CTrajectorySetsFinder::iFindBestSet_Standard_EA
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lNumberOfGenerations, long  lPopulationNumberDiv4, double dTimeRestriction, 
			double dCrossPossibility,  double  dMutatePossibility,
			double dRandomCrossPossibility,//it affects high level crossing way
			long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
						//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
			CString  sIniFile,
			long  lNumberOfSpeciesToPresent,  CString  sReportFileName,
			CString  sPopulationFOMtrackingFile, FILE *pfResFile,
			bool  bUseOldPopulation ,
			long  lCapaIncr,  long  lCapaGenIncr,
			 
			//brainstorming
			long  lBrainAvrLen,  double  dBrainMinInc,
			long  lBrainTimeLen,  long  lBrainFinishTime,
			long  lBrainMinBreak
			)
{
	if  (lPopulationNumberDiv4  <  2)  return(-1);
	//if  (lNumberOfGenerations  <  1)  return(-2);
	if  ( (dCrossPossibility > 1.0)||(dCrossPossibility < 0) )  return(-3);
	if  ( (dMutatePossibility > 1.0)||(dMutatePossibility < 0) )  return(-3);

	if  (lNumberOfSpeciesToPresent  >  lPopulationNumberDiv4 * 4)  return(-4);


	FILE  *pf_fom_tracking;
	
	if  (sPopulationFOMtrackingFile  !=  "")
	{
		pf_fom_tracking  =  fopen( (LPCSTR) sPopulationFOMtrackingFile, "w+");
		if  (pf_fom_tracking  ==  NULL)  
			return(-5);
		else
			fprintf(pf_fom_tracking,"Pop number  \tAverage population FOM\t\t Best specie FOM \t Brain Storm \t Time\n\n");
					
	}//if  (sPopulationFOMtrackingFile  !=  "")  



	if  (pc_best_species  !=  NULL)
		delete  []  pc_best_species;


	if  (bUseOldPopulation  ==  false)
	{

		if  (pc_population  !=  NULL)
			delete  []  pc_population;
	
		l_population_number  =  0;

		pc_population  =  new  CSingleTrajectorySet[lPopulationNumberDiv4 * 4];

		if  (pc_population  ==  NULL)  return(0);

		l_population_number  =  lPopulationNumberDiv4 * 4;

	}//if  (bUseOldPopulation  ==  false)
	else
	{

		for  (long  lk = 0; lk < l_population_number; lk++)
			pc_population[lk].vSetWhenCreated(0);
		
	}//else  if  (bUseOldPopulation  ==  false)



	pc_best_species  =  new  CSingleTrajectorySet[lNumberOfSpeciesToPresent];
	if  (pc_best_species  ==  NULL)  return(0);

	

	//genetic algorithm starts...
	if  (bUseOldPopulation  ==  false)
	{
		b_init_population(pc_population, l_population_number, lPenalty);
		if  (b_input_defined_species(sIniFile,true)  !=  true)  return(-6);
		b_init_population(pc_population, l_population_number, lPenalty);
		if  (b_input_defined_species(sIniFile,true)  !=  true)  return(-6);
	}//if  (bUseOldPopulation  ==  false)


	
	
	c_brain_storm_superv.bSetUpConfig
		(
		lBrainAvrLen,  dBrainMinInc,
		lBrainTimeLen,  lBrainFinishTime,
		lBrainMinBreak
		);
	double  d_pop_avr_fom = 0;//the information colector for "brain storm" supervisor
	double  d_fom_modifier = 0;//the modifier set up by "brain storm" supervisor


	CString  s_buf;
	long  l_last_capa_increasment  =  0;
	CTimeCounter  c_timer;
	double  d_time_passed;
	c_timer.vSetStartNow();
	c_timer.bSetFinishOn(dTimeRestriction);
	
	long li;
	for  (li = 0; 
			(
			( (dTimeRestriction > 0)&&(c_timer.bIsFinished()  ==  false) )
			||
			( (dTimeRestriction <= 0)&&(li < lNumberOfGenerations) )
			)
			&&
			(pc_best_species[0].dGetFOMLevel()  <  1);
		li++)
	{
		//taking the modifier from "brain storm" supervisor
		d_fom_modifier  =  c_brain_storm_superv.dGetNextGenerationState(d_pop_avr_fom);

		b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);

		//if we change the fom function during work we can not store best species during algorithm work
		if  (lCapaIncr  ==  0)  
		{
			//b_select_1_best_specie(lNumberOfSpeciesToPresent);
			b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
			v_input_best_species(lNumberOfSpeciesToPresent);
		}//if  (lCapaIncr  ==  0)

		//d_pop_avr_fom  =  d_population_fom / l_population_number;//collecting information for "brain dtorm" supervisor

		//generating statistical information
		c_timer.bGetTimePassed(&d_time_passed);
		if  (sPopulationFOMtrackingFile  !=  "")  
		{
			fprintf(pf_fom_tracking,"%ld high  \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_pop_avr_fom,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
		}//if  (sPopulationFOMtrackingFile  !=  "")

		s_buf.Format("High phase  Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
			li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
		listComm->Items->Add( (System::String *) s_buf);
		listComm->SelectedIndex  =  listComm->Items->Count - 1;
		listComm->Refresh();
				
		

		if  (b_cross_population_1_1(dCrossPossibility, li, dRandomCrossPossibility, d_pop_avr_fom, d_fom_modifier)  ==  false)
		{
			listComm->Items->Add(S"High level crossing error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			fclose(pf_fom_tracking);
			return(0);
		}//if  (b_cross_population(dCrossPossibility, li, dRandomCrossPossibility, d_fom_modifier)  ==  false)

		if  (b_mutate_population(pc_population, l_population_number, dMutatePossibility, li)  ==  false)
		{
			listComm->Items->Add(S"High level mutation error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			fclose(pf_fom_tracking);
			return(0);		
		}//if  (b_mutate_population(dMutatePossibility, li)  ==  false)

		b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);
		
		//if we change the fom function during work we can not store best species during algorithm work
		if  (lCapaIncr  ==  0)
		{
			//b_select_1_best_specie(lNumberOfSpeciesToPresent);
			b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
			v_input_best_species(lNumberOfSpeciesToPresent);
		}//if  (lCapaIncr  ==  0)

		//d_pop_avr_fom  +=  d_population_fom / l_population_number;//collecting information for "brain dtorm" supervisor
		//d_pop_avr_fom  =  d_pop_avr_fom / 2;	


		//generating statistical information
		c_timer.bGetTimePassed(&d_time_passed);
		if  (sPopulationFOMtrackingFile  !=  "")
		{
			fprintf(pf_fom_tracking,"%ld low   \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_pop_avr_fom,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
		}//if  (sPopulationFOMtrackingFile  !=  "")

				
		//now - increasing the capacities if it was demanded
		if  ( (li - l_last_capa_increasment  ==  lCapaGenIncr)&&(lCapaGenIncr  !=  0) )
		{
			l_last_capa_increasment  =  li;


			for  (long  lk = 0; lk < i_number_of_pairs; lk++)
				pl_capacities[lk]  +=  lCapaIncr;
		
		}//if  (li - l_last_capa_increasment  ==  lCapaGenIncr)

					
			
	}//for  (long  li = 0; li < lNumberOfGenerations; li++)*/


	b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);;
	b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
	//b_select_1_best_specie(lNumberOfSpeciesToPresent);
	c_timer.bGetTimePassed(&d_time_passed);
	if  (sPopulationFOMtrackingFile  !=  "")  
	{
		fprintf(pf_fom_tracking,"%ld final \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_pop_avr_fom,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
	}//if  (sPopulationFOMtrackingFile  !=  "")
	
	s_buf.Format("Finalizing  Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
		li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
	listComm->Items->Add( (System::String *) s_buf);
	listComm->SelectedIndex  =  listComm->Items->Count - 1;
	listComm->Refresh();
	


	//now we close fom tracking file if it was to be opened
	if  (sPopulationFOMtrackingFile  !=  "")  fclose(pf_fom_tracking);


	//now we create the report file
	i_create_report_files(sReportFileName, pfResFile, d_pop_avr_fom, lNumberOfSpeciesToPresent, lPenalty);


	return(1);
}//int  CTrajectorySetsFinder::iFindBestSet_Standard_EA



/*
returned values:
1  -  ok
0  -  memory allocation problem
-1 -  bad population number
-2 -  bad number of generations
-3 -  possiblity badly inputted
-4 -  number of species to report is too high
-5 -  couldn't open population fom tracking file
-6 -  wrong defined species file filename or format
*/
int   CTrajectorySetsFinder::iFindBestSet_1_0
	(
	System::Windows::Forms::ListBox *  listComm,
	long  lNumberOfGenerations, long  lPopulationNumberDiv4, double dTimeRestriction, 
	double dCrossPossibility,  double  dMutatePossibility,
	double dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
	double dRandomCrossPossibility,//it affects high level crossing way
	long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
				//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
	CString  sIniFile,
	long  lNumberOfSpeciesToPresent,  CString  sReportFileName,
	CString  sPopulationFOMtrackingFile, FILE *pfResFile,
	bool  bUseOldPopulation,
	long  lCapaIncr,  long  lCapaGenIncr,

	//brainstorming
	long  lBrainAvrLen,  double  dBrainMinInc,
	long  lBrainTimeLen,  long  lBrainFinishTime,
	long  lBrainMinBreak
	)
{

	if  (lPopulationNumberDiv4  <  2)  return(-1);
	//if  (lNumberOfGenerations  <  1)  return(-2);
	if  ( (dCrossPossibility > 1.0)||(dCrossPossibility < 0) )  return(-3);
	if  ( (dMutatePossibility > 1.0)||(dMutatePossibility < 0) )  return(-3);
	if  ( (dCrossPossibilityLowLevel > 1.0)||(dCrossPossibilityLowLevel < 0) )  return(-3);
	if  ( (dMutatePossibilityLowLevel > 1.0)||(dMutatePossibilityLowLevel < 0) )  return(-3);

	if  (lNumberOfSpeciesToPresent  >  lPopulationNumberDiv4 * 4)  return(-4);


	FILE  *pf_fom_tracking;
	
	if  (sPopulationFOMtrackingFile  !=  "")
	{
		pf_fom_tracking  =  fopen( (LPCSTR) sPopulationFOMtrackingFile, "w+");
		if  (pf_fom_tracking  ==  NULL)  
			return(-5);
		else
			fprintf(pf_fom_tracking,"Pop number  \tAverage population FOM\t\t Best specie FOM \t Brain Storm \t Time\n\n");
					
	}//if  (sPopulationFOMtrackingFile  !=  "")  



	if  (pc_best_species  !=  NULL)
		delete  []  pc_best_species;


	if  (bUseOldPopulation  ==  false)
	{

		if  (pc_population  !=  NULL)
			delete  []  pc_population;
	
		l_population_number  =  0;

		pc_population  =  new  CSingleTrajectorySet[lPopulationNumberDiv4 * 4];

		if  (pc_population  ==  NULL)  return(0);

		l_population_number  =  lPopulationNumberDiv4 * 4;

	}//if  (bUseOldPopulation  ==  false)
	else
	{

		for  (long  lk = 0; lk < l_population_number; lk++)
			pc_population[lk].vSetWhenCreated(0);
		
	}//else  if  (bUseOldPopulation  ==  false)



	pc_best_species  =  new  CSingleTrajectorySet[lNumberOfSpeciesToPresent];
	if  (pc_best_species  ==  NULL)  return(0);

	

	//genetic algorithm starts...
	if  (bUseOldPopulation  ==  false)
	{
		b_init_population(pc_population, l_population_number, lPenalty);
		if  (b_input_defined_species(sIniFile,true)  !=  true)  return(-6);
		b_init_population(pc_population, l_population_number, lPenalty);
		if  (b_input_defined_species(sIniFile,true)  !=  true)  return(-6);
	}//if  (bUseOldPopulation  ==  false)

	
	
	c_brain_storm_superv.bSetUpConfig
		(
		lBrainAvrLen,  dBrainMinInc,
		lBrainTimeLen,  lBrainFinishTime,
		lBrainMinBreak
		);
	double  d_pop_avr_fom = 0;//the information colector for "brain storm" supervisor
	double  d_fom_modifier = 0;//the modifier set up by "brain storm" supervisor


	CString  s_buf;
	long  l_last_capa_increasment  =  0;
	CTimeCounter  c_timer;
	double  d_time_passed;
	c_timer.vSetStartNow();
	c_timer.bSetFinishOn(dTimeRestriction);
	
	long li;
	for  (li = 0; 
			(
			( (dTimeRestriction > 0)&&(c_timer.bIsFinished()  ==  false) )
			||
			( (dTimeRestriction <= 0)&&(li < lNumberOfGenerations) )
			)
			&&
			(pc_best_species[0].dGetFOMLevel()  <  1);
		li++)
	{
		//taking the modifier from "brain storm" supervisor
		d_fom_modifier  =  c_brain_storm_superv.dGetNextGenerationState(d_pop_avr_fom);

		b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);

		//if we change the fom function during work we can not store best species during algorithm work
		if  (lCapaIncr  ==  0)  
		{
			//b_select_1_best_specie(lNumberOfSpeciesToPresent);
			b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
			v_input_best_species(lNumberOfSpeciesToPresent);
		}//if  (lCapaIncr  ==  0)

		//d_pop_avr_fom  =  d_population_fom / l_population_number;//collecting information for "brain dtorm" supervisor

		//generating statistical information
		c_timer.bGetTimePassed(&d_time_passed);
		if  (sPopulationFOMtrackingFile  !=  "")  
		{
			fprintf(pf_fom_tracking,"%ld high  \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_pop_avr_fom,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
		}//if  (sPopulationFOMtrackingFile  !=  "")

		s_buf.Format("High phase  Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
			li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
		listComm->Items->Add( (System::String *) s_buf);
		listComm->SelectedIndex  =  listComm->Items->Count - 1;
		listComm->Refresh();
				
		

		if  (b_cross_population(dCrossPossibility, li, dRandomCrossPossibility, d_pop_avr_fom, d_fom_modifier)  ==  false)
		{
			listComm->Items->Add(S"High level crossing error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			fclose(pf_fom_tracking);
			return(0);
		}//if  (b_cross_population(dCrossPossibility, li, dRandomCrossPossibility, d_fom_modifier)  ==  false)

		if  (b_mutate_population(pc_population, l_population_number, dMutatePossibility, li)  ==  false)
		{
			listComm->Items->Add(S"High level mutation error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			fclose(pf_fom_tracking);
			return(0);		
		}//if  (b_mutate_population(dMutatePossibility, li)  ==  false)

		b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);
		
		//if we change the fom function during work we can not store best species during algorithm work
		if  (lCapaIncr  ==  0)
		{
			//b_select_1_best_specie(lNumberOfSpeciesToPresent);
			b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
			v_input_best_species(lNumberOfSpeciesToPresent);
		}//if  (lCapaIncr  ==  0)

		//d_pop_avr_fom  +=  d_population_fom / l_population_number;//collecting information for "brain dtorm" supervisor
		//d_pop_avr_fom  =  d_pop_avr_fom / 2;	


		//generating statistical information
		c_timer.bGetTimePassed(&d_time_passed);
		if  (sPopulationFOMtrackingFile  !=  "")
		{
			fprintf(pf_fom_tracking,"%ld low   \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_pop_avr_fom,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
		}//if  (sPopulationFOMtrackingFile  !=  "")

		s_buf.Format("Low  phase  Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
			li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
		listComm->Items->Add( (System::String *) s_buf);
		listComm->SelectedIndex  =  listComm->Items->Count - 1;
		listComm->Refresh();
		


		if  (b_cross_population_low_level(dCrossPossibilityLowLevel, li, d_pop_avr_fom, d_fom_modifier)  ==  false)
		{
			listComm->Items->Add(S"Low level crossing error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			fclose(pf_fom_tracking);
			return(0);		
		}//if  (b_cross_population_low_level(dCrossPossibilityLowLevel, li, d_fom_modifier)  ==  false)


		if  (b_mutate_population_low_level(pc_population, l_population_number,  dMutatePossibilityLowLevel, li)  ==  false)  
		{
			listComm->Items->Add(S"Low level mutation error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			fclose(pf_fom_tracking);
			return(0);
		}//if  (b_mutate_population_low_level(dMutatePossibilityLowLevel, li)  ==  false)  


		
		//now - increasing the capacities if it was demanded
		if  ( (li - l_last_capa_increasment  ==  lCapaGenIncr)&&(lCapaGenIncr  !=  0) )
		{
			l_last_capa_increasment  =  li;


			for  (long  lk = 0; lk < i_number_of_pairs; lk++)
				pl_capacities[lk]  +=  lCapaIncr;
		
		}//if  (li - l_last_capa_increasment  ==  lCapaGenIncr)

					
			
	}//for  (long  li = 0; li < lNumberOfGenerations; li++)*/


	b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);
	b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
	//b_select_1_best_specie(lNumberOfSpeciesToPresent);
	c_timer.bGetTimePassed(&d_time_passed);
	if  (sPopulationFOMtrackingFile  !=  "")  
	{
		fprintf(pf_fom_tracking,"%ld final \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_pop_avr_fom,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
	}//if  (sPopulationFOMtrackingFile  !=  "")
	
	s_buf.Format("Finalizing  Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
			li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
	listComm->Items->Add( (System::String *) s_buf);
	listComm->SelectedIndex  =  listComm->Items->Count - 1;
	listComm->Refresh();
	


	//now we close fom tracking file if it was to be opened
	if  (sPopulationFOMtrackingFile  !=  "")  fclose(pf_fom_tracking);


	//now we create the report file
	i_create_report_files(sReportFileName, pfResFile, d_pop_avr_fom, lNumberOfSpeciesToPresent, lPenalty);


	return(1);

}//int   int   CTrajectorySetsFinder::iFindBestSet_1_0





/*
returned values:
1  -  ok
0  -  memory allocation problem
-1 -  bad population number
-2 -  bad number of generations
-3 -  possiblity badly inputted
-4 -  number of species to report is too high
-5 -  couldn't open population fom tracking file
-6 -  wrong defined species file filename or format
*/
int   CTrajectorySetsFinder::iFindBestSet_1_1
	(
	System::Windows::Forms::ListBox *  listComm,
	long  lNumberOfGenerations, long  lPopulationNumberDiv4, double dTimeRestriction, 
	double dCrossPossibility,  double  dMutatePossibility,
	double dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
	double dRandomCrossPossibility,//it affects high level crossing way
	long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
				//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
	CString  sIniFile,
	long  lNumberOfSpeciesToPresent,  CString  sReportFileName,
	CString  sPopulationFOMtrackingFile, FILE *pfResFile,
	bool  bUseOldPopulation,
	long  lCapaIncr,  long  lCapaGenIncr,

	//brainstorming
	long  lBrainAvrLen,  double  dBrainMinInc,
	long  lBrainTimeLen,  long  lBrainFinishTime,
	long  lBrainMinBreak
	)
{

	if  (lPopulationNumberDiv4  <  2)  return(-1);
	//if  (lNumberOfGenerations  <  1)  return(-2);
	if  ( (dCrossPossibility > 1.0)||(dCrossPossibility < 0) )  return(-3);
	if  ( (dMutatePossibility > 1.0)||(dMutatePossibility < 0) )  return(-3);
	if  ( (dCrossPossibilityLowLevel > 1.0)||(dCrossPossibilityLowLevel < 0) )  return(-3);
	if  ( (dMutatePossibilityLowLevel > 1.0)||(dMutatePossibilityLowLevel < 0) )  return(-3);

	if  (lNumberOfSpeciesToPresent  >  lPopulationNumberDiv4 * 4)  return(-4);


	FILE  *pf_fom_tracking;
	
	if  (sPopulationFOMtrackingFile  !=  "")
	{
		pf_fom_tracking  =  fopen( (LPCSTR) sPopulationFOMtrackingFile, "w+");
		if  (pf_fom_tracking  ==  NULL)  
			return(-5);
		else
			fprintf(pf_fom_tracking,"Pop number  \tAverage population FOM\t\t Best specie FOM \t Brain Storm \t Time\n\n");
					
	}//if  (sPopulationFOMtrackingFile  !=  "")  



	if  (pc_best_species  !=  NULL)
		delete  []  pc_best_species;


	if  (bUseOldPopulation  ==  false)
	{

		if  (pc_population  !=  NULL)
			delete  []  pc_population;
	
		l_population_number  =  0;

		pc_population  =  new  CSingleTrajectorySet[lPopulationNumberDiv4 * 4];

		if  (pc_population  ==  NULL)  return(0);

		l_population_number  =  lPopulationNumberDiv4 * 4;

	}//if  (bUseOldPopulation  ==  false)
	else
	{

		for  (long  lk = 0; lk < l_population_number; lk++)
			pc_population[lk].vSetWhenCreated(0);
		
	}//else  if  (bUseOldPopulation  ==  false)



	pc_best_species  =  new  CSingleTrajectorySet[lNumberOfSpeciesToPresent];
	if  (pc_best_species  ==  NULL)  return(0);

	

	//genetic algorithm starts...
	if  (bUseOldPopulation  ==  false)
	{
		b_init_population(pc_population, l_population_number, lPenalty);
		if  (b_input_defined_species(sIniFile,true)  !=  true)  return(-6);
		b_init_population(pc_population, l_population_number, lPenalty);
		if  (b_input_defined_species(sIniFile,true)  !=  true)  return(-6);
	}//if  (bUseOldPopulation  ==  false)

	
	c_brain_storm_superv.bSetUpConfig
		(
		lBrainAvrLen,  dBrainMinInc,
		lBrainTimeLen,  lBrainFinishTime,
		lBrainMinBreak
		);
	double  d_pop_avr_fom = 0;//the information colector for "brain storm" supervisor
	double  d_fom_modifier = 0;//the modifier set up by "brain storm" supervisor


	CString  s_buf;
	long  l_last_capa_increasment  =  0;
	CTimeCounter  c_timer;
	double  d_time_passed;
	c_timer.vSetStartNow();
	c_timer.bSetFinishOn(dTimeRestriction);
	
	long  li;
	for  (li = 0; 
			(
			( (dTimeRestriction > 0)&&(c_timer.bIsFinished()  ==  false) )
			||
			( (dTimeRestriction <= 0)&&(li < lNumberOfGenerations) )
			)
			&&
			(pc_best_species[0].dGetFOMLevel()  <  1);
		li++)
	{
		//taking the modifier from "brain storm" supervisor
		d_fom_modifier  =  c_brain_storm_superv.dGetNextGenerationState(d_pop_avr_fom);

		b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);

		//if we change the fom function during work we can not store best species during algorithm work
		if  (lCapaIncr  ==  0)  
		{
			b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
			v_input_best_species(lNumberOfSpeciesToPresent);
		}//if  (lCapaIncr  ==  0)

		//d_pop_avr_fom  =  d_population_fom / l_population_number;//collecting information for "brain dtorm" supervisor

		//generating statistical information
		c_timer.bGetTimePassed(&d_time_passed);
		if  (sPopulationFOMtrackingFile  !=  "")  
		{
			fprintf(pf_fom_tracking,"%ld high  \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_pop_avr_fom,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
		}//if  (sPopulationFOMtrackingFile  !=  "")

		s_buf.Format("High phase  Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
			li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
		listComm->Items->Add( (System::String *) s_buf);
		listComm->SelectedIndex  =  listComm->Items->Count - 1;
		listComm->Refresh();
				
		

		if  (b_cross_population_1_1(dCrossPossibility, li, dRandomCrossPossibility, d_pop_avr_fom, d_fom_modifier)  ==  false)
		{
			listComm->Items->Add(S"High level crossing error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			fclose(pf_fom_tracking);
			return(0);
		}//if  (b_cross_population(dCrossPossibility, li, dRandomCrossPossibility, d_fom_modifier)  ==  false)

		if  (b_mutate_population(pc_population, l_population_number, dMutatePossibility, li)  ==  false)
		{
			listComm->Items->Add(S"High level mutation error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			fclose(pf_fom_tracking);
			return(0);		
		}//if  (b_mutate_population(dMutatePossibility, li)  ==  false)

		b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);
		
		//if we change the fom function during work we can not store best species during algorithm work
		if  (lCapaIncr  ==  0)
		{
			//b_select_1_best_specie(lNumberOfSpeciesToPresent);
			b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
			v_input_best_species(lNumberOfSpeciesToPresent);
		}//if  (lCapaIncr  ==  0)

		//d_pop_avr_fom  +=  d_population_fom / l_population_number;//collecting information for "brain dtorm" supervisor
		//d_pop_avr_fom  =  d_pop_avr_fom / 2;	


		//generating statistical information
		c_timer.bGetTimePassed(&d_time_passed);
		if  (sPopulationFOMtrackingFile  !=  "")
		{
			fprintf(pf_fom_tracking,"%ld low   \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_pop_avr_fom,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
		}//if  (sPopulationFOMtrackingFile  !=  "")

		s_buf.Format("Low  phase  Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
			li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
		listComm->Items->Add( (System::String *) s_buf);
		listComm->SelectedIndex  =  listComm->Items->Count - 1;
		listComm->Refresh();
		


		if  (b_cross_population_low_level(dCrossPossibilityLowLevel, li, d_pop_avr_fom, d_fom_modifier)  ==  false)
		{
			listComm->Items->Add(S"Low level crossing error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			fclose(pf_fom_tracking);
			return(0);		
		}//if  (b_cross_population_low_level(dCrossPossibilityLowLevel, li, d_fom_modifier)  ==  false)


		if  (b_mutate_population_low_level(pc_population, l_population_number, dMutatePossibilityLowLevel, li)  ==  false)  
		{
			listComm->Items->Add(S"Low level mutation error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			fclose(pf_fom_tracking);
			return(0);
		}//if  (b_mutate_population_low_level(dMutatePossibilityLowLevel, li)  ==  false)


		

		
		//now - increasing the capacities if it was demanded
		if  ( (li - l_last_capa_increasment  ==  lCapaGenIncr)&&(lCapaGenIncr  !=  0) )
		{
			l_last_capa_increasment  =  li;


			for  (long  lk = 0; lk < i_number_of_pairs; lk++)
				pl_capacities[lk]  +=  lCapaIncr;
		
		}//if  (li - l_last_capa_increasment  ==  lCapaGenIncr)

					
			
	}//for  (long  li = 0; li < lNumberOfGenerations; li++)*/


	b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);
	b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
	//b_select_1_best_specie(lNumberOfSpeciesToPresent);
	c_timer.bGetTimePassed(&d_time_passed);
	if  (sPopulationFOMtrackingFile  !=  "")  
	{
		fprintf(pf_fom_tracking,"%ld final \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_pop_avr_fom,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
	}//if  (sPopulationFOMtrackingFile  !=  "")
	
	s_buf.Format("Finalizing  Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
			li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
	listComm->Items->Add( (System::String *) s_buf);
	listComm->SelectedIndex  =  listComm->Items->Count - 1;
	listComm->Refresh();
	


	//now we close fom tracking file if it was to be opened
	if  (sPopulationFOMtrackingFile  !=  "")  fclose(pf_fom_tracking);


	//now we create the report file
	i_create_report_files(sReportFileName, pfResFile, d_pop_avr_fom, lNumberOfSpeciesToPresent, lPenalty);


	return(1);

}//int   CTrajectorySetsFinder::iFindBestSet_1_1






/*
returned values:
1  -  ok
0  -  memory allocation problem
-1 -  bad population number
-2 -  bad number of generations
-3 -  possiblity badly inputted
-4 -  number of species to report is too high
-5 -  couldn't open population fom tracking file
-6 -  wrong defined species file filename or format
*/
int   CTrajectorySetsFinder::iFindBestSet_2_0_or_2_1_or_2_2
	(
	System::Windows::Forms::ListBox *  listComm,
	long  lNumberOfGenerations, long  lPopulationNumberDiv4, double dTimeRestriction, 
	double dCrossPossibility,  double  dMutatePossibility,
	double dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
	double dRandomCrossPossibility,//it affects high level crossing way
	long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
				//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
	CString  sIniFile,
	long  lNumberOfSpeciesToPresent,  CString  sReportFileName,
	CString  sFileSummarize, FILE *pfResFile, 
	bool  bUseOldPopulation,
	long  lCapaIncr,  long  lCapaGenIncr,

	//brainstorming
	long  lBrainAvrLen,  double  dBrainMinInc,
	long  lBrainTimeLen,  long  lBrainFinishTime,
	long  lBrainMinBreak,
	int  iAlgorithmVersion  //0- 2.0; 1- 2.1; 2- 2.2
	)
{

	if  (lPopulationNumberDiv4  <  2)  return(-1);
	//if  (lNumberOfGenerations  <  1)  return(-2);
	if  ( (dCrossPossibility > 1.0)||(dCrossPossibility < 0) )  return(-3);
	if  ( (dMutatePossibility > 1.0)||(dMutatePossibility < 0) )  return(-3);
	if  ( (dCrossPossibilityLowLevel > 1.0)||(dCrossPossibilityLowLevel < 0) )  return(-3);
	if  ( (dMutatePossibilityLowLevel > 1.0)||(dMutatePossibilityLowLevel < 0) )  return(-3);

	if  (lNumberOfSpeciesToPresent  >  lPopulationNumberDiv4 * 4)  return(-4);


	/*FILE  *pf_fom_tracking;
	
	sPopulationFOMtrackingFile = "";
	if  (sPopulationFOMtrackingFile  !=  "")
	{
		pf_fom_tracking  =  fopen( (LPCSTR) sPopulationFOMtrackingFile, "w+");
		if  (pf_fom_tracking  ==  NULL)  
			return(-5);
		else
			fprintf(pf_fom_tracking,"Pop number  \tAverage population FOM\t\t Best specie FOM \t Brain Storm \t Time\n\n");
	}//if  (sPopulationFOMtrackingFile  !=  "")  */



	if  (pc_best_species  !=  NULL)
		delete  []  pc_best_species;


	if  (bUseOldPopulation  ==  false)
	{

		if  (pc_population  !=  NULL)
			delete  []  pc_population;
	
		l_population_number  =  0;
		pc_population  =  new  CSingleTrajectorySet[lPopulationNumberDiv4 * 4];
		if  (pc_population  ==  NULL)  return(0);
		l_population_number  =  lPopulationNumberDiv4 * 4;
	}//if  (bUseOldPopulation  ==  false)
	else
	{
		for  (long  lk = 0; lk < l_population_number; lk++)
			pc_population[lk].vSetWhenCreated(0);
	}//else  if  (bUseOldPopulation  ==  false)



	pc_best_species  =  new  CSingleTrajectorySet[lNumberOfSpeciesToPresent];
	if  (pc_best_species  ==  NULL)  return(0);
	b_init_population(pc_best_species, lNumberOfSpeciesToPresent, lPenalty);
	pc_best_species[0].dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty);


	

	//genetic algorithm starts...
	if  (bUseOldPopulation  ==  false)
	{
		b_init_population(pc_population, l_population_number, lPenalty);
		if  (b_input_defined_species(sIniFile,true)  !=  true)  return(-6);
		b_init_population(pc_population, l_population_number, lPenalty);
		if  (b_input_defined_species(sIniFile,true)  !=  true)  return(-6);
	}//if  (bUseOldPopulation  ==  false)


	
	/*CString  s_buf1;
	s_buf1.Format("%.2lf", pc_population[0].dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty));
	::MessageBox(NULL, s_buf1, s_buf1, MB_OK);*/
	
	c_brain_storm_superv.bSetUpConfig
		(
		lBrainAvrLen,  dBrainMinInc,
		lBrainTimeLen,  lBrainFinishTime,
		lBrainMinBreak
		);
	double  d_pop_avr_fom = 0;//the information colector for "brain storm" supervisor
	double  d_fom_modifier = 0;//the modifier set up by "brain storm" supervisor


	CString  s_buf;
	long  l_last_capa_increasment  =  0;
	CTimeCounter  c_timer;
	double  d_time_passed;
	double  d_current_best;
	double  d_time_till_best, d_eval_till_best;
	c_timer.vSetStartNow();
	c_timer.bSetFinishOn(dTimeRestriction);
	
	d_fom_modifier  =  c_brain_storm_superv.dGetNextGenerationState(d_pop_avr_fom);
	b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);
	pc_best_species[0].vCopy(&pc_population[0]);
	

	d_current_best = 0;
	
	long  li;
	for  (li = 0; 
			(
			( (dTimeRestriction > 0)&&(c_timer.bIsFinished()  ==  false) )
			||
			( (dTimeRestriction <= 0)&&(li < lNumberOfGenerations) )
			)
			&&
			(pc_best_species[0].dGetFOMLevel()  <  1);
		li++)
	{
		//taking the modifier from "brain storm" supervisor
		d_fom_modifier  =  c_brain_storm_superv.dGetNextGenerationState(d_pop_avr_fom);

		b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);

		//if we change the fom function during work we can not store best species during algorithm work
		if  (lCapaIncr  ==  0)  
		{
			b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
			v_input_best_species(lNumberOfSpeciesToPresent);
		}//if  (lCapaIncr  ==  0)

		//d_pop_avr_fom  =  d_population_fom / l_population_number;//collecting information for "brain dtorm" supervisor

		//generating statistical information
		c_timer.bGetTimePassed(&d_time_passed);
		/*if  (sPopulationFOMtrackingFile  !=  "")  
		{
			fprintf(pf_fom_tracking,"%ld high  \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_population_fom / l_population_number,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
		}//if  (sPopulationFOMtrackingFile  !=  "")*/

		s_buf.Format("High phase  best: %.8lf (%.8lf) Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
			pc_best_species[0].dGetFOMLevel(), ((double)1.0)/pc_best_species[0].dGetFOMLevel() - 1,
			li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
		listComm->Items->Add( (System::String *) s_buf);
		listComm->SelectedIndex  =  listComm->Items->Count - 1;
		listComm->Refresh();
				
		

		if  (b_cross_population_1_1(dCrossPossibility, li, dRandomCrossPossibility, d_pop_avr_fom, d_fom_modifier)  ==  false)
		{
			listComm->Items->Add(S"High level crossing error!");
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();
			//fclose(pf_fom_tracking);
			return(0);
		}//if  (b_cross_population(dCrossPossibility, li, dRandomCrossPossibility, d_fom_modifier)  ==  false)

		if  ( (iAlgorithmVersion  ==  0)||(iAlgorithmVersion  ==  1) )
		{
			if  (b_mutate_population_2_0(dMutatePossibility, li)  ==  false)
			{
				listComm->Items->Add(S"High level mutation error!");
				listComm->SelectedIndex  =  listComm->Items->Count - 1;
				listComm->Refresh();
				//fclose(pf_fom_tracking);
				return(0);		
			}//if  (b_mutate_population(dMutatePossibility, li)  ==  false)		
		}//if  ( (iAlgorithmVersion  ==  0)||(iAlgorithmVersion  ==  1) )

		if  (iAlgorithmVersion  ==  2)
		{
			if  (b_mutate_population(pc_population, l_population_number, dMutatePossibility, li)  ==  false)
			{
				listComm->Items->Add(S"High level mutation error!");
				listComm->SelectedIndex  =  listComm->Items->Count - 1;
				listComm->Refresh();
				//fclose(pf_fom_tracking);
				return(0);		
			}//if  (b_mutate_population(dMutatePossibility, li)  ==  false)		
		}//if  ( (iAlgorithmVersion  ==  0)||(iAlgorithmVersion  ==  1) )
		
		
		b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);
		
		//if we change the fom function during work we can not store best species during algorithm work
		if  (lCapaIncr  ==  0)
		{
			//b_select_1_best_specie(lNumberOfSpeciesToPresent);
			b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
			v_input_best_species(lNumberOfSpeciesToPresent);
		}//if  (lCapaIncr  ==  0)

		//d_pop_avr_fom  +=  d_population_fom / l_population_number;//collecting information for "brain dtorm" supervisor
		//d_pop_avr_fom  =  d_pop_avr_fom / 2;	


		//generating statistical information
		c_timer.bGetTimePassed(&d_time_passed);
		/*if  (sPopulationFOMtrackingFile  !=  "")
		{
			fprintf(pf_fom_tracking,"%ld low   \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_population_fom / l_population_number,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
		}//if  (sPopulationFOMtrackingFile  !=  "")*/

		s_buf.Format("Low  phase best: %.8lf (%.8lf)  Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
			pc_best_species[0].dGetFOMLevel(), ((double)1.0)/pc_best_species[0].dGetFOMLevel() - 1,
			li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
		listComm->Items->Add( (System::String *) s_buf);
		listComm->SelectedIndex  =  listComm->Items->Count - 1;
		listComm->Refresh();
		


		if  (iAlgorithmVersion  ==  0)
		{
			if  (b_cross_population_low_level_2_0(dCrossPossibilityLowLevel, li, d_pop_avr_fom, d_fom_modifier)  ==  false)
			{
				listComm->Items->Add(S"Low level crossing error!");
				listComm->SelectedIndex  =  listComm->Items->Count - 1;
				listComm->Refresh();
				//fclose(pf_fom_tracking);
				return(0);		
			}//if  (b_cross_population_low_level(dCrossPossibilityLowLevel, li, d_fom_modifier)  ==  false)
		}//if  (iAlgorithmVersion  ==  0)

		if  ( (iAlgorithmVersion  ==  1)||(iAlgorithmVersion  ==  2) )
		{
			if  (b_cross_population_low_level_2_1(dCrossPossibilityLowLevel, li, d_pop_avr_fom, d_fom_modifier)  ==  false)
			{
				listComm->Items->Add(S"Low level crossing error!");
				listComm->SelectedIndex  =  listComm->Items->Count - 1;
				listComm->Refresh();
				//fclose(pf_fom_tracking);
				return(0);		
			}//if  (b_cross_population_low_level(dCrossPossibilityLowLevel, li, d_fom_modifier)  ==  false)
		}//if  (iAlgorithmVersion  ==  1)

		if  ( (iAlgorithmVersion  ==  0)||(iAlgorithmVersion  ==  1) )
		{
			if  (b_mutate_population_low_level_2_0(dMutatePossibilityLowLevel, li)  ==  false)  
			{
				listComm->Items->Add(S"Low level mutation error!");
				listComm->SelectedIndex  =  listComm->Items->Count - 1;
				listComm->Refresh();
				//fclose(pf_fom_tracking);
				return(0);
			}//if  (b_mutate_population_low_level(dMutatePossibilityLowLevel, li)  ==  false)
		}//if  ( (iAlgorithmVersion  ==  0)||(iAlgorithmVersion  ==  1) )


		if  (iAlgorithmVersion  ==  2)
		{
			if  (b_mutate_population_low_level(pc_population, l_population_number, dMutatePossibilityLowLevel, li)  ==  false)  
			{
				listComm->Items->Add(S"Low level mutation error!");
				listComm->SelectedIndex  =  listComm->Items->Count - 1;
				listComm->Refresh();
				//fclose(pf_fom_tracking);
				return(0);
			}//if  (b_mutate_population_low_level(dMutatePossibilityLowLevel, li)  ==  false)		
		}//if  (iAlgorithmVersion  ==  2)


	
		


		
		//now - increasing the capacities if it was demanded
		if  ( (li - l_last_capa_increasment  ==  lCapaGenIncr)&&(lCapaGenIncr  !=  0) )
		{
			l_last_capa_increasment  =  li;


			for  (long  lk = 0; lk < i_number_of_pairs; lk++)
				pl_capacities[lk]  +=  lCapaIncr;
		
		}//if  (li - l_last_capa_increasment  ==  lCapaGenIncr)



		if  (d_current_best  <  pc_best_species[0].dGetFOMLevel())
		{
			c_timer.bGetTimePassed(&d_time_passed);
			d_current_best = pc_best_species[0].dGetFOMLevel();
			d_time_till_best = d_time_passed;
			d_eval_till_best = c_translator.pcGetFittnesCounter()->dEvalNumber();
		}//if  (d_current_best  <  pc_best_species[0].dGetFOMLevel())
		
		System::Windows::Forms::Application::DoEvents();

	}//for  (long  li = 0; li < lNumberOfGenerations; li++)


	b_count_fom(pc_population, l_population_number, &d_pop_avr_fom,  lPenalty);
	b_select_best_species(pc_population, l_population_number, lNumberOfSpeciesToPresent);
	c_timer.bGetTimePassed(&d_time_passed);
	/*if  (sPopulationFOMtrackingFile  !=  "")  
	{
		fprintf(pf_fom_tracking,"%ld final \t\t%.10lf  \t\t\t%.10lf \t %d \t%lf \t%lf\n",
				li,
				d_population_fom / l_population_number,
				pc_best_species[0].dGetFOMLevel(),
				c_brain_storm_superv.iGetCurrentState(),d_fom_modifier,
				d_time_passed
				);
	}//if  (sPopulationFOMtrackingFile  !=  "")*/
	
	s_buf.Format("Finalizing  Population number: %ld  Number of species: %ld Average population FOM:%.10lf\n Brain storm: %d(%lf) Time:%lf", 
			li, l_population_number, d_pop_avr_fom, 
			c_brain_storm_superv.iGetCurrentState(),d_fom_modifier, d_time_passed);
	listComm->Items->Add( (System::String *) s_buf);
	listComm->SelectedIndex  =  listComm->Items->Count - 1;
	listComm->Refresh();
	


	//now we close fom tracking file if it was to be opened
	//if  (sPopulationFOMtrackingFile  !=  "")  fclose(pf_fom_tracking);


	FILE  *pf_run_save;
	CString  s_effective_file_name;
	s_effective_file_name.Format("%s_RUN.txt", sReportFileName);
	pf_run_save  =  fopen(s_effective_file_name,  "w+");
	if  (pf_run_save  !=  NULL)
	{
		for  (int  ii = 0; ii  <  listComm->Items->get_Count();  ii++)
		{
			s_buf  =  listComm->Items->get_Item(ii)->ToString();		
			fprintf(pf_run_save,  "%s\n", s_buf);
		}//for  (int  ii = 0; ii  <  listInfo->Items->get_Count();  ii++)
		fclose(pf_run_save);
	}//if  (pf_run_save  !=  NULL)


	//now we create the report file
	i_create_report_files(sReportFileName, pfResFile, d_pop_avr_fom, lNumberOfSpeciesToPresent, lPenalty);


	if  (sFileSummarize  !=  "")
	{
		FILE  *pf_summarized_rep;
		pf_summarized_rep  =  fopen(sFileSummarize, "a");


		double  d_optimized_func_val;
		d_optimized_func_val =  Math::Round(((double) 1.0) / pc_best_species[0].dGetFOMLevel()  -1);
		

		double  d_path_len_avr;
		int i_path_len_min, i_path_len_max;

		pc_best_species[0].vGetPathStats(&d_path_len_avr, &i_path_len_min, &i_path_len_max);

		CString  s_path_lens;
		s_path_lens = pc_best_species[0].sReportPathLens(20);

		//TUTAJ DOLOZYC SREDNIA SLUGOSC SCIEZKI I MINIMALNA/MAKSYMALNA DLUGOSC SCIEZKI, EWENTUALNIE LICZBE SCEIZEK O DLUGOSCI 1,2,3,4,5,...,20, 20<
		fprintf
			(pf_summarized_rep, 
			"%.8lf \t %.0lf \t %.2lf \t %.0lf \t %.4lf \t %d \t %d \t %.0lf \t %.2lf \t %d \t %s \t %s \n", 

			pc_best_species[0].dGetFOMLevel(), d_optimized_func_val, d_time_till_best, d_eval_till_best,
			d_path_len_avr, i_path_len_min, i_path_len_max,
			c_translator.pcGetFittnesCounter()->dEvalNumber(),
			d_time_passed, i_gen, 
			sReportFileName,
			s_path_lens
			);
		fclose(pf_summarized_rep);		
	}//if  (sFileSummarize  !=  "")


	return(1);

}//int   CTrajectorySetsFinder::iFindBestSet_2_0




CError  CTrajectorySetsFinder::eGetIniFitness(CString  sIniFile, double  *pdFitness,  long  lPenalty)
{
	CError  c_err;
	CString  s_buf;

	CSingleTrajectorySet  c_single_set;

	if  (
		c_single_set.bInit
			(pl_start_finish_pairs, i_number_of_pairs, &c_virtual_ways, c_translator.pcGetSim(), c_translator.pcGetFittnesCounter(), pl_capacities,  lPenalty)
		==
		false
		)
	{
		c_err.vPutError("CTrajectorySetsFinder::eGetIniFitness init solution was not read in successfully.");
		return(c_err);	
	}//if  (
		
	int  i_ini_type  =  i_check_header(sIniFile);

	FILE  *pf_source;

	pf_source  =  fopen( (LPCSTR)  sIniFile, "r+");
	if  (pf_source  ==  NULL)  
	{
		c_err.vPutError("Couldnt open ini file.");
		return(c_err);	
	}//if  (pf_source  ==  NULL)  


	bool  b_ini_type_found  =  false;
	if  (i_ini_type  ==  1)
	{
		b_ini_type_found  =  true;

		if  (
			c_single_set.iLoadFromOldIniFile(&c_translator,  pf_source,  pl_capacities, true)  
			!=  1
			)  
		{
            fclose(pf_source);
			s_buf.Format("Couldnt load from (%s)", (LPCSTR) sIniFile);
			c_err.vPutError(s_buf);
			return(c_err);
		}//if  (pc_single_trajectory_set_buf->iLoadFromFile(pf_source,  &c_translator,  bTranslate)  !=  1)  
	}//if  (i_ini_type  ==  1)


	if  (i_ini_type  ==  2)
	{
		b_ini_type_found  =  true;

		if  (
			c_single_set.iLoadFromIniFile(&c_translator,  pf_source,  pl_capacities,  true)
			!=  1
			)  
		{
			fclose(pf_source);
			s_buf.Format("Couldnt load from (%s)", (LPCSTR) sIniFile);
			c_err.vPutError(s_buf);
			return(c_err);
		}//if  (pc_single_trajectory_set_buf->iLoadFromFile(pf_source,  &c_translator,  bTranslate)  !=  1)  
	}//if  (i_ini_type  ==  1)

	fclose(pf_source);

	if  (b_ini_type_found  ==  true)
		*pdFitness  =  c_single_set.dCountFOM(c_translator.pcGetFittnesCounter(),  pl_capacities, lPenalty);
	else
	{
		s_buf.Format("Couldnt find ini file type for (%s)", (LPCSTR) sIniFile);
		c_err.vPutError(s_buf);
	}//else  if  (b_ini_type_found  ==  true)

	return(c_err);
}//CError  CTrajectorySetsFinder::eGetIniFitness(CString  sIniFile)




/*
returned values:
1  -  ok
-2 -  bets specie table not inited
-3 -  couldn't open short report file
-4 -  couldn't open full report file
*/
int  CTrajectorySetsFinder::i_create_report_files(CString  sFileName, FILE *pfResFile, double  dFitAvr, long lNumberToPresent, long  lPenalty)
{

	/*//first, we create short version of a report
	FILE  *pf_rep_short;


	if  (pc_best_species  ==  NULL)  return(-2);

	pf_rep_short  =  fopen( (LPCSTR)  (sFileName + ".rep") , "w+");
	if  (pf_rep_short  == NULL)  return(-3);


	fprintf(pf_rep_short,"\nilosc osobnikow w populacji: %ld\n", l_population_number);
	fprintf(pf_rep_short,"srednia przystosowania osobnikow w ostatniej populacji: %.10lf\n\n\n", d_population_fom / l_population_number);
	

	long  li;
	for  (li = 0; li < lNumberToPresent; li++)
	{

		fprintf(pf_rep_short,"\n\n\nosobnik numer: %ld\n", li);
//		fprintf(pf_rep,"poziom przystosowania: %lf\n\n", pd_fom_values[li]);

		pc_best_species[li].vReport(pf_rep_short, false, pl_capacities, lPenalty);
	
	}//for  (long  li = 0; li < l_population_number; li++)

	fclose(pf_rep_short);*/




	
	//second, we create a full version of a report

	FILE  *pf_rep_full;


	//pf_rep_full  =  fopen( (LPCSTR)  (sFileName /*+ ".ful"*/) , "w+");
	pf_rep_full = pfResFile;
	if  (pf_rep_full  == NULL)  return(-4);


	fprintf(pf_rep_full,"\nilosc osobnikow w populacji: %ld\n", l_population_number);
	fprintf(pf_rep_full,"srednia przystosowania osobnikow w ostatniej populacji: %lf\n\n\n", dFitAvr);
	

	long li;
	for  (li = 0; li < lNumberToPresent; li++)
	{

		fprintf(pf_rep_full,"osobnik numer: %ld\n", li);
//		fprintf(pf_rep,"poziom przystosowania: %lf\n\n", pd_fom_values[li]);

		pc_best_species[li].vReport(pf_rep_full, true, pl_capacities, lPenalty);
	
	}//for  (long  li = 0; li < l_population_number; li++)

	fclose(pf_rep_full);





	//third we create a virtual way database report file
	//c_virtual_ways.iCreateReportFile(sFileName + ".vwd");
	//c_virtual_ways.iCreateStatisticsReportFile(sFileName + ".vws");


	return(1);


}//int  CTrajectorySetsFinder::iCreateReport(CString  sFileName)












bool  CTrajectorySetsFinder::b_count_fom(CSingleTrajectorySet *pcPopulation, long lPopSize, double *pdAvrPopFitness, long  lPenalty)
{
	*pdAvrPopFitness  =  0;

	double  d_buf;
	
	for  (long  li = 0; li < lPopSize; li++)
	{

		d_buf  =  pcPopulation[li].dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty);

		
		*pdAvrPopFitness +=  d_buf;
	}//for  (long  li = 0; li < l_population_number; li++)

	*pdAvrPopFitness =  *pdAvrPopFitness / lPopSize;

	
	return(true);


	/*d_population_fom  =  0;

	double  d_buf;
	
	for  (long  li = 0; li < l_population_number; li++)
	{

		d_buf  =  pc_population[li].dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty);

		
		d_population_fom  +=  d_buf;
		//pd_fom_values[li]  =  d_buf;
	
	}//for  (long  li = 0; li < l_population_number; li++)

	
	return(true);*/

}//bool  CTrajectorySetsFinder::b_count_fom()











bool  CTrajectorySetsFinder::b_cross_population
	(double  dCrossPossibility,  long lGenNum,  double  dRandomCrossPossibility, double dPopFitAvr, double dFOMmodifier)
{

//	if  (pc_new_population  !=  NULL)  delete  []  pc_new_population;

	pc_new_population  =  new  CSingleTrajectorySet[l_population_number];
	if  (pc_new_population  ==  NULL)  return(false);




	long  l_mother, l_father;

	for  (long  li = 0; li < l_population_number / 4; li++)
	{

		v_find_parents(&l_mother, &l_father, dPopFitAvr,  dFOMmodifier);

		pc_new_population[li * 4].vCopy(&pc_population[l_mother]);
		pc_new_population[li * 4 + 1].vCopy(&pc_population[l_father]);
		pc_new_population[li * 4 + 2].vCopy(&pc_population[l_mother]);
		pc_new_population[li * 4 + 3].vCopy(&pc_population[l_father]);



		if  (dRand()  <  dCrossPossibility)
		{

			pc_new_population[li * 4].bCross
				(
				&pc_new_population[li * 4 + 1],
				&pc_new_population[li * 4 + 2],
				&pc_new_population[li * 4 + 3],
				dRandomCrossPossibility,
				pl_capacities
				);

			pc_new_population[li * 4 + 2].vSetWhenCreated(lGenNum);
			pc_new_population[li * 4 + 3].vSetWhenCreated(lGenNum);

					
		}//if  (dRand()  <  dCrossPossibility)
		


	}//for  (li = 0; li < l_population_number; li++)


	delete  []  pc_population;

	pc_population  =  pc_new_population;


	

	return(true);

}//bool  CTrajectorySetsFinder::b_cross_population()





bool  CTrajectorySetsFinder::b_cross_population_1_1
	(double  dCrossPossibility,  long lGenNum,  double  dRandomCrossPossibility, double dPopFitAvr, double dFOMmodifier)
{

	pc_new_population  =  new  CSingleTrajectorySet[l_population_number];
	if  (pc_new_population  ==  NULL)  return(false);

	long  l_mother, l_father;

	for  (long  li = 0; li < l_population_number / 2; li++)
	{

		v_find_parents(&l_mother, &l_father, dPopFitAvr, dFOMmodifier);

		pc_new_population[li * 2].vCopy(&pc_population[l_mother]);
		pc_new_population[li * 2 + 1].vCopy(&pc_population[l_father]);


		if  (dRand()  <  dCrossPossibility)
		{

			pc_population[l_mother].bCross
				(
				&pc_population[l_father],
				&pc_new_population[li * 2],
				&pc_new_population[li * 2 + 1],
				dRandomCrossPossibility,
				pl_capacities
				);

			pc_new_population[li * 2].vSetWhenCreated(lGenNum);
			pc_new_population[li * 2 + 1].vSetWhenCreated(lGenNum);

					
		}//if  (dRand()  <  dCrossPossibility)
		


	}//for  (li = 0; li < l_population_number; li++)


	delete  []  pc_population;

	pc_population  =  pc_new_population;
	return(true);
}//bool  CTrajectorySetsFinder::b_cross_population_1_1











bool  CTrajectorySetsFinder::b_cross_population_low_level(double  dCrossPossibility,  long  lGenNum,  double dPopFitAvr, double dFOMmodifier)
{

	
	pc_new_population  =  new  CSingleTrajectorySet[l_population_number];
	if  (pc_new_population  ==  NULL)  return(false);




	long  l_mother, l_father;

	for  (long  li = 0; li < l_population_number / 2; li++)
	{

		v_find_parents(&l_mother, &l_father, dPopFitAvr, dFOMmodifier);

		pc_new_population[li * 2].vCopy(&pc_population[l_mother]);
		pc_new_population[li * 2 + 1].vCopy(&pc_population[l_father]);
	


		if  (dRand()  <  dCrossPossibility)
		{

			if  (pc_new_population[li * 2].bCrossLowLevel
				(&pc_new_population[li * 2 + 1],  pl_capacities)  ==  false)
				return(false);

			pc_new_population[li * 2].vSetWhenCreated(lGenNum);
			pc_new_population[li * 2 + 1].vSetWhenCreated(lGenNum);

			pc_population[l_mother].bCrossLowLevel(&pc_population[l_father],  pl_capacities);
					
		}//if  (dRand()  <  dCrossPossibility)
		


	}//for  (li = 0; li < l_population_number; li++)


	delete  []  pc_population;

	pc_population  =  pc_new_population;


	

	return(true);

}//bool  CTrajectorySetsFinder::b_cross_population()



bool  CTrajectorySetsFinder::b_cross_population_low_level_2_0(double  dCrossPossibility,  long  lGenNum,  double dPopFitAvr, double dFOMmodifier)
{

	
	long  l_mother, l_father;

	for  (long  li = 0; li < l_population_number / 2; li++)
	{

		v_find_parents(&l_mother, &l_father, dPopFitAvr, dFOMmodifier);

		if  (dRand()  <  dCrossPossibility)
		{

			pc_population[l_mother].bCrossLowLevelLLD(pl_capacities);
			pc_population[l_mother].vSetWhenCreated(lGenNum);					
		}//if  (dRand()  <  dCrossPossibility)
	}//for  (li = 0; li < l_population_number; li++)

	return(true);
}//bool  CTrajectorySetsFinder::b_cross_population()





bool  CTrajectorySetsFinder::b_cross_population_low_level_2_1(double  dCrossPossibility,  long  lGenNum,  double dPopFitAvr, double dFOMmodifier)
{


	pc_new_population  =  new  CSingleTrajectorySet[l_population_number];
	if  (pc_new_population  ==  NULL)  return(false);




	long  l_mother, l_father;

	for  (long  li = 0; li < l_population_number / 2; li++)
	{

		v_find_parents(&l_mother, &l_father, dPopFitAvr, dFOMmodifier);

		pc_new_population[li * 2].vCopy(&pc_population[l_mother]);
		pc_new_population[li * 2 + 1].vCopy(&pc_population[l_father]);
	


		if  (dRand()  <  dCrossPossibility)
		{

			if  (pc_new_population[li * 2].bCrossLowLevelLLD(pl_capacities)  == false)
				return(false);

			if  (pc_new_population[li * 2 + 1].bCrossLowLevelLLD(pl_capacities)  == false)
				return(false);

			pc_new_population[li * 2].vSetWhenCreated(lGenNum);
			pc_new_population[li * 2 + 1].vSetWhenCreated(lGenNum);
					
		}//if  (dRand()  <  dCrossPossibility)
		


	}//for  (li = 0; li < l_population_number; li++)


	delete  []  pc_population;

	pc_population  =  pc_new_population;


	

	return(true);

	
	for  (long  li = 0; li < l_population_number / 2; li++)
	{

		v_find_parents(&l_mother, &l_father, dPopFitAvr, dFOMmodifier);

		if  (dRand()  <  dCrossPossibility)
		{

			pc_population[l_mother].bCrossLowLevelLLD(pl_capacities);
			pc_population[l_mother].vSetWhenCreated(lGenNum);					
		}//if  (dRand()  <  dCrossPossibility)
	}//for  (li = 0; li < l_population_number; li++)

	return(true);
}//bool  CTrajectorySetsFinder::b_cross_population()



bool  CTrajectorySetsFinder::b_cross_population_low_level_2_1_tournament(CSingleTrajectorySet  **pcPopulation, long lPopSize, double  dCrossPossibility, long  lGenNum)
{
	pc_new_population  =  new  CSingleTrajectorySet[lPopSize];
	if  (pc_new_population  ==  NULL)  return(false);


	long  l_mother, l_father;

	for  (long  li = 0; li < lPopSize / 2; li++)
	{
		v_find_parents_tournament(*pcPopulation, lPopSize, &l_mother, &l_father);

		pc_new_population[li * 2].vCopy(&((*pcPopulation)[l_mother]));
		pc_new_population[li * 2 + 1].vCopy(&((*pcPopulation)[l_father]));
	


		if  (dRand()  <  dCrossPossibility)
		{

			if  (pc_new_population[li * 2].bCrossLowLevelLLD(pl_capacities)  == false)
				return(false);

			if  (pc_new_population[li * 2 + 1].bCrossLowLevelLLD(pl_capacities)  == false)
				return(false);

			pc_new_population[li * 2].vSetWhenCreated(lGenNum);
			pc_new_population[li * 2 + 1].vSetWhenCreated(lGenNum);
					
		}//if  (dRand()  <  dCrossPossibility)*
		


	}//for  (li = 0; li < l_population_number; li++)


	delete  []  *pcPopulation;

	*pcPopulation  =  pc_new_population;


	

	return(true);
}//bool  CTrajectorySetsFinder::b_cross_population_low_level_2_1_tournament(CSingleTrajectorySet  **pcPopulation, long lPopSize, double  dCrossPossibility, long  lGenNum)

















long  CTrajectorySetsFinder::l_find_one_parent(double  dFitnessAvr, double  dFOMmodifier)
{

	double  d_rand;

	d_rand  =  dRand();//first we take a number between 0 and 1

	d_rand  *=  (dFitnessAvr * l_population_number  +  dFOMmodifier * l_population_number);//we scale it on whole population


	double d_sum  =  0;
	for  (long  li = 0; li < l_population_number; li++)
	{
		d_sum  +=  pc_population[li].dGetFOMLevel() + dFOMmodifier;//pd_fom_values[li];
		
		if  (d_sum >  d_rand)  
			return(li);

		
	
	}//for  (long  li = 0; li < l_population_number; li++)

	
	return(l_population_number - 1);//it should be impossible to get in here but if we did we return the last specie

}//long  CTrajectorySetsFinder::l_find_one_parent()



long  CTrajectorySetsFinder::l_find_one_parent_tournament(CSingleTrajectorySet *pcPopulation, long lPopSize)
{
	long  l_par_0, l_par_1;
	
	l_par_0 = lRand(lPopSize);
	l_par_1 = lRand(lPopSize);

	if  (pcPopulation[l_par_0].dGetFOMLevel() > pcPopulation[l_par_1].dGetFOMLevel())  return(l_par_0);

		
	return(l_par_1);
}//long  CTrajectorySetsFinder::l_find_one_parent_tournament(CSingleTrajectorySet *pcPopulation)








void  CTrajectorySetsFinder::v_find_parents(long *plMother, long  *plFather, double dPopFitnessAvr, double dFOMmodifier)
{

	*plMother  =  l_find_one_parent(dPopFitnessAvr, dFOMmodifier);
	*plFather  =  l_find_one_parent(dPopFitnessAvr, dFOMmodifier);



}//void  CTrajectorySetsFinder::v_find_parents(long *plMother, long  *plFather)



void  CTrajectorySetsFinder::v_find_parents_tournament(CSingleTrajectorySet *pcPopulation, long lPopSize,  long *plMother, long  *plFather)
{

	*plMother  =  l_find_one_parent_tournament(pcPopulation, lPopSize);
	*plFather  =  l_find_one_parent_tournament(pcPopulation, lPopSize);



}//void  CTrajectorySetsFinder::v_find_parents(long *plMother, long  *plFather)








bool  CTrajectorySetsFinder::b_init_population(CSingleTrajectorySet  *pcPopulation, long lPopSize,  long  lPenalty)
{

	for  (long  li = 0; li < lPopSize; li++)
	{

		if  (
			pcPopulation[li].bInit
			(pl_start_finish_pairs, i_number_of_pairs, &c_virtual_ways, c_translator.pcGetSim(),  c_translator.pcGetFittnesCounter(), pl_capacities, lPenalty)
			==
			false
			)
			return(false);
	
	}//for  (long  li = 0; li < l_population_number; li++)


	
	return(true);

}//bool  CTrajectorySetsFinder::b_init_population()




/*
3 - result.ful file
2 - new ini
1 - old ini
0 - unexpected end of file
-1 - can not open file
*/
int  CTrajectorySetsFinder::i_check_header(CString  sIniFile)
{

	FILE  *pf_source;
	pf_source  =  fopen( (LPCSTR)  sIniFile, "r+");

	if  (pf_source  ==  NULL)  return(-1);//file not found or can not be opened


	char  c_buf;
	long  l_buf;

	CString  s_buf;
	s_buf  =  Tools::sReadLine(pf_source, &s_buf);
	s_buf  =  Tools::sReadLine(pf_source, &s_buf);
	int i_check = s_buf.Find("populacji");
		

	fclose(pf_source);
	if  (i_check  >  0)  
		return(3);
	else
		pf_source  =  fopen( (LPCSTR)  sIniFile, "r+");

	
	fscanf(pf_source, "%ld", &l_buf);//connections number
	fscanf(pf_source, "%ld", &l_buf);//connection number

	//we find 4th enter after connection number...
	c_buf  =  'a';//ini value different from '\n'
	while  ( (!feof(pf_source))&&(c_buf  !=  '\n') )  fscanf(pf_source, "%c", &c_buf);
	c_buf  =  'a';//ini value different from '\n'
	while  ( (!feof(pf_source))&&(c_buf  !=  '\n') )  fscanf(pf_source, "%c", &c_buf);
	if  (c_buf  !=  '\n')  
	{
		fclose(pf_source);
		return(0);
	}//if  (c_buf  !=  '\n')  

	fscanf(pf_source, "%c", &c_buf);
	fclose(pf_source);
	if  ( (c_buf  ==  ' ')||(c_buf  ==  '\n') )
		return(2);
	else
		return(1);

}//int  CTrajectorySetsFinder::i_check_header(CString  sIniFile)




bool  CTrajectorySetsFinder::b_input_defined_specie
	(
	CSingleTrajectorySet  *pcDefinedSpecie, CString  sIniFile,  bool  bTranslate
	)
{
	if  (sIniFile  ==  "")  return(true);

	int  i_ini_type;

	i_ini_type  =  i_check_header(sIniFile);
	if  (i_ini_type  <=  0)  return(false);
	
	FILE  *pf_source;

	pf_source  =  fopen( (LPCSTR)  sIniFile, "r+");


	if  (pf_source  ==  NULL)  return(false);//file not found or can not be opened

	
	
	if  (pcDefinedSpecie  ==  NULL)  
	{
		fclose(pf_source);
		return(false);//unexpected unallocated specie
	}//if  (pc_single_trajectory_set_buf  ==  NULL)  

		
	if  (i_ini_type  ==  1)
	{

		if  (
			pcDefinedSpecie->iLoadFromOldIniFile(&c_translator,  pf_source,  pl_capacities,  bTranslate)  
			!=  1
			)  
		{
			fclose(pf_source);
			return(false);
		}//if  (pc_single_trajectory_set_buf->iLoadFromFile(pf_source,  &c_translator,  bTranslate)  !=  1)  
	}//if  (i_ini_type  ==  1)


	if  (i_ini_type  ==  2)
	{

		if  (
			pcDefinedSpecie->iLoadFromIniFile(&c_translator,  pf_source,  pl_capacities, bTranslate)
			!=  1
			)  
		{
			fclose(pf_source);
			return(false);
		}//if  (pc_single_trajectory_set_buf->iLoadFromFile(pf_source,  &c_translator,  bTranslate)  !=  1)  
	}//if  (i_ini_type  ==  1)



	if  (i_ini_type  ==  3)
	{
		if  (
			pcDefinedSpecie->iLoadFromFulFile(&c_translator,  pf_source,  pl_capacities)
			!=  1
			)  
		{
			fclose(pf_source);
			return(false);
		}//if  (pc_single_trajectory_set_buf->iLoadFromFile(pf_source,  &c_translator,  bTranslate)  !=  1)  
	}//if  (i_ini_type  ==  1)


	fclose(pf_source);
    return(true);
}//bool  CTrajectorySetsFinder::b_input_defined_specie




bool  CTrajectorySetsFinder::b_input_defined_species(CString  sIniFile,  bool  bTranslate)
{
	CSingleTrajectorySet  *pc_single_trajectory_set_buf;
	pc_single_trajectory_set_buf  =  &(pc_population[0]);
    return(b_input_defined_specie(pc_single_trajectory_set_buf, sIniFile, bTranslate));
}//bool  b_input_defined_species(CString  sIniFile,  bool  bTranslate = true)









bool  CTrajectorySetsFinder::b_mutate_population(CSingleTrajectorySet  *pcPopulation,  long lPopSize, double  dMutatePossibility,  long  lGenNum)
{
	for  (long  li = 0; li < lPopSize; li++)
	{
		if  (dRand()  <  dMutatePossibility)
		{

			if  (
				pcPopulation[li].bMutate(pl_capacities)
				==
				false
				)
				return(false);

			
			pcPopulation[li].vSetWhenCreated(lGenNum);

		}//if  (dRand()  <  dMutatePossibility)
	}//for  (long  li = 0; li < l_population_number; li++)

	return(true);
}//bool  CTrajectorySetsFinder::b_mutate_population()




bool  CTrajectorySetsFinder::b_mutate_population_2_0(double  dMutatePossibility,  long  lGenNum)
{
	for  (long  li = 0; li < l_population_number; li++)
	{
		if  (dRand()  <  dMutatePossibility)
		{

			if  (
				pc_population[li].bMutateLLD(pl_capacities)
				==
				false
				)
				return(false);

			pc_population[li].vSetWhenCreated(lGenNum);

		}//if  (dRand()  <  dMutatePossibility)
	}//for  (long  li = 0; li < l_population_number; li++)

	return(true);
}//bool  CTrajectorySetsFinder::b_mutate_population()







bool  CTrajectorySetsFinder::b_mutate_population_low_level(CSingleTrajectorySet  *pcPopulation, long lPopSize, double  dMutatePossibility,  long  lGenNum)
{

	
	for  (long  li = 0; li < lPopSize; li++)
	{

		if  (dRand()  <  dMutatePossibility)
		{

			if  (
				pcPopulation[li].bMutateLowLevel(pl_capacities)
				==
				false
				)
				return(false);

			pcPopulation[li].vSetWhenCreated(lGenNum);

		}//if  (dRand()  <  dMutatePossibility)
	
	}//for  (long  li = 0; li < l_population_number; li++)



	return(true);

}//bool  CTrajectorySetsFinder::b_mutate_population()






bool  CTrajectorySetsFinder::b_mutate_population_low_level_2_0(double  dMutatePossibility,  long  lGenNum)
{

	for  (long  li = 0; li < l_population_number; li++)
	{

		if  (dRand()  <  dMutatePossibility)
		{

			if  (
				//pc_population[li].bMutateLowLevel()
				pc_population[li].bMutateLLD(pl_capacities)
				==
				false
				)
				return(false);

			pc_population[li].vSetWhenCreated(lGenNum);

		}//if  (dRand()  <  dMutatePossibility)
	
	}//for  (long  li = 0; li < l_population_number; li++)



	return(true);

}//bool  CTrajectorySetsFinder::b_mutate_population()









//the table MUST be previusly initiated
bool  CTrajectorySetsFinder::b_select_best_species(CSingleTrajectorySet  *pcPopulation, long lPopSize, long  lNumberOfSpeciesToSelect, CSingleTrajectorySet **pcThisPopBest)
{

	double  d_worst_fom;
	double  d_new_specie_fom;

	if  (pcThisPopBest  !=  NULL)  *pcThisPopBest = &(pcPopulation[0]);


	if  (lNumberOfSpeciesToSelect  ==  1)
	{
		double  d_chosen_fom;
		int  i_found_index;

		d_chosen_fom  =  pc_best_species[0].dGetFOMLevel();

		i_found_index  =  -1;
		for  (long  li = 0; li < lPopSize; li++)
		{
			if  (pcThisPopBest  !=  NULL)
			{
				if  ((*pcThisPopBest)->dGetFOMLevel() < pcPopulation[li].dGetFOMLevel())  *pcThisPopBest = &(pcPopulation[li]);
			}//if  (pcThisPopBest  !=  NULL)

			if  (pcPopulation[li].dGetFOMLevel()  >  d_chosen_fom)
			{
				d_chosen_fom  =  pcPopulation[li].dGetFOMLevel();
				i_found_index  =  li;
			}//if  ( (d_new_specie_fom  =  pc_population[li].dGetFOMLevel())  >  d_chosen_fom)
		}//for  (long  li = 0; li < l_population_number; li++)

		if  (i_found_index  !=  -1)
		{
			pc_best_species[0].vCopy(&pcPopulation[i_found_index]);
		
		}//if  (i_found_index  !=  -1)

		return(true);
	
	}//if  (lNumberOfSpeciesToSelect  ==  1)


	d_worst_fom  =  pc_best_species[lNumberOfSpeciesToSelect - 1].dGetFOMLevel();


	long  lj,lk;
	bool  b_specie_already_on_the_list;

    for  (long  li = 0; li < lPopSize; li++)
	{
		if  (pcThisPopBest  !=  NULL)
			{
				if  ((*pcThisPopBest)->dGetFOMLevel() < pcPopulation[li].dGetFOMLevel()) * pcThisPopBest = &(pcPopulation[li]);
			}//if  (pcThisPopBest  !=  NULL)
		
		//when we find a specie that is better then the worst one
		if  ( (d_new_specie_fom  =  pcPopulation[li].dGetFOMLevel())  >  d_worst_fom)
		{
			//now we check wheather the same kind of specie is not already on the best species list
			b_specie_already_on_the_list  =  false;
			for  (lj = 0; 
					(lj < lNumberOfSpeciesToSelect)&&(b_specie_already_on_the_list  ==  false); 
				 lj++)
			{
				if  (pc_best_species[lj]  ==  &pcPopulation[li])
					b_specie_already_on_the_list  =  true;
			}//for
				

			//if the specie is not there yet we input it!
			if  (b_specie_already_on_the_list  ==  false)
			{

				//now we look for the best specie that is not worse then the new inputted one
				for  (
					lj = lNumberOfSpeciesToSelect - 1;
					(pc_best_species[lj].dGetFOMLevel()  <  d_new_specie_fom)&&(lj >= 0);
					lj--
					);
								

				lj++;//becase we are always one step too far

				//printf("li: %ld  lj:%ld\n",li,lj);

				//now we input the new one but before that we move all down by one position
				for  (lk = lNumberOfSpeciesToSelect - 2; lk >= lj; lk--)
					pc_best_species[lk + 1].vCopy(&pc_best_species[lk]);


				pc_best_species[lj].vCopy(&pcPopulation[li]);

				d_worst_fom  =  pc_best_species[lNumberOfSpeciesToSelect - 1].dGetFOMLevel();

			}//if  (b_specie_already_on_the_list  ==  false)

		
		}//if  (pc_population[li].dGetFOMLevel()  >  d_worst_fom)
	
	}//for  (long  li = 0; li < l_population_number; li++)


	return(true);

}//bool  CTrajectorySetsFinder::b_select_best_species(long  lNumberOfSpeciesToSelect)









/*
this method copies the best found species into the population table so the best found
species are not lost
*/
void  CTrajectorySetsFinder::v_input_best_species(long  lNumberOfSpecies)
{

	for  (long  li = 0; li < lNumberOfSpecies; li++)
	{

		if  (pc_population[li].dGetFOMLevel()  <  pc_best_species[li].dGetFOMLevel())
			pc_population[li].vCopy(&pc_best_species[li]);
	
	}//for  (long  li = 0; li < lNumberOfSpecies; li++)

}//bool  CTrajectorySetsFinder::b_input_best_species()










int   CTrajectorySetsFinder::iLoadNetTopology(CString  sFileName)
{
	CString  s_comment;

	return  (c_translator.iLoadTopologyFile(sFileName, &s_comment));

}//int   CTrajectorySetsFinder::iLoadNetTopology(CString  sFileName)








int   CTrajectorySetsFinder::iLoadVirtualWays(CString  sFileName,  bool  bTranslate)
{

	return(c_virtual_ways.iLoadVirtualWays(sFileName, &c_translator,  bTranslate));

}//int   CTrajectorySetsFinder::iLoadVirtualWays(CString  sFileName)













//-------------------------------------------------------------------------------------------
//--------------------------implementation of class CSingleTrajectorySet--------------------------


CSingleTrajectorySet::CSingleTrajectorySet()
{

	b_fom_lvl_actual  =  false;
	l_population_when_created  =  0;

	d_fom_level_penalized  =  0;
	d_fom_level_pure = 0;
	d_penalty_pure = 0;

	pl_start_finish_pairs  =  NULL;
	i_number_of_pairs  =  0;
	b_capacity_extending  =  true;


	pc_trajectories  =  NULL;
	pc_competetive_template_before_insert = NULL;

	pc_fitness_counter  =  NULL;

	pc_net_sim  =  new  CNETsimulatorSimplyfied();

	b_virgin_init  =  true;

	pv_population = NULL;

	pc_best_found  =  NULL;
	pc_infection_history  =  NULL;
	pc_tool = NULL;

	d_templ_fittness_before_insert  = 0;
	d_templ_fittness_before_crossing = 0;


	pc_best_solution_on_the_run = NULL;
	d_best_solution_on_the_run_fitness = 0;

	//d_ranking_objective_weight = 0;
}//CSingleTrajectorySet::CSingleTrajectorySet




CSingleTrajectorySet::~CSingleTrajectorySet()
{

	if  (pl_start_finish_pairs  !=  NULL)
		delete  []  pl_start_finish_pairs;
	
	
	if  (pc_net_sim  !=  NULL)  delete  pc_net_sim;
	
	
	if  (pc_trajectories  !=  NULL)
		delete  []  pc_trajectories;

	if  (pc_competetive_template_before_insert  !=  NULL)
		delete  []  pc_competetive_template_before_insert;

	


	if  (pv_population  !=  NULL)
	{
		for  (int  ii = 0; ii < (int) pv_population->size(); ii++)
			delete  pv_population->at(ii);
		delete  pv_population;
	}//if  (pv_population  !=  NULL)


	if  (pc_best_found  !=  NULL)  delete  pc_best_found;
	if  (pc_infection_history  !=  NULL)  delete  pc_infection_history;
	if  (pc_tool  !=  NULL)  delete  pc_tool;

	
}//CSingleTrajectorySet::CSingleTrajectorySet










bool  CSingleTrajectorySet::bInit
	(long *plStartFinishPairs, int  iNumberOfPairs,  CVirtualWayDatabase  *pcWaysDatabase, CNETsimulator  *pcNetSim, CFOMfunction  *pcFOMcounter,  long *plCapacities,  long  lPenalty)
{
	vSetNewFOM(pcFOMcounter);
	
	d_fom_level_penalized  =  0;
	d_fom_level_pure = 0;
	d_penalty_pure = 0;

	b_virgin_init  =  true;

	pc_virtual_ways  =  pcWaysDatabase;
	if  (pc_virtual_ways  ==  NULL)  return(false);



	if  (pl_start_finish_pairs  !=  NULL)
		delete []  pl_start_finish_pairs;

	i_number_of_pairs  =  0;


	
	pl_start_finish_pairs  =  new  long[iNumberOfPairs * 2];

	if  (pl_start_finish_pairs  ==  NULL)  return(false);

	i_number_of_pairs  =  iNumberOfPairs;



	for  (int  ii = 0; ii < i_number_of_pairs * 2; ii++)
		pl_start_finish_pairs[ii]  =  plStartFinishPairs[ii];
		

	

	//now we init the trajectories
	if  (pc_trajectories  !=  NULL)  delete  []  pc_trajectories;
	pc_trajectories = new CVirtualWay*[i_number_of_pairs];
	if  (pc_trajectories  ==  NULL)  return(false);


	for  (int  ii = 0; ii < i_number_of_pairs; ii++)
	{

		pc_trajectories[ii]  =  
			pc_virtual_ways->pcGetVirtualWay
								(
								pl_start_finish_pairs[ii*2],
								pl_start_finish_pairs[ii*2 + 1]
								);


		//we do NOT break the process HERE!!! because
		//it is an init procedure...
		//if  (pc_trajectories[ii]  ==  NULL)  return(false);


	}//for  (int ii = 0; ii < i_number_of_pairs; ii++)


	if  (pc_net_sim->iCopySimulator(pcNetSim)  !=  1)  return(false);

	pc_net_sim->iRemoveAllConnections();
	//if  (b_set_all_conns(plCapacities)  ==  false)  return(false);
	//we allow set all conns to return false, because it is ONLY the init
	b_set_all_conns(plCapacities);
	b_fom_lvl_actual  =  false;

	dCountFOM(pc_fitness_counter, plCapacities,  lPenalty);
	vSaveBestSolutionOnTheRun(plCapacities,  lPenalty);

	pc_tool = new CMessyIndividual(i_number_of_pairs);	



	return(true);
}//bool  CSingleTrajectorySet::bInit



void  CSingleTrajectorySet::vSaveBestSolutionOnTheRun(long *plCapacities,  long  lPenalty)
{
	if  (d_best_solution_on_the_run_fitness < dCountFOM(pc_fitness_counter, plCapacities, lPenalty))
	{
		if  (pc_best_solution_on_the_run  ==  NULL)  pc_best_solution_on_the_run  =  new CVirtualWay* [i_number_of_pairs];
		for  (int  ii = 0;  ii < i_number_of_pairs; ii++)
			pc_best_solution_on_the_run[ii]  =  pc_trajectories[ii];
		d_best_solution_on_the_run_fitness = dCountFOM(pc_fitness_counter, plCapacities, lPenalty);
	}//if  (d_best_solution_on_the_run_fitness < dCountFOM())
}//void  CSingleTrajectorySet::vSaveBestSolutionOnTheRun(long *plCapacities,  long  lPenalty)


void  CSingleTrajectorySet::vSaveBestSolutionOnTheRun(CTrajectorySetsFinder  *pcVGA)
{
	vSaveBestSolutionOnTheRun(pcVGA->pl_capacities, pcVGA->l_penalty);
}//void  CSingleTrajectorySet::vSaveBestSolutionOnTheRun()











bool  CSingleTrajectorySet::bMutate(long *plCapacities)
{
	b_fom_lvl_actual  =  false;

	//first we pick up the pair
	int  i_mutate_traj;

	
	i_mutate_traj  =  lRand(i_number_of_pairs);


	if  (TSF_PEACH == 1)
	{
		//we take off the mutated connection
		int  i_buf;
		long  *pl_buf;
		long  l_conn_set_result;
		
		i_buf  =  pc_trajectories[i_mutate_traj]->iGetWay(&pl_buf);
		l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_mutate_traj] * (-1) );
		
		if  (l_conn_set_result  <  1)
		{
			d_fom_level_penalized  =  0;
			d_fom_level_pure = 0;
			d_penalty_pure = 0;
			return(false);
		}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)

		

		pc_trajectories[i_mutate_traj]  =  
			pc_virtual_ways->pcGetVirtualWay
				(
				pl_start_finish_pairs[i_mutate_traj * 2],
				pl_start_finish_pairs[i_mutate_traj * 2 + 1]
				);

		if  (pc_trajectories[i_mutate_traj]  ==  NULL)  return(false);  

		
		//finaly we put back the new, mutated connection
		i_buf  =  pc_trajectories[i_mutate_traj]->iGetWay(&pl_buf);
		l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_mutate_traj]);

		if  (l_conn_set_result  <  1)
		{
			d_fom_level_penalized  =  0;
			d_fom_level_pure = 0;
			d_penalty_pure = 0;
			return(false);
		}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)
	}//if  (TSF_PEACH == 1)
	else
	{
		pc_trajectories[i_mutate_traj]  =  
			pc_virtual_ways->pcGetVirtualWay
				(
				pl_start_finish_pairs[i_mutate_traj * 2],
				pl_start_finish_pairs[i_mutate_traj * 2 + 1]
				);


		pc_net_sim->iRemoveAllConnections();

		if  (b_set_all_conns(plCapacities)  ==  false)  return(false);
	}//else  if  (TSF_PEACH == 1)



	
	return(true);

}//bool  CSingleTrajectorySet::bMutate()




void  CSingleTrajectorySet::vRandomize_LLDSI(CTrajectorySetsFinder  *pcVGA)
{
	CMessyPattern  *pc_pattern;

	pc_pattern  =  pcVGA->pc_get_random_pattern();

	if  (pc_pattern  ==  NULL)  return;

	int  i_gene_pos;
	for  (int  ii = 0; ii < pc_pattern->pvGetGenotype()->size(); ii++)
	{
		i_gene_pos = pc_pattern->pvGetGenotype()->at(ii)->i_gene_pos;

		pc_trajectories[i_gene_pos]  =  
			pc_virtual_ways->pcGetVirtualWay
				(
				pl_start_finish_pairs[i_gene_pos * 2],
				pl_start_finish_pairs[i_gene_pos * 2 + 1]
				);
	
	}//for  (int  ii = 0; ii < pc_pattern->pvGetGenotype()->size(); ii++)

	b_fom_lvl_actual = false;
}//void  CSingleTrajectorySet::vRandomize(CTrajectorySetsFinder  *pcVGA)



void  CSingleTrajectorySet::vRandomize(long *plCapacities, double  dProbInitMut)
{
	int  i_buf;
	long  *pl_buf, l_conn_set_result;

	bool  b_random;

	int  i_replaced_genes;

	i_replaced_genes = 0;
	for  (int  ii = 0; ii < i_number_of_pairs; ii++)
	{
		b_random = false;

		if  (dProbInitMut < 0)  
			b_random = true;
		else
		{
			if  (dRand()  <  dProbInitMut)  b_random = true;
		}//if  (dProbInitMut < 0)  

		if  (b_random == true)
		{
			
			pc_trajectories[ii]  =  
				pc_virtual_ways->pcGetVirtualWay
					(
					pl_start_finish_pairs[ii * 2],
					pl_start_finish_pairs[ii * 2 + 1]
					);

			i_replaced_genes++;
		}//if  (dRand()  <  dProbInitMut)	
	}//for  (int  ii = 0; ii < i_number_of_pairs; ii++)

	CString  s_buf;
	double  d_buf;
	d_buf = i_replaced_genes;
	d_buf = d_buf / i_number_of_pairs;
	s_buf.Format("%d/%d = %.2lf",  i_replaced_genes, i_number_of_pairs, d_buf);
	//::Tools::vShow(s_buf);

	b_fom_lvl_actual = false;
}//void  CSingleTrajectorySet::vRandomize(long *plCapacities, double  dProbInitMut)







bool  CSingleTrajectorySet::bMutateLLD(long *plCapacities)
{
	b_fom_lvl_actual  =  false;

	//first we pick up the pair
	int  i_mutate_traj;

	
	i_mutate_traj  =  lRand(i_number_of_pairs);



	//we take off the mutated connection
	int  i_buf;
	long  *pl_buf;
	long  l_conn_set_result;
	
	

	CVirtualWay  *pc_new_way;
	
	pc_virtual_ways->bGet2VirtualWaysWithLowLevelFOM
		(
		pc_net_sim,
		pl_start_finish_pairs[i_mutate_traj * 2],
		pl_start_finish_pairs[i_mutate_traj * 2 + 1],
		&pc_new_way
		);

	
	if  (pc_new_way  ==  NULL)
	{
		return(false);
	}//if  (pc_new_way  ==  NULL)
	else
	{
		if  (TSF_PEACH == 1)
		{
			i_buf  =  pc_trajectories[i_mutate_traj]->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_mutate_traj] * (-1) );
			
			if  (l_conn_set_result  <  1)
			{
				d_fom_level_penalized  =  0;
				d_fom_level_pure = 0;
				d_penalty_pure = 0;
				return(false);
			}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)

			pc_trajectories[i_mutate_traj]  =  pc_new_way;

			//finaly we put back the new, mutated connection
			i_buf  =  pc_new_way->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_mutate_traj]);
		
			if  (l_conn_set_result  <  1)
			{
				d_fom_level_penalized  =  0;
				d_fom_level_pure = 0;
				d_penalty_pure = 0;
				return(false);
			}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)
		}//if  (TSF_PEACH == 1)
		else
		{
			pc_trajectories[i_mutate_traj]  =  pc_new_way;

			pc_net_sim->iRemoveAllConnections();

			if  (b_set_all_conns(plCapacities)  ==  false)  return(false);
		}//else  if  (TSF_PEACH == 1)

		return(true);
	}//else  if  (pc_new_way  ==  NULL)

	return(false);

}//bool  CSingleTrajectorySet::bMutate()












bool   CSingleTrajectorySet::bCross
		(CSingleTrajectorySet *pcFather,  
		 CSingleTrajectorySet *pcChild1, CSingleTrajectorySet  *pcChild2,
		 double  dRandomCrossPossibility,  long *plCapacities)
{

	//first we must find the crossing point
	int  i_crossing_point;


	if  (dRand()  <  dRandomCrossPossibility)
	{
		//random ordered crossing

		for  (int  ii = 0; ii < i_number_of_pairs; ii++)
		{

			if  (dRand()  <  0.5)
			{
				pcChild1->pc_trajectories[ii]  =  pcFather->pc_trajectories[ii];
				pcChild2->pc_trajectories[ii]  =  pc_trajectories[ii];		
			}//if  (dRand()  <  0.5)
			else
			{
				pcChild1->pc_trajectories[ii]  =  pc_trajectories[ii];
				pcChild2->pc_trajectories[ii]  =  pcFather->pc_trajectories[ii];		
			}//else  if  (dRand()  <  0.5)

		}//for  (int  ii = 0; ii < i_crossing_point; ii++)
	
	}//if  (dRand()  <  dRandomCrossPossibility)
	else
	{
		//linearly ordered crossing

		i_crossing_point  =  lRand(i_number_of_pairs);

		
		int  ii, ij;
		for  (ii = 0; ii < i_crossing_point; ii++)
		{
			pcChild1->pc_trajectories[ii]  =  pc_trajectories[ii];
			pcChild2->pc_trajectories[ii]  =  pcFather->pc_trajectories[ii];
		}//for  (int  ii = 0; ii < i_crossing_point; ii++)


		for  (ij = ii + 1; ij < i_number_of_pairs; ij++)
		{
			pcChild1->pc_trajectories[ii]  =  pcFather->pc_trajectories[ii];
			pcChild2->pc_trajectories[ii]  =  pc_trajectories[ii];
		}//for  (int  ij = ii + 1; ij < i_crossing_point; ij++)
	
	}//else  if  (dRand()  <  dRandomCrossPossibility)

	pcChild1->b_fom_lvl_actual  =  false;
	pcChild2->b_fom_lvl_actual  =  false;

	pcChild1->pc_net_sim->iRemoveAllConnections();
	pcChild2->pc_net_sim->iRemoveAllConnections();

	if  (pcChild1->b_set_all_conns(plCapacities)  ==  false)  return(false);
	if  (pcChild2->b_set_all_conns(plCapacities)  ==  false)  return(false);


	return(true);

}//bool   CSingleTrajectorySet::bCross




void  CSingleTrajectorySet::vTakeRandomGenes(CSingleTrajectorySet *pcOther)
{
	for  (int  ii = 0; ii < i_number_of_pairs; ii++)
	{
		if  (dRand()  <  0.5)
			pc_trajectories[ii]  =  pcOther->pc_trajectories[ii];
	}//for  (int  ii = 0; ii < i_crossing_point; ii++)

	b_fom_lvl_actual  =  false;
	pc_net_sim->iRemoveAllConnections();
}//void  CSingleTrajectorySet::vTakeRandomGenes(CSingleTrajectorySet *pcOther)





bool   CSingleTrajectorySet::bMutateLowLevel(long *plCapacities)
{
	b_fom_lvl_actual  =  false;

	CVirtualWay  *pc_new_way;

	int  i_mutate_traj;

	i_mutate_traj  =  (int)  lRand(i_number_of_pairs);

	//we take off the mutated connection
	int  i_buf;
	long  *pl_buf;
	long  l_conn_set_result;
	
	
	if  (TSF_PEACH == 1)
	{
		int  i_test  =  pc_trajectories[i_mutate_traj]->iMutate(&pc_new_way, pc_virtual_ways);
		if  (i_test  ==  1)
		{
			i_buf  =  pc_trajectories[i_mutate_traj]->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_mutate_traj] * (-1) );
			
			if  (l_conn_set_result  <  1)
			{
				d_fom_level_penalized  =  0;
				d_fom_level_pure = 0;
				d_penalty_pure = 0;
				return(false);
			}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)

			pc_trajectories[i_mutate_traj]  =  pc_new_way;

			//finaly we put back the new, mutated connection
			i_buf  =  pc_trajectories[i_mutate_traj]->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_mutate_traj]);
		
			if  (l_conn_set_result  <  1)
			{
				d_fom_level_penalized  =  0;
				d_fom_level_pure = 0;
				d_penalty_pure = 0;
				return(false);
			}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)


			return(true);	
		}//if  (pc_actual_way->iMutate(pc_new_way, pc_virtual_ways)  ==  1)
		else
		{
			return(false);
		}//else

	}//if  (TSF_PEACH == 1)
	else
	{
		int  i_test  =  pc_trajectories[i_mutate_traj]->iMutate(&pc_new_way, pc_virtual_ways);
		if  (i_test  ==  1)
		{
			pc_trajectories[i_mutate_traj]  =  pc_new_way;

			pc_net_sim->iRemoveAllConnections();

			if  (b_set_all_conns(plCapacities)  ==  false)  return(false);

			return(true);	
		}//if  (pc_actual_way->iMutate(pc_new_way, pc_virtual_ways)  ==  1)
		else
		{
			return(false);
		}//else
	
	}//else  if  (TSF_PEACH == 1)

	

	return(false);

}//bool   CSingleTrajectorySet::bMutateLowLevel()







bool   CSingleTrajectorySet::bMutateLowLevelLLD(long *plCapacities)
{

	b_fom_lvl_actual  =  false;
	
	CVirtualWay  *pc_actual_way,  *pc_new_way;
	int  i_mutate_traj;

	i_mutate_traj  =  (int)  lRand(i_number_of_pairs);
	pc_actual_way  =  pc_trajectories[i_mutate_traj];


	//we take off the mutated connection
	int  i_buf;
	long  *pl_buf;
	long  l_conn_set_result;
	
	
	if  (TSF_PEACH == 1)
	{

		if  (pc_actual_way->iMutate(&pc_new_way, pc_virtual_ways, pc_net_sim)  ==  1)
		{
			i_buf  =  pc_trajectories[i_mutate_traj]->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_mutate_traj] * (-1) );
			
			if  (l_conn_set_result  <  1)
			{
				d_fom_level_penalized  =  0;
				d_fom_level_pure = 0;
				d_penalty_pure = 0;
				return(false);
			}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)


			pc_trajectories[i_mutate_traj]  =  pc_new_way;


			//finaly we put back the new, mutated connection
			i_buf  =  pc_new_way->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_mutate_traj]);
		
			if  (l_conn_set_result  <  1)
			{
				d_fom_level_penalized  =  0;
				d_fom_level_pure = 0;
				d_penalty_pure = 0;
				return(false);
			}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)


			

			return(true);
		}//if  (pc_actual_way->iMutate(pc_new_way, pc_virtual_ways)  ==  1)
		else
		{
			return(false);
		}//else  if  (pc_actual_way->iMutate(pc_new_way, pc_virtual_ways)  ==  1)	

	}//if  (TSF_PEACH == 1)
	else
	{
		if  (pc_actual_way->iMutate(&pc_new_way, pc_virtual_ways, pc_net_sim)  ==  1)
		{
			pc_trajectories[i_mutate_traj]  =  pc_new_way;

			pc_net_sim->iRemoveAllConnections();

			if  (b_set_all_conns(plCapacities)  ==  false)  return(false);			

			return(true);
		}//if  (pc_actual_way->iMutate(pc_new_way, pc_virtual_ways)  ==  1)
		else
		{
			return(false);
		}//else  if  (pc_actual_way->iMutate(pc_new_way, pc_virtual_ways)  ==  1)	
	}//else  if  (TSF_PEACH == 1)
	
	
	return(false);
}//bool   CSingleTrajectorySet::bMutateLowLevel()







bool   CSingleTrajectorySet::bCrossLowLevel(CSingleTrajectorySet  *pcOther, long *plCapacities)
{

	CVirtualWay  *pc_mother_v_way,  *pc_father_v_way;
	CVirtualWay  *pc_child1,  *pc_child2;


	//first we pick up which part of species is to be crossed
	int  i_crossed_pair_number;

	i_crossed_pair_number  =  (int)  lRand(i_number_of_pairs);


	pc_mother_v_way  =  pc_trajectories[i_crossed_pair_number];
	pc_father_v_way  =  pcOther->pc_trajectories[i_crossed_pair_number];

	pc_mother_v_way->iCross(pc_father_v_way, &pc_child1,  &pc_child2, pc_virtual_ways);

	if  (pc_child1  !=  NULL)  
	{
		//we take off the mutated connection
		int  i_buf;
		long  *pl_buf;
		long  l_conn_set_result;
		
		i_buf  =  pc_trajectories[i_crossed_pair_number]->iGetWay(&pl_buf);
		l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_crossed_pair_number] * (-1) );
		
		if  (l_conn_set_result  <  1)
		{
			d_fom_level_penalized  =  0;
			d_fom_level_pure = 0;
			d_penalty_pure = 0;
			return(false);
		}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)

		pc_trajectories[i_crossed_pair_number]  =  pc_child1;
		b_fom_lvl_actual  =  false;


		//finaly we put back the new, mutated connection
		i_buf  =  pc_trajectories[i_crossed_pair_number]->iGetWay(&pl_buf);
		l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_crossed_pair_number]);

		if  (l_conn_set_result  <  1)
		{
			d_fom_level_penalized  =  0;
			d_fom_level_pure = 0;
			d_penalty_pure = 0;
			return(false);
		}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)

	}//if  (pc_child1  !=  NULL)  

	if  (pc_child2  !=  NULL)  
	{
		//we take off the mutated connection
		int  i_buf;
		long  *pl_buf;
		long  l_conn_set_result;
		
		i_buf  =  pcOther->pc_trajectories[i_crossed_pair_number]->iGetWay(&pl_buf);
		l_conn_set_result  =  pcOther->pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_crossed_pair_number] * (-1) );
		
		if  (l_conn_set_result  <  1)
		{
			d_fom_level_penalized  =  0;
			d_fom_level_pure = 0;
			d_penalty_pure = 0;
			return(false);
		}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)

		pcOther->pc_trajectories[i_crossed_pair_number]  =  pc_child2;
		pcOther->b_fom_lvl_actual  =  false;


		//finaly we put back the new, mutated connection
		i_buf  =  pcOther->pc_trajectories[i_crossed_pair_number]->iGetWay(&pl_buf);
		l_conn_set_result  =  pcOther->pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_crossed_pair_number]);

		if  (l_conn_set_result  <  1)
		{
			d_fom_level_penalized  =  0;
			d_fom_level_pure = 0;
			d_penalty_pure = 0;
			return(false);
		}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)
		
	}//if  (pc_child2  !=  NULL)  


	if  ( (pc_child1  !=  NULL)&&(pc_child2  !=  NULL) )
		return(true);
	else
		return(false);

	return(true);
}//bool   CSingleTrajectorySet::bCrossLowLevel(CSingleTrajectorySet  *pcOther)










bool   CSingleTrajectorySet::bCrossLowLevelLLD
	(
	long *plCapacities
	)
{
	CVirtualWay  *pc_mother_v_way,  *pc_father_v_way;
	CVirtualWay  *pc_child1,  *pc_child2;


	//first we pick up which part of species is to be crossed
	int  i_crossed_pair_number;

	i_crossed_pair_number  =  (int)  lRand(i_number_of_pairs);

	//we take off the mutated connection
	int  i_buf;
	long  *pl_buf;
	long  l_conn_set_result;
	
	i_buf  =  pc_trajectories[i_crossed_pair_number]->iGetWay(&pl_buf);
	l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_crossed_pair_number] * (-1) );
	
	if  (l_conn_set_result  <  1)
	{
		d_fom_level_penalized  =  0;
		d_fom_level_pure = 0;
		d_penalty_pure = 0;
		return(false);
	}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)

	//now we find mother and father
	pc_virtual_ways->bGet2VirtualWaysWithLowLevelFOM
		(
		pc_net_sim,
		pl_start_finish_pairs[i_crossed_pair_number * 2],
		pl_start_finish_pairs[i_crossed_pair_number * 2 + 1],
		&pc_mother_v_way,
		&pc_father_v_way
		);



	//for crossing we use fathers enviroment of the net
	if  (
		pc_mother_v_way->iCross
			(
			pc_father_v_way, &pc_child1,  &pc_child2, 
			pc_virtual_ways, pc_net_sim
			)
		==
		1
		)
	{
		double  d_child1_fom, d_child2_fom;
		d_child1_fom  =  pc_child1->dCountFOM(pc_net_sim);
		d_child2_fom  =  pc_child2->dCountFOM(pc_net_sim);

		if  (dRand()  <  d_child1_fom / (d_child1_fom + d_child2_fom) )
		{
			pc_trajectories[i_crossed_pair_number]  =  pc_child1;
			b_fom_lvl_actual  =  false;

			//finaly we put back the new, mutated connection
			i_buf  =  pc_child1->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_crossed_pair_number]);
					
			if  (l_conn_set_result  <  1)
			{
				d_fom_level_penalized  =  0;
				d_fom_level_pure = 0;
				d_penalty_pure = 0;
				return(false);
			}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)

			return(true);
		}//if  (dRand()  <  d_child1_fom / (d_child1_fom + d_child2_fom) )
		else
		{
			pc_trajectories[i_crossed_pair_number]  =  pc_child2;
			b_fom_lvl_actual  =  false;

			//finaly we put back the new, mutated connection
			i_buf  =  pc_child2->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_crossed_pair_number]);

		
			if  (l_conn_set_result  <  1)
			{
				d_fom_level_penalized  =  0;
				d_fom_level_pure = 0;
				d_penalty_pure = 0;
				return(false);
			}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)

			return(true);
		}//else  if  (dRand()  <  d_child1_fom / (d_child1_fom + d_child2_fom) )
		
	}//if


	return(false);
}//bool   CSingleTrajectorySet::bCrossLowLevel(CSingleTrajectorySet  *pcOther)








bool  CSingleTrajectorySet::b_set_all_conns(long *plCapacities)
{
	long  *pl_buf;
	int   i_buf;
	long  l_conn_set_result;

	//first we set up all connections
	b_capacity_extending  =  false;
	for  (int ii = 0; ii < i_number_of_pairs; ii++)
	{
		if  (pc_trajectories[ii]  !=  NULL)
		{
			i_buf  =  pc_trajectories[ii]->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii]);
					
			if  (l_conn_set_result  <  1)
			{
				return(false);
			}//if  (pcTranslator->lSetUpConnetcion(pl_buf, i_buf, plCapacities[ii])  <  1)

			if  (l_conn_set_result  ==  2)  b_capacity_extending  =  true;		
		}//if  (pc_trajectories[ii]  !=  NULL)
		else
			return(false);
		
	}//for  (int ii = 0; ii < i_number_of_pairs; ii++)

	
	return(true);
}//bool  CSingleTrajectorySet::b_set_all_conns(long *plCapacities,  long  lPenalty)




double  CSingleTrajectorySet::dGetFOMLevel()
{
	if  (b_fom_lvl_actual) 
		return(d_fom_level_penalized); 
	else
	{
		CError  c_err;
		c_err.vPutError("FOM unactual");
		c_err.vShowWindow();
		return(-1);
	}//else  if  (b_fom_lvl_actual) 
};//double  CSingleTrajectorySet::dGetFOMLevel()


double  CSingleTrajectorySet::dGetRankingWeighted(vector<double> *pvObjective, vector<double> *pvPenalty, double dWeight, double  *pdObjective, double  *pdPenalty, CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty)
{
	dCountFOM(pcFOMcounter, plCapacities,  lPenalty);

	double d_ranking_weighted;


	pc_tool->d_fitness_pure = this->d_fom_level_pure;
	pc_tool->d_penalty_pure = this->d_penalty_pure;
	d_ranking_weighted = pc_tool->dGetRankingWeighted(pvObjective, pvPenalty, dWeight, pdObjective, pdPenalty);
	

	return(d_ranking_weighted);
}//double  CSingleTrajectorySet::dGetRankingWeighted(vector<double> *pvObjective, vector<double> *pvPenalty, double dWeight, CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty)




double  CSingleTrajectorySet::dCountFOM(CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty)
{
	if  (b_fom_lvl_actual  ==  true)  return(d_fom_level_penalized);

	//now we ask the model about the fom value
	pc_net_sim->iRemoveAllConnections();


	
	b_set_all_conns(plCapacities);	//


	
	d_fom_level_penalized  =  pcFOMcounter->dCountFOM(pc_net_sim,  lPenalty,  &b_capacity_extending, &d_fom_level_pure, &d_penalty_pure);
	//d_fom_level_pure = d_fom_level_penalized - d_penalty_pure;
	

	b_fom_lvl_actual  =  true;
	return(d_fom_level_penalized);
}//double  CSingleTrajectorySet::dCountFOM(CTopologyTranslator  *pcTranslator)












void  CSingleTrajectorySet::vCopy(CSingleTrajectorySet *pcOther)
{

	l_population_when_created  =  pcOther->l_population_when_created;
	
	i_number_of_pairs  =  pcOther->i_number_of_pairs;

	d_fom_level_penalized = pcOther->d_fom_level_penalized;
	d_fom_level_pure = pcOther->d_fom_level_pure;
	d_penalty_pure = pcOther->d_penalty_pure;
	

	
	if  (pc_trajectories  !=  NULL)  delete  []  pc_trajectories;

	if  (pl_start_finish_pairs  !=  NULL)  delete  []  pl_start_finish_pairs;

	


	pc_trajectories = new CVirtualWay*[i_number_of_pairs];
	pl_start_finish_pairs  =  new  long[i_number_of_pairs * 2];
	

	for  (int ii = 0; ii < i_number_of_pairs * 2; ii++)
		pl_start_finish_pairs[ii]  =  pcOther->pl_start_finish_pairs[ii];

	
	for  (int  ii = 0; ii < i_number_of_pairs; ii++)
		pc_trajectories[ii]  =  pcOther->pc_trajectories[ii];


	pc_virtual_ways  =  pcOther->pc_virtual_ways;
	pc_net_sim->iCopySimulator(pcOther->pc_net_sim);
	b_fom_lvl_actual  =  pcOther->b_fom_lvl_actual;

	vSetNewFOM(pcOther->pc_fitness_counter);
	
	b_capacity_extending  =  pcOther->b_capacity_extending;

	
}//void  CSingleTrajectorySet::vCopy(CSingleTrajectorySet *pcOther)










CSingleTrajectorySet&  CSingleTrajectorySet::operator=(CSingleTrajectorySet &pcOther)
{


	if  (&pcOther  ==  this)  return(*this);
	
	i_number_of_pairs  =  pcOther.i_number_of_pairs;

	
	if  (pc_trajectories  !=  NULL)  delete  []  pc_trajectories;

	if  (pl_start_finish_pairs  !=  NULL)  delete  []  pl_start_finish_pairs;


	pc_trajectories = new CVirtualWay*[i_number_of_pairs];
	pl_start_finish_pairs  =  new  long[i_number_of_pairs * 2];
	

	for  (int ii = 0; ii < i_number_of_pairs * 2; ii++)
		pl_start_finish_pairs[ii]  =  pcOther.pl_start_finish_pairs[ii];

	
	for  (int  ii = 0; ii < i_number_of_pairs; ii++)
		pc_trajectories[ii]  =  pcOther.pc_trajectories[ii];


	pc_virtual_ways  =  pcOther.pc_virtual_ways;

	b_capacity_extending  =  pcOther.b_capacity_extending; 


	
	return(*this);

}//void  CSingleTrajectorySet::operator =









bool  CSingleTrajectorySet::operator ==(CSingleTrajectorySet *pcOther)
{


	if  (i_number_of_pairs  !=  pcOther->i_number_of_pairs)  return(false);

	

	if  (d_fom_level_penalized  !=  pcOther->d_fom_level_penalized)  return(false);
	if  (d_fom_level_pure  !=  pcOther->d_fom_level_pure)  return(false);
	if  (d_penalty_pure  !=  pcOther->d_penalty_pure)  return(false);

	
	
	for  (int ii = 0; ii < i_number_of_pairs * 2; ii++)
		if  (pl_start_finish_pairs[ii]  !=  pcOther->pl_start_finish_pairs[ii])  return(false);

	
	for  (int  ii = 0; ii < i_number_of_pairs; ii++)
		if  (pc_trajectories[ii]  !=  pcOther->pc_trajectories[ii])  return(false);


	if  (pc_virtual_ways  !=  pcOther->pc_virtual_ways)  return(false);

	if  (b_capacity_extending  !=  pcOther->b_capacity_extending)  return(false);

	return(true);

}//bool  CSingleTrajectorySet::operator ==(CSingleTrajectorySet &pcOther)






void  CSingleTrajectorySet::vSetInfectionHistory(CMessyIndividual  *pcInfectionHistory)
{
	if  (pcInfectionHistory  !=  NULL)
	{
		if  (pc_infection_history  ==  NULL)
		{
			pc_infection_history  =  new  CMessyIndividual(i_number_of_pairs);
			*pc_infection_history  =  *pcInfectionHistory;
		}//if  (pc_best_found  ==  NULL)
		else
		{
			*pc_infection_history  =  *pcInfectionHistory;
		}//else  if  (pc_best_found  ==  NULL)
	}//if  (pcInfectionHistory  !=  NULL)
	else
	{
		if  (pc_infection_history  !=  NULL)
		{
			delete  pc_infection_history;
			pc_infection_history  =  NULL;		
		}//if  (pc_infection_history  !=  NULL)
	}//else  if  (pcInfectionHistory  !=  NULL)
}//CError  CSingleTrajectorySet::eSetInfectionHistory(CMessyIndividual  *pcInfectionHistory)





void  CSingleTrajectorySet::vGetPathStats(double  *pdAvr, int  *piMin, int  *piMax)
{
	double  d_summary_len;
	int  i_min_len, i_max_len;
	int  i_traj_len;

	long  *pl_buf; //it must be given to CVirtualWay::iGetWay function

	d_summary_len = 0;
	for  (int  ii = 0; ii < i_number_of_pairs; ii++)
	{
		i_traj_len  =  pc_trajectories[ii]->iGetWay(&pl_buf);
		i_traj_len  =  (i_traj_len - 1) / 2;

		d_summary_len += i_traj_len;

		if  (ii == 0)
		{
			i_min_len = i_traj_len;
			i_max_len = i_traj_len;
		}//if  (ii == 0)

		if  (i_min_len > i_traj_len)  i_min_len = i_traj_len;
		if  (i_max_len < i_traj_len)  i_max_len = i_traj_len;	
	}//for  (long li = 0; li < i_number_of_pairs; li++)

	d_summary_len = d_summary_len / i_number_of_pairs;

	if  (pdAvr  !=  NULL)  *pdAvr = d_summary_len;
	if  (piMin  !=  NULL)  *piMin = i_min_len;
	if  (piMax  !=  NULL)  *piMax = i_max_len;

}//void  CSingleTrajectorySet::vGetPathStats(double  *pdAvr, int  *piMin, int  *piMax)



CString  CSingleTrajectorySet::sReportPathLens(int  iMaxPathLen)
{
	CString  s_result;
	CString  s_buf;


	int  i_traj_len;
	long  *pl_buf; //it must be given to CVirtualWay::iGetWay function

	s_result = "";
	int  i_counter;
	for  (int  i_path_len = 1; i_path_len <= iMaxPathLen; i_path_len++)
	{
		i_counter = 0;
		for  (long li = 0; li < i_number_of_pairs; li++)
		{
			i_traj_len  =  pc_trajectories[li]->iGetWay(&pl_buf);
			i_traj_len  =  (i_traj_len - 1) / 2;

			if  (i_path_len  ==  i_traj_len)  i_counter++;

			if  (
				(i_path_len  ==  iMaxPathLen)&&
				(i_path_len  <  i_traj_len)
				)
				i_counter++;
			
		}//for  (long li = 0; li < i_number_of_pairs; li++)

		s_buf.Format(" %d \t", i_counter);
		s_result += s_buf;
	}//for  (int  i_path_len = iMaxPathLen; i_path_len > 0; i_path_len--)


	return(s_result);
}//void  CSingleTrajectorySet::vReportPathLens(CString  *psPathLens, int  iMaxPathLen)



void  CSingleTrajectorySet::vReport(FILE  *pfReportFile,  bool  bFullReport,  long *plCapacities, long  lPenalty)
{
	pc_net_sim->iRemoveAllConnections();
	b_set_all_conns(plCapacities);
	double  d_test  =  d_fom_level_penalized;
	if  (b_fom_lvl_actual  ==  false)  d_test  =  dCountFOM(pc_fitness_counter,  plCapacities,  lPenalty);


	b_fom_lvl_actual  =  false;
	dCountFOM(pc_fitness_counter,  plCapacities,  lPenalty);
	//fprintf(pfReportFile,"Poziom przystosowania osobnika:%.10lf (%.10lf)\n",d_fom_level, (1/ d_fom_level) - 1);
	fprintf(pfReportFile,"Fitness:%.16lf (%.16lf) \n",d_fom_level_penalized, d_test);
	fprintf(pfReportFile,"Optimized function value:%.16lf (%.16lf)\n", ((double)1.0)/d_fom_level_penalized - 1, ((double)1.0)/d_test - 1);
	

	fprintf(pfReportFile,"Created in iteration:%ld\n", l_population_when_created);
	fprintf(pfReportFile,"Link capacity constraint broken:");
	if  (b_capacity_extending  ==  false)
		fprintf(pfReportFile," NO\n");
	else
		fprintf(pfReportFile," yes\n");

	//before listing all trajectories we make a statistics of them
	long  *pl_traj_lengths;

	pl_traj_lengths  =  new  long[i_number_of_pairs];
	long  *pl_buf; //it must be given to CVirtualWay::iGetWay function


	if  (pl_traj_lengths  !=  NULL)
	{

		double  d_summary_length = 0;
		long   l_longest_traj = 0;


		long  li;
		for  (li = 0; li < i_number_of_pairs; li++)
		{
			pl_traj_lengths[li]  =  pc_trajectories[li]->iGetWay(&pl_buf);
			pl_traj_lengths[li]  =  (pl_traj_lengths[li] - 1) / 2;

			if  (pl_traj_lengths[li]  >  l_longest_traj)  l_longest_traj  =  pl_traj_lengths[li];

			d_summary_length +=  pl_traj_lengths[li];
		
		}//for  (long li = 0; li < i_number_of_pairs; li++)


		fprintf(pfReportFile,"Average trajectory length:%lf\n",d_summary_length / i_number_of_pairs);

		//now we create statistics for trajectories lengths
		fprintf(pfReportFile, "\nTrajectory number by length:\n");

		long  lk;
		long  l_counter;
		for  (li = l_longest_traj; li > 0; li--)
		{

			l_counter  =  0;
			for  (lk = 0; lk < i_number_of_pairs; lk++)
			{
				if  (pl_traj_lengths[lk]  ==  li)  l_counter++;
			}//for  (lk = 0; lk < i_number_of_pairs; lk++)

			fprintf(pfReportFile, "Number of trajectories of length %ld: %ld\n", li, l_counter);

		}//for  (li = l_longest_traj; li > 0; li--)


	
		delete  [] pl_traj_lengths;
	}//if  (pl_traj_lengths  !=  NULL)



	
	pc_net_sim->vPresentNetwork(pfReportFile, true);
	


	if  (bFullReport  ==  true)
	{
		for  (int ii = 0; ii < i_number_of_pairs; ii++)
		{

			fprintf(pfReportFile,"Trajectory from node %ld to node %ld:\n", 
				pl_start_finish_pairs[ii*2], pl_start_finish_pairs[ii*2+1]);
			

			pc_trajectories[ii]->vCreateReportFile(pfReportFile);


			fprintf(pfReportFile,"\n\n\n");
		
		}//for  (int ii = 0; ii < i_number_of_pairs; ii++)
	}//if  (bFullReport  ==  true)

}//void  CSingleTrajectorySet::vReport(FILE  *pfReportFile)




long  CSingleTrajectorySet::l_get_start_node(CString  sLine)
{
	return(l_get_node(sLine, 0));
}//long  CSingleTrajectorySet::l_get_start_node(CString  sLine)

long  CSingleTrajectorySet::l_get_end_node(CString  sLine)
{
	return(l_get_node(sLine, l_get_node_num(sLine) - 1));
}//long  CSingleTrajectorySet::l_get_end_node(CString  sLine)

long  CSingleTrajectorySet::l_get_node_num(CString  sLine)
{
	long  l_node_num;

	int  ii;
	for  (ii = 0; 0 <= l_get_node(sLine, ii) ;ii++);
	l_node_num  =  ii; //dont have to add 1 because it is already added (ii++)

	return(l_node_num);
}//long  CSingleTrajectorySet::l_get_node_num(CString  sLine)

/*
0 or more - node id
-1 - node not found
*/
long  CSingleTrajectorySet::l_get_node(CString  sLine, int iNodeIndex)
{
	CString  s_buf;
	char  c_buf;
	bool  b_number;
	int  i_number_no;

	long  l_result;

	s_buf  =  "";
	b_number  =  false;
	i_number_no  =  -1;
	int  i_line_len  =  sLine.GetLength();
	for  (int  ii = 0; ii < i_line_len; ii++)
	{
		c_buf  =  (char)  sLine.GetAt(ii);

		if  (
			(c_buf  ==  '0')||(c_buf  ==  '1')||(c_buf  ==  '2')||
			(c_buf  ==  '3')||(c_buf  ==  '4')||(c_buf  ==  '5')||
			(c_buf  ==  '6')||(c_buf  ==  '7')||(c_buf  ==  '8')||
			(c_buf  ==  '9')
			)
		{
			if  (b_number  ==  false)  
			{
				b_number  =  true;
				i_number_no++;
			}//if  (b_number  ==  false)  
			s_buf  +=  c_buf;
		}//if  (
		else
		{
			if  (b_number  ==  true)  
			{
				b_number  =  false;

				if  (i_number_no  ==  iNodeIndex)
				{
					l_result  =  atoi(  (LPCSTR)  s_buf);
					return(l_result);				
				}//if  (i_number_no  ==  iNodeIndex)
			}//if  (b_number  ==  false)
			
			s_buf  =  "";
		}//else  if  (
	
	}//for  (int  ii = 0; ii < sLine.GetLength(); ii++)

	if  (b_number  ==  true)  
	{
		if  (i_number_no  ==  iNodeIndex)
		{
			l_result  =  atoi(  (LPCSTR)  s_buf);
			return(l_result);				
		}//if  (i_number_no  ==  iNodeIndex)
	}//if  (b_number  ==  false)*/

	return(-1);
}//long  CSingleTrajectorySet::l_get_node(CString  sLine, int iNodeNum)






/*
returned values:
1  -  ok
0  -  memory allocation problems
-1 -  unexpected end of file
-2 -  wrong number of trajectories
-3 -  wrong trajectory number
-4 -  proper link id to fill up nodes spaces not found
-5 -  error while insterting virtual way
*/
int   CSingleTrajectorySet::iLoadFromFulFile(CTopologyTranslator  *pcTranslator, FILE  *pfSource,  long  *plCapacities)
{
	
	char  c_buf;
	CString  s_buf, s_number;

	CString  s_start_node_marker = "Trajektoria z wezla ";
	CString  s_end_node_marker = "do wezla ";
	int  i_start_node,  i_end_node;
	int  i_buf;

	for  (long  li = 0; li < i_number_of_pairs; li++)
	{
		//single trajectory inputation

		s_buf  = "";
		while 
			(
			(s_buf.Find(s_start_node_marker) < 0)
			&&
			(feof(pfSource)  ==  0)
			)
		{
			s_buf  =  Tools::sReadLine(pfSource, &s_buf);
		}//while
		//::MessageBox(NULL, s_buf, s_buf, MB_OK);

		s_number = Tools::sExtractNumberAtStart(s_buf, s_buf.Find(s_start_node_marker) + s_start_node_marker.GetLength());
		i_start_node = atoi(s_number);
		//::MessageBox(NULL, s_number, s_number, MB_OK);
		s_number = Tools::sExtractNumberAtStart(s_buf, s_buf.Find(s_end_node_marker) + s_end_node_marker.GetLength());
		i_end_node = atoi(s_number);
		//::MessageBox(NULL, s_number, s_number, MB_OK);


		

		s_buf  =  Tools::sReadLine(pfSource, &s_buf);
		//::MessageBox(NULL, s_buf, s_buf, MB_OK);
		//first count number of numbers
		int  i_length = 0;
		s_number = 'a';
		int  i_current_offset = 0;
		while (s_number  !=  "")
		{
			s_number = Tools::sExtractNumberAtStart(s_buf, i_current_offset);
			i_current_offset += s_number.GetLength() + 1;

			i_length++;
			
			//::MessageBox(NULL, s_number, s_number, MB_OK);		
		}//while (s_number  !=  "")
		i_length = i_length - 2;//the last counted number is not a number and the first number is a number of numbers

		long  *pl_new_way;
		pl_new_way  =  new  long[i_length];

		//second input ids into trajectory
		i_current_offset = 0;
		int  i_current_number = 0;
		s_number = 'a';
		while (s_number  !=  "")
		{
			s_number = Tools::sExtractNumberAtStart(s_buf, i_current_offset);
			i_current_offset += s_number.GetLength() + 1;

			if  (i_current_number > 0) pl_new_way[i_current_number - 1] = atoi(s_number);
			i_current_number++;
			
			//::MessageBox(NULL, s_number, s_number, MB_OK);		
		}//while (s_number  !=  "")

		

		//now we create the proper virtual way and try to insert it into the virtual way database
		CVirtualWay  *pc_new_vw, *pc_vw_buf;
		
		pc_new_vw  =  new  CVirtualWay;
		if  (pc_new_vw  ==  NULL)  
		{
			delete  []  pl_new_way;
			return(0);
		}//if  (pc_new_vw  ==  NULL)

		if  (pc_new_vw->bSetWay(pl_new_way, i_length)  ==  false)
		{
			delete  []  pl_new_way;
			delete  pc_new_vw;
			return(0);
		}//if  (pc_new_vw->bSetWay(pl_new_way, l_traj_len * 2 - 1)  ==  false)


		
		int  i_vw_input_res;	
		i_vw_input_res  =  pc_virtual_ways->iInputNewVirtWay
							(
							pc_new_vw,  pl_new_way[0],  pl_new_way[i_length - 1],
							&pc_vw_buf, true
							);

		delete  []  pl_new_way;//we delete it because it's unnecessary after virtual way object initialization


		//virtual way inserted as new we just put the virtual way address(id) into trajectories table of the specie
		if  (i_vw_input_res  ==  1)
		{
			pc_trajectories[li]  =  pc_new_vw;
		}//if  (i_vw_input_res  ==  1)

		
		//virtual way not inserted because it already exists
		if  (i_vw_input_res  ==  2)
		{
			pc_trajectories[li]  =  pc_vw_buf;
			delete  pc_new_vw;		
		}//if  (i_vw_input_res  ==  2)


		//error occured
		if  (i_vw_input_res  <=  0)
		{
			delete  pc_new_vw;
			return(-5);		
		}//if  (i_vw_input_res  <=  0)*/



	}//for  (long  li = 0; li < i_number_of_pairs; li++)

	
	pc_net_sim->iRemoveAllConnections();
	if  (b_set_all_conns(plCapacities)  ==  false)  return(0);

	b_fom_lvl_actual  =  false;
	return(1);

}//int   CSingleTrajectorySet::iLoadFromFulFile(FILE  *pfSource,  CTopologyTranslator  *pcTranslator,  bool  bTranslate)



/*
returned values:
1  -  ok
0  -  memory allocation problems
-1 -  unexpected end of file
-2 -  wrong number of trajectories
-3 -  wrong trajectory number
-4 -  proper link id to fill up nodes spaces not found
-5 -  error while insterting virtual way
*/
int   CSingleTrajectorySet::iLoadFromIniFile(CTopologyTranslator  *pcTranslator, FILE  *pfSource,  long  *plCapacities,  bool  bTranslate)
{
	long  l_buf;


	if  (feof(pfSource)  ==  0)
		fscanf(pfSource,"%ld", &l_buf);
	else
		return(-1);//unexpected end of file
	


	if  (i_number_of_pairs  !=  l_buf)  return(-2);//wrong number of trajectories



	CString  s_line;
	char  c_buf;
	for  (long  li = 0; li < i_number_of_pairs; li++)
	{
		//single trajectory inputation

		//trajectory number
		if  (feof(pfSource)  ==  0)
			fscanf(pfSource,"%ld", &l_buf);
		else
			return(-1);//unexpected end of file

		if  (l_buf != li + 1)  return(-3);//wrong trajectory number

		
		fscanf(pfSource, "%c", &c_buf);//scan enter after trajectory number
		c_buf  =  'a';//ini value different from '\n'
		s_line  =  "";
		while  ( (!feof(pfSource))&&(c_buf  !=  '\n') )  
		{
			fscanf(pfSource, "%c", &c_buf);
			s_line  +=  c_buf;
		}//while  ( (!feof(pf_source))&&(c_buf  !=  '\n') )  
		if  (c_buf  !=  '\n')  return(0);



		//start&finish node numbers
		l_buf  =  l_get_start_node(s_line);
		l_buf  =  pcTranslator->lTranslateNodeNum(l_buf);

		if  (bTranslate  ==  true)
		{
			//if we are given untranslated node numbers from the file we don't have to do any translation
			//when we compare them with "pl_start_finish_pairs" because these pairs were
			//directly read in and are untranslated by definition
			if  (
				l_buf  !=  pl_start_finish_pairs[li * 2]
				)  
				return(-4);//wrong start/finish node number


			l_buf  =  l_get_end_node(s_line);
			l_buf  =  pcTranslator->lTranslateNodeNum(l_buf);

			if  (
				l_buf  !=  pl_start_finish_pairs[li * 2 + 1]
				)  
				return(-4);//wrong start/finish node number
		}//if  (bTranslate  ==  true)
		else
		{
			//if we are given translated node numbers from the file we do not have to translate
			//"pl_start_finish_pairs" because these pairs were
			//directly read in and translated right after it

			if  (
				l_buf  !=  pl_start_finish_pairs[li * 2]
				)  
				return(-4);//wrong start/finish node number


			l_buf  =  l_get_end_node(s_line);

			if  (
				l_buf  !=  pl_start_finish_pairs[li * 2 + 1]
				)  
				return(-4);//wrong start/finish node number
		
		}//else  if  (bTranslate  ==  true)



		//now reading trajectory length
		l_buf  =  l_get_node_num(s_line);


		//now we read in trajectory nodes
		long  l_traj_len  =  l_buf;
		long  *pl_new_way;

		pl_new_way  =  new  long[l_traj_len * 2 - 1];//the length is doubled and decreased because we have to put links ids there
		if  (pl_new_way  ==  NULL)  return(0);

		long lj;
		for  (lj = 0; lj < l_traj_len; lj++)
		{

			//inputting trajectory nodes...
			l_buf  =  l_get_node(s_line,  lj);

			pl_new_way[lj * 2]  =  pcTranslator->lTranslateNodeNum(l_buf);
		
		}//for  (long  lj = 0; lj < l_traj_len; lj++)


		//now we fill spaces between nodes ids with propoer links ids
		long  l_link_id_buf;
		for  (lj = 0; lj < l_traj_len - 1; lj++)
		{
			
			l_link_id_buf  =  
				pcTranslator->lFindLinkIdForNodes(pl_new_way[lj * 2],pl_new_way[lj * 2 + 2], false);

			if  (l_link_id_buf  <  0)
			{
				delete  []  pl_new_way;
				return(-4);			
			}//if  (l_link_id_buf  <  0)

			pl_new_way[lj * 2 + 1]  =  l_link_id_buf;
		
		}//for  (lj = 0; lj < l_traj_len - 1; lj++)


		

		//now we create the proper virtual way and try to insert it into the virtual way database
		CVirtualWay  *pc_new_vw, *pc_vw_buf;
		
		pc_new_vw  =  new  CVirtualWay;
		if  (pc_new_vw  ==  NULL)  
		{
			delete  []  pl_new_way;
			return(0);
		}//if  (pc_new_vw  ==  NULL)

		if  (pc_new_vw->bSetWay(pl_new_way, l_traj_len * 2 - 1)  ==  false)
		{
			delete  []  pl_new_way;
			delete  pc_new_vw;
			return(0);
		}//if  (pc_new_vw->bSetWay(pl_new_way, l_traj_len * 2 - 1)  ==  false)


		
		int  i_vw_input_res;	
		i_vw_input_res  =  pc_virtual_ways->iInputNewVirtWay
							(
							pc_new_vw,  pl_new_way[0],  pl_new_way[l_traj_len * 2 - 2],
							&pc_vw_buf, true
							);

		delete  []  pl_new_way;//we delete it because it's unnecessary after virtual way object initialization


		//virtual way inserted as new we just put the virtual way address(id) into trajectories table of the specie
		if  (i_vw_input_res  ==  1)
		{
			pc_trajectories[li]  =  pc_new_vw;
		}//if  (i_vw_input_res  ==  1)

		
		//virtual way not inserted because it already exists
		if  (i_vw_input_res  ==  2)
		{
			pc_trajectories[li]  =  pc_vw_buf;
			delete  pc_new_vw;		
		}//if  (i_vw_input_res  ==  2)


		//error occured
		if  (i_vw_input_res  <=  0)
		{
			delete  pc_new_vw;
			return(-5);		
		}//if  (i_vw_input_res  <=  0)



	}//for  (long  li = 0; li < i_number_of_pairs; li++)

	
	pc_net_sim->iRemoveAllConnections();
	if  (b_set_all_conns(plCapacities)  ==  false)  return(0);

	b_fom_lvl_actual  =  false;
	return(1);

}//int   CSingleTrajectorySet::iLoadFromIniFile(FILE  *pfSource,  CTopologyTranslator  *pcTranslator,  bool  bTranslate)




/*
returned values:
1  -  ok
0  -  memory allocation problems
-1 -  unexpected end of file
-2 -  wrong number of trajectories
-3 -  wrong trajectory number
-4 -  proper link id to fill up nodes spaces not found
-5 -  error while insterting virtual way
*/
int  CSingleTrajectorySet::iLoadFromOldIniFile(CTopologyTranslator  *pcTranslator, FILE  *pfSource,  long  *plCapacities,  bool  bTranslate)
{

	long  l_buf;


	if  (feof(pfSource)  ==  0)
		fscanf(pfSource,"%ld", &l_buf);
	else
		return(-1);//unexpected end of file
	


	if  (i_number_of_pairs  !=  l_buf)  return(-2);//wrong number of trajectories



	for  (long  li = 0; li < i_number_of_pairs; li++)
	{
		//single trajectory inputation

		//trajectory number
		if  (feof(pfSource)  ==  0)
			fscanf(pfSource,"%ld", &l_buf);
		else
			return(-1);//unexpected end of file

		if  (l_buf != li + 1)  return(-3);//wrong trajectory number


		//start&finish node numbers
		if  (feof(pfSource)  ==  0)
			fscanf(pfSource,"%ld", &l_buf);
		else
			return(-1);//unexpected end of file

		if  (bTranslate  ==  true)
		{
			//if we are given untranslated node numbers from the file we don't have to do any translation
			//when we compare them with "pl_start_finish_pairs" because these pairs were
			//directly read in and are untranslated by definition
			if  (
				l_buf  !=  pl_start_finish_pairs[li * 2]
				)  
				return(-4);//wrong start/finish node number


			if  (feof(pfSource)  ==  0)
				fscanf(pfSource,"%ld", &l_buf);
			else
				return(-1);//unexpected end of file

			if  (
				l_buf  !=  pl_start_finish_pairs[li * 2 + 1]
				)  
				return(-4);//wrong start/finish node number
		}//if  (bTranslate  ==  true)
		else
		{
			//if we are given translated node numbers from the file we have to translate
			//"pl_start_finish_pairs" because these pairs were
			//directly read in and are untranslated by definition

			if  (
				l_buf  !=  pcTranslator->lTranslateNodeNum(pl_start_finish_pairs[li * 2])
				)  
				return(-4);//wrong start/finish node number


			if  (feof(pfSource)  ==  0)
				fscanf(pfSource,"%ld", &l_buf);
			else
				return(-1);//unexpected end of file

			if  (
				l_buf  !=  pcTranslator->lTranslateNodeNum(pl_start_finish_pairs[li * 2 + 1])
				)  
				return(-4);//wrong start/finish node number
		
		}//else  if  (bTranslate  ==  true)



		//now reading trajectory length
		if  (feof(pfSource)  ==  0)
			fscanf(pfSource,"%ld", &l_buf);
		else
			return(-1);//unexpected end of file


		//now we read in trajectory nodes
		long  l_traj_len  =  l_buf;
		long  *pl_new_way;

		pl_new_way  =  new  long[l_traj_len * 2 - 1];//the length is doubled and decreased because we have to put links ids there
		if  (pl_new_way  ==  NULL)  return(0);

		for  (long  lj = 0; lj < l_traj_len; lj++)
		{

			//inputting trajectory nodes...
			if  (feof(pfSource)  ==  0)
				fscanf(pfSource,"%ld", &l_buf);
			else
			{
				delete  []  pl_new_way;
				return(-1);//unexpected end of file
			}//else if

			pl_new_way[lj * 2]  =  pcTranslator->lTranslateNodeNum(l_buf);
		
		}//for  (long  lj = 0; lj < l_traj_len; lj++)


		//now we fill spaces between nodes ids with propoer links ids
		long  l_link_id_buf;
		for  (long lj = 0; lj < l_traj_len - 1; lj++)
		{
			
			l_link_id_buf  =  
				pcTranslator->lFindLinkIdForNodes(pl_new_way[lj * 2],pl_new_way[lj * 2 + 2], false);

			if  (l_link_id_buf  <  0)
			{
				delete  []  pl_new_way;
				return(-4);			
			}//if  (l_link_id_buf  <  0)

			pl_new_way[lj * 2 + 1]  =  l_link_id_buf;
		
		}//for  (lj = 0; lj < l_traj_len - 1; lj++)


		

		//now we create the proper virtual way and try to insert it into the virtual way database
		CVirtualWay  *pc_new_vw, *pc_vw_buf;
		
		pc_new_vw  =  new  CVirtualWay;
		if  (pc_new_vw  ==  NULL)  
		{
			delete  []  pl_new_way;
			return(0);
		}//if  (pc_new_vw  ==  NULL)

		if  (pc_new_vw->bSetWay(pl_new_way, l_traj_len * 2 - 1)  ==  false)
		{
			delete  []  pl_new_way;
			delete  pc_new_vw;
			return(0);
		}//if  (pc_new_vw->bSetWay(pl_new_way, l_traj_len * 2 - 1)  ==  false)

		int  i_vw_input_res;	
		i_vw_input_res  =  pc_virtual_ways->iInputNewVirtWay
							(
							pc_new_vw,  pl_new_way[0],  pl_new_way[l_traj_len * 2 - 2],
							&pc_vw_buf, true
							);

		delete  []  pl_new_way;//we delete it because it's unnecessary after virtual way object initialization


		//virtual way inserted as new we just put the virtual way address(id) into trajectories table of the specie
		if  (i_vw_input_res  ==  1)
		{
			pc_trajectories[li]  =  pc_new_vw;
		}//if  (i_vw_input_res  ==  1)

		
		//virtual way not inserted because it already exists
		if  (i_vw_input_res  ==  2)
		{
			pc_trajectories[li]  =  pc_vw_buf;
			delete  pc_new_vw;		
		}//if  (i_vw_input_res  ==  2)


		//error occured
		if  (i_vw_input_res  <=  0)
		{
			delete  pc_new_vw;
			return(-5);		
		}//if  (i_vw_input_res  <=  0)



	}//for  (long  li = 0; li < i_number_of_pairs; li++)


	pc_net_sim->iRemoveAllConnections();
	if  (b_set_all_conns(plCapacities)  ==  false)  return(0);

	b_fom_lvl_actual  =  false;
	return(1);

}//int  CSingleTrajectorySet::iLoadFromFile(FILE  *pfSource,  CTopologyTranslator  *pcTranslator)




CMessyPattern*  CSingleTrajectorySet::pcGetPatternByDifference(CSingleTrajectorySet  *pcOther)
{
	CMessyPattern  *pc_result;

	if  (bIsTheSame(pcOther) ==  true)  return(NULL);

	pc_result  =  new CMessyPattern(i_number_of_pairs);

	for  (int  ii = 0; ii < i_number_of_pairs;  ii++)
	{
		if  (pc_trajectories[ii]  !=  pcOther->pc_trajectories[ii])
		{
			pc_result->v_genotype.push_back(new CMessyGene(pc_trajectories[ii], ii));
		}//if  (pc_trajectories[ii]  !=  pcOther->pc_trajectories[ii])
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	return(pc_result);
}//CMessyPattern*  CSingleTrajectorySet::pcGetPatternByDifference(CSingleTrajectorySet  *pcOther)




bool  CSingleTrajectorySet::bIsTheSame(CSingleTrajectorySet  *pcOther)
{
	if  ( (pc_trajectories  ==  NULL) )  return(false);
	if  ( (pcOther->pc_trajectories  ==  NULL) )  return(false);

	for  (int  ii = 0; ii < i_number_of_pairs;  ii++)
	{
		if  (pc_trajectories[ii]  !=  pcOther->pc_trajectories[ii])  return(false);	
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	return(true);
}//bool  CSingleTrajectorySet::bIsTheSame(CSingleTrajectorySet  *pcOther)




bool  CSingleTrajectorySet::bGetDifferences(CSingleTrajectorySet  *pcOther, CMessyPattern  *pcPattern)
{
	if  ( (pc_trajectories  ==  NULL) )  return(false);
	if  ( (pcOther->pc_trajectories  ==  NULL) )  return(false);

	for  (int  ii = 0;  ii < (int)  pcPattern->pvGetGenotype()->size(); ii++)
		delete  pcPattern->pvGetGenotype()->at(ii);
	pcPattern->pvGetGenotype()->clear();

	for  (int  ii = 0; ii < i_number_of_pairs;  ii++)
	{
		if  (pc_trajectories[ii]  !=  pcOther->pc_trajectories[ii])
			pcPattern->pvGetGenotype()->push_back(new  CMessyGene(pc_trajectories[ii], ii) );
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)


	return(true);
}//bool  CSingleTrajectorySet::bIsTheSame(CSingleTrajectorySet  *pcOther)




CError  CSingleTrajectorySet::eVirConfigure
	(
	bool  bGlueInfectionRows,
	int  iVirusGen,  int  iVirusPopSize,
	double  dPopReductionJuxtapositional,
	double  dVirProbCut,  double  dVirProbSplice,  double  dVirProbMut,
	double  dProbMutRemGene,	double  dProbMutAddGene,
	double  dProbLowLevelCross, double  dProbLowLevelMut,
	double  dProbInitMut
	)
{
	CError  c_err;


	if  (iVirusGen  <  0)
	{
		c_err.vPutError("Generation number below 0");
		return(c_err);	
	}//if  (iVirusGen  <  0)

	if  (iVirusPopSize  <  0)
	{
		c_err.vPutError("Population size below 0");
		return(c_err);	
	}//if  (iGenMax  <  0)


	if  ( (dVirProbCut  <  0)||(dVirProbCut  >  1) )
	{
		c_err.vPutError("Cut probability exceeds bounds");
		return(c_err);	
	}//if  ( (dVirProbCut  <  0)||(dVirProbCut  >  1) )

	if  ( (dVirProbSplice  <  0)||(dVirProbSplice  >  1) )
	{
		c_err.vPutError("Splice probability exceeds bounds");
		return(c_err);	
	}//if  (iGenMax  <  0)

	if  ( (dVirProbMut  <  0)||(dVirProbMut  >  1) )
	{
		c_err.vPutError("Mutation probability exceeds bounds");
		return(c_err);	
	}//if  (iGenMax  <  0)

	if  ( (dPopReductionJuxtapositional  <  0)||(dPopReductionJuxtapositional  >  1) )
	{
		c_err.vPutError("Population reduction juxta exceeds bounds");
		return(c_err);	
	}//if  (iGenMax  <  0)


	b_glue_infection_rows  =  bGlueInfectionRows;
	d_prob_cut  =  dVirProbCut;
	d_prob_splice  =  dVirProbSplice;
	d_prob_mut  =  dVirProbMut;

	i_generations  =  iVirusGen;
	i_pop_size  =  iVirusPopSize;

	d_pop_reduction_juxtapositional  =  dPopReductionJuxtapositional;

	d_prob_mut_rem_gene = dProbMutRemGene;
	d_prob_mut_add_gene = dProbMutAddGene;
	d_prob_low_level_cross = dProbLowLevelCross;
	d_prob_low_level_mut = dProbLowLevelMut;
	d_prob_init_mut = dProbInitMut;

		
	return(c_err);
}//CError  CSingleTrajectorySet::eVirConfigure





int  CSingleTrajectorySet::iGetNumberOfDiffrGenesToOtherBest(CMessyPattern  *pcPattern,  CSingleTrajectorySet  *pcOther)
{
	if  ( (pc_trajectories  ==  NULL) )  return(0);
	if  ( (pcOther->pc_trajectories  ==  NULL) )  return(0);

	int  i_result  = 0;

	for  (int  ii = 0; ii < (int) pcPattern->pvGetGenotype()->size();  ii++)
	{
		if  (
			pc_trajectories[pcPattern->pvGetGenotype()->at(ii)->i_gene_pos]  
			!=  
			pcOther->pc_best_solution_on_the_run[pcPattern->pvGetGenotype()->at(ii)->i_gene_pos]
			)  
			i_result++;
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	return(i_result);
}//int  CSingleTrajectorySet::iGetNumberOfDiffrGenesToOtherBest(CMessyPattern  *pcPattern,  CSingleTrajectorySet  *pcOther)



int  CSingleTrajectorySet::iGetNumberOfDiffrGenes(CMessyPattern  *pcPattern,  CSingleTrajectorySet  *pcOther)
{
	if  ( (pc_trajectories  ==  NULL) )  return(0);
	if  ( (pcOther->pc_trajectories  ==  NULL) )  return(0);

	int  i_result  = 0;

	for  (int  ii = 0; ii < (int) pcPattern->pvGetGenotype()->size();  ii++)
	{
		if  (
			pc_trajectories[pcPattern->pvGetGenotype()->at(ii)->i_gene_pos]  
			!=  
			pcOther->pc_trajectories[pcPattern->pvGetGenotype()->at(ii)->i_gene_pos])  
			i_result++;
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	return(i_result);
}//int  CSingleTrajectorySet::iGetNumberOfDiffrGenes(CmGA  *pcOther)









void  CSingleTrajectorySet::v_try_pattern_and_template_insert(CTrajectorySetsFinder  *pcVGA,  int  *piInitDone,  long  *plCapacities, long  lPenalty)
{
	*piInitDone  =  0;
	
	vector  <CMessyGene  *>  v_genotype,  v_genotype_for_pure_ct_and_pattern;

	CMessyPattern  *pc_pattern;
	CSingleTrajectorySet  *pc_competetive_template;

	pc_pattern  =  pcVGA->pc_get_random_pattern();
	pc_competetive_template  =  pcVGA->pc_get_parent_tournament_normal_for_pattern_different(pc_pattern, this);


	if  (pc_competetive_template_before_insert  ==  NULL)  pc_competetive_template_before_insert  =  new CVirtualWay* [i_number_of_pairs];
	for  (int  ii = 0;  ii < i_number_of_pairs; ii++)
		pc_competetive_template_before_insert[ii]  =  pc_trajectories[ii];




	if  ( (pc_pattern  !=  NULL)&&(pc_competetive_template  !=  NULL) )
	{
		//we create base proposition
		for  (int  ij = 0; ij < (int) pc_pattern->pvGetGenotype()->size(); ij++)
		{
			v_genotype.push_back
				(
				new  CMessyGene
					(
					pc_competetive_template->pc_best_solution_on_the_run[pc_pattern->pvGetGenotype()->at(ij)->i_gene_pos], 
					pc_pattern->pvGetGenotype()->at(ij)->i_gene_pos
					)
				);
		}//for  (int  ij = 0; ij < (int) pc_template->pvGetGenotype()->size(); ij++)


		//we check if the base proposition makes any changes - if it doesnt no computation wille be done AND
		bool  b_base_proposition_does_not_make_changes  =  true;
		for  (int  ij = 0; (ij < (int) v_genotype.size())&&(b_base_proposition_does_not_make_changes  ==  true); ij++)
		{
			if  (v_genotype.at(ij)->pc_gene_val  !=  pc_trajectories[v_genotype.at(ij)->i_gene_pos])
				b_base_proposition_does_not_make_changes  =  false;	
		}//for  (int  ij = 0; (ij < (int) v_genotype.size())&&(b_base_proposition_does_not_make_changes  ==  true); ij++)

		if  (b_base_proposition_does_not_make_changes  ==  true)
		{
			//we clear the genotype buffer
			for  (int  ij = 0; ij < (int) v_genotype.size(); ij++)
				delete  v_genotype.at(ij);
			v_genotype.clear();

			*piInitDone  =  1;
			return;
		}//if  (b_base_proposition_does_not_make_changes  ==  true)


		//we also check if the base proposition gives any enhancement - if it does we input it and dont do any computation too
		CMessyIndividual  c_buf(i_number_of_pairs);
		c_buf.vSetGenotype(&v_genotype);

		//we clear the genotype buffer
		for  (int  ij = 0; ij < (int) v_genotype.size(); ij++)
			delete  v_genotype.at(ij);
		v_genotype.clear();

		
		double  d_base_fit  =  c_buf.dComputeFitness(pc_trajectories,  pc_fitness_counter,  plCapacities, lPenalty, pc_net_sim, VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED);
		c_buf.vRemoveUnimportantGenes(pc_trajectories);

		if  (pc_infection_history  ==  NULL)
			pc_infection_history  =  new  CMessyIndividual(i_number_of_pairs);
		
		*pc_infection_history  =  c_buf;


		if  (d_base_fit  >  dCountFOM(pc_fitness_counter, plCapacities, lPenalty))
		{
			v_infect_competetive_template(pcVGA, &c_buf, plCapacities, lPenalty);//it MUST be here because v_infect_competetive_template affects dGetCompTemplateFitness

			*piInitDone  =  2;
			return;	
		}//if  (d_base_fit  >  dGetCompTemplateFitness())
		else
		{
			d_templ_fittness_before_insert  =  dCountFOM(pc_fitness_counter, plCapacities, lPenalty);
			v_infect_competetive_template(pcVGA, &c_buf, plCapacities, lPenalty);
			b_fom_lvl_actual = false;
		}//else  if  (d_base_fit  >  dGetCompTemplateFitness())


	}//if  ( (pc_pattern  !=  NULL)&&(pc_competetive_template  !=  NULL) )

}//void  CSingleTrajectorySet::v_try_pattern_and_template_insert()





CError  CSingleTrajectorySet::eReport(FILE  *pfReport)
{
	CError  c_err;

	fprintf(pfReport,  "Competetive template:\n");
	fprintf(pfReport,  "Fitness: %.16lf  Pure:%.16lf Penalty:%.16lf\n",  d_fom_level_penalized, d_fom_level_pure, d_penalty_pure);
	//for  (int  ii = 0;  ii < i_number_of_pairs;  ii++)
	//	fprintf(pfReport,  "%d\t",  pc_trajectories[ii]);


	return(c_err);
}//CError  CSingleTrajectorySet::eReport(FILE  *pfReport)




void  CSingleTrajectorySet::v_infect_competetive_template(CTrajectorySetsFinder  *pcVGA, CMessyIndividual  *pcBestFound, long  *plCapacities, long  lPenalty)
{
	
	d_fom_level_penalized  =  pcBestFound->dComputeFitness(pc_trajectories,  pc_fitness_counter, plCapacities, lPenalty, pc_net_sim, VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED);

	CVirtualWay  **pc_fenotype;
	pc_fenotype  =  pcBestFound->pcGetFenotype();


	int  i_buf;
	long  l_conn_set_result;
	long  *pl_buf;

	for  (int  ii = 0; ii < i_number_of_pairs; ii++)
	{
		if ( (pc_fenotype[ii]  !=  NULL)&&(pc_fenotype[ii]  !=  pc_trajectories[ii]) )
		{
			i_buf  =  pc_trajectories[ii]->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] * (-1) );

			i_buf  =  pc_fenotype[ii]->iGetWay(&pl_buf);
			l_conn_set_result  =  pc_net_sim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] );


			pc_trajectories[ii]  =  pc_fenotype[ii];	
		}//if ( (pc_fenotype[ii]  !=  NULL)&&(pc_fenotype[ii]  !=  pc_trajectories[ii]) )
	
	}//for  (int  ii = 0; ii < i_fenotype_length; ii++)

	b_fom_lvl_actual = false;

	vSaveBestSolutionOnTheRun(pcVGA);
}//void  CSingleTrajectorySet::v_infect_competetive_template(CMessyIndividual  *pcBestFound)




CError  CSingleTrajectorySet::eVirRun(vector  <CMessyPattern  *>  *pvInfectionHistory,  CTrajectorySetsFinder  *pcVGA,  int  *piInitDone, int iParentSelection, bool bRestoreCTifNoImprovement /*= true*/)
{
	CError  c_err;


	b_fom_lvl_actual = false;
	dCountFOM(pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty);
	if  ( (b_virgin_init  ==  false)&&(bRestoreCTifNoImprovement == true) )
	{
		v_try_pattern_and_template_insert(pcVGA,  piInitDone, pcVGA->pl_capacities, pcVGA->l_penalty);
		vSaveBestSolutionOnTheRun(pcVGA);
		if  (*piInitDone  !=  0)  return(c_err);
	}//if  (b_virgin_init  ==  false)

	int  i_buf = 0;//unecessary, but i dont wanna change interfaces
	b_fom_lvl_actual = false;

	c_err  =  e_juxtapositional_phase(&i_buf, pvInfectionHistory, pcVGA, iParentSelection, bRestoreCTifNoImprovement);
	vSaveBestSolutionOnTheRun(pcVGA);
	if  (c_err)  return(c_err);


	
	return(c_err);
}//CError  CSingleTrajectorySet::eVirRun()





CMessyIndividual*  CSingleTrajectorySet::pc_get_parent_tournament(int  iIndiv1Offset,  int  iIndiv2Offset,  long  *plCapacities, long  lPenalty, int iParentSelection /*=0*/,  bool  bBetterTakesAll  /*=  false*/)
{
	CString  s_buf;
	CMessyIndividual  *pc_candidate_1,  *pc_candidate_2;

	//Tools::vShow(iParentSelection + 1000);

	pc_candidate_1  =  pv_population->at(iIndiv1Offset);
	pc_candidate_2  =  pv_population->at(iIndiv2Offset);

	double  d_fit_1,  d_fit_2;

	d_fit_1  =  pc_candidate_1->dComputeFitness(pc_trajectories,  pc_fitness_counter, plCapacities, lPenalty, pc_net_sim, iParentSelection);
	d_fit_1  =  Math::Round(d_fit_1, 2);
	d_fit_2  =  pc_candidate_2->dComputeFitness(pc_trajectories,  pc_fitness_counter, plCapacities, lPenalty, pc_net_sim, iParentSelection);
	d_fit_2  =  Math::Round(d_fit_2, 2);

	//CString  s_buf;
	//s_buf.Format("%d %.4lf  %d %.4lf", iIndiv1Offset,  d_fit_1,  iIndiv2Offset,  d_fit_2);
	//System::Diagnostics::Debug::WriteLine((String *)s_buf);

	if  (iParentSelection == VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED)
	{
		if  (bBetterTakesAll  ==  true)
		{
			if  (d_fit_1  >  d_fit_2)  
				return(pc_candidate_1);
			else
				return(pc_candidate_2);
		
		}//if  (bBetterTakesAll  ==  true)
		else
		{
			double  d_fit_sum;
			d_fit_sum  =  d_fit_1  +  d_fit_2;
			d_fit_sum  =  d_fit_sum  *  dRand();

			if  (d_fit_sum  <  d_fit_1)
				return(pc_candidate_1);
			else
				return(pc_candidate_2);	
		}//else  if  (bBetterTakesAll  ==  true)
	}//if  (iParentSelection == VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED)



	if  (iParentSelection == VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED)
	{
		int  i_fit_1, i_fit_2;

		i_fit_1 = 0;
		i_fit_2 = 0;
		
		if  (pc_candidate_1->d_fitness_pure  <  pc_candidate_2->d_fitness_pure)  i_fit_1++;
		if  (pc_candidate_1->d_fitness_penalized  <  pc_candidate_2->d_fitness_penalized)  i_fit_1++;

		if  (pc_candidate_1->d_fitness_pure  >  pc_candidate_2->d_fitness_pure)  i_fit_2++;
		if  (pc_candidate_1->d_fitness_penalized  >  pc_candidate_2->d_fitness_penalized)  i_fit_2++;

		if  (i_fit_1  >  i_fit_2)  
			return(pc_candidate_1);
		else
			return(pc_candidate_2);
	

	}//if  (iParentSelection == VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED)



	if  (iParentSelection == VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED_RANKING)
	{
		double  d_ranking_1_objective, d_ranking_1_penalty;
		double  d_ranking_2_objective, d_ranking_2_penalty;
		double  d_ranking_1_weighted, d_ranking_2_weighted;

		d_ranking_1_weighted = pc_candidate_1->dGetRankingWeighted(&v_objective, &v_penalty, d_ranking_objective_weight, &d_ranking_1_objective, &d_ranking_1_penalty);
		d_ranking_2_weighted = pc_candidate_2->dGetRankingWeighted(&v_objective, &v_penalty, d_ranking_objective_weight, &d_ranking_2_objective, &d_ranking_2_penalty);

		/*d_ranking_1_objective = pc_candidate_1->dGetRankingObjective(&v_objective);
		d_ranking_1_penalty = pc_candidate_1->dGetRankingPenalty(&v_penalty);

		d_ranking_2_objective = pc_candidate_2->dGetRankingObjective(&v_objective);
		d_ranking_2_penalty = pc_candidate_2->dGetRankingPenalty(&v_penalty);

		d_ranking_1_weighted = d_ranking_1_objective * d_ranking_objective_weight  +  d_ranking_1_penalty * (1.0 - d_ranking_objective_weight);
		d_ranking_2_weighted = d_ranking_2_objective * d_ranking_objective_weight  +  d_ranking_2_penalty * (1.0 - d_ranking_objective_weight);*/

		
		
		/*double  d_test_1, d_test_2;
		d_test_1 = pc_candidate_1->dGetRankingWeighted(&v_objective, &v_penalty, d_ranking_objective_weight);
		d_test_2 = pc_candidate_2->dGetRankingWeighted(&v_objective, &v_penalty, d_ranking_objective_weight);

		if  ( (d_ranking_1_weighted == d_test_1)&&(d_ranking_2_weighted == d_test_2) )
		{
			s_buf.Format("%.4lf == %.4lf  AND %.4lf == %.4lf", d_ranking_1_weighted, d_test_1, d_ranking_2_weighted, d_test_2);
		}//if  ( (d_ranking_1_weighted == d_test_1)&&(d_ranking_2_weighted == d_test_2) )
		else
			s_buf.Format("WRONG %.4lf != %.4lf  AND %.4lf != %.4lf", d_ranking_1_weighted, d_test_1, d_ranking_2_weighted, d_test_2);


		::Tools::vRepInFile("zz_ran_test.txt", s_buf);*/
		

		/*s_buf.Format("1st Cand (obj, penalty): %.12lf  /  %.12lf", pc_candidate_1->d_fitness_pure, pc_candidate_1->d_penalty_pure);
		::Tools::vRepInFile("zz_ran_test.txt", s_buf);
		s_buf.Format("1st Cand RANKING: %.12lf  /  %.12lf", d_ranking_1_objective, d_ranking_1_penalty);
		::Tools::vRepInFile("zz_ran_test.txt", s_buf);
		s_buf.Format("1st Cand (obj, penalty): %.12lf  /  %.12lf", pc_candidate_2->d_fitness_pure, pc_candidate_2->d_penalty_pure);
		::Tools::vRepInFile("zz_ran_test.txt", s_buf);
		s_buf.Format("1st Cand RANKING: %.12lf  /  %.12lf", d_ranking_2_objective, d_ranking_2_penalty);
		::Tools::vRepInFile("zz_ran_test.txt", s_buf);
		::Tools::vShow("stop!");*/


		if  (d_ranking_1_weighted > d_ranking_2_weighted)  return(pc_candidate_1);
		if  (d_ranking_2_weighted > d_ranking_1_weighted)  return(pc_candidate_2);

		//weighted ranks are equal
		if  (d_ranking_1_penalty > d_ranking_2_penalty)  return(pc_candidate_1);
		if  (d_ranking_2_penalty > d_ranking_1_penalty)  return(pc_candidate_2);

		//weighted ranks and penalty ranks are equal
		if  (d_ranking_1_objective > d_ranking_2_objective)  return(pc_candidate_1);
		if  (d_ranking_1_objective < d_ranking_2_objective)  return(pc_candidate_2);

		return(pc_candidate_1);
	}//if  (iParentSelection == VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED_RANKING)
	
	

}//CMessyIndividual*  CSingleTrajectorySet::pc_get_parent_tournament(int  iIndiv1Offset,  int  iIndiv2Offset)





CMessyIndividual*  CSingleTrajectorySet::pc_get_parent_tournament(int  iTournamentSize,  long  *plCapacities, long  lPenalty, int iParentSelection /*=0*/, bool  bBetterTakesAll  /*=  false*/)
{
	if  (iTournamentSize  ==  2)
	{
		int  i_indiv_1,  i_indiv_2;

		i_indiv_1  =  lRand(pv_population->size());//pc_random_gen->Next(0,  pv_population->size());
		i_indiv_2  =  lRand(pv_population->size());//pc_random_gen->Next(0,  pv_population->size());

		
		while  ( (i_indiv_1  ==  i_indiv_2)&&(pv_population->size()  >  1) )
			i_indiv_2  =  lRand(pv_population->size());//pc_random_gen->Next(0,  pv_population->size());

		//CString  s_buf;
		//s_buf.Format("%d %d %d", i_indiv_1,  i_indiv_2,  (int) pv_population->size());
		//System::Diagnostics::Debug::WriteLine((String *)s_buf);

		return(pc_get_parent_tournament(i_indiv_1,  i_indiv_2,  plCapacities, lPenalty, iParentSelection, bBetterTakesAll));
	}//if  (iTournamentSize  ==  2)

	return(NULL);
}//CMessyIndividual*  CSingleTrajectorySet::pc_get_parent_tournament(int  iTournamentSize)



bool bDoubleGreater (double elem1, double elem2)
{
	return elem1 > elem2;
}




CError  CSingleTrajectorySet::e_juxtapositional_phase(int  *piGenNum,  vector  <CMessyPattern  *>  *pvInfectionHistory, CTrajectorySetsFinder  *pcVGA, int iParentSelection, bool bRestoreCTifNoImprovement /*= true*/)
{
	CError  c_err;
	CString  s_buf;
	
	CMessyIndividual  *pc_parent_1,  *pc_parent_2;
	int  i_parent_1_child_num,  i_parent_2_child_num;
	CMessyIndividual  *pc_par_1_child_1,  *pc_par_1_child_2;
	CMessyIndividual  *pc_par_2_child_1,  *pc_par_2_child_2;

	vector  <CMessyIndividual  *>  *pv_new_population;

	d_fom_level_penalized  =  dCountFOM(pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty);
	if  (pv_population  ==  NULL)  return(c_err);//if population does not exist we just simply go on and leave...


	if  (pc_best_found  !=  NULL)  
	{
		delete  pc_best_found;
		pc_best_found  =  NULL;	
	}//if  (pc_best_found  !=  NULL)  

	vSaveBestSolutionOnTheRun(pcVGA);
	
	double  d_current_pop_size;
	d_current_pop_size  =  i_pop_size;
	for  (int  i_gen = 0; i_gen <  i_generations; i_gen++)
	{
		(*piGenNum)++;

		//make ranking if you want to use it
		if  (iParentSelection == VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED_RANKING)  
		{
			v_objective.clear();
			v_penalty.clear();

			v_objective.reserve((int) pv_population->size() + 1);
			v_penalty.reserve((int) pv_population->size() + 1);

			//now fill it
			for  (int  ii = 0;  ii < (int) pv_population->size();  ii++)
			{
				pv_population->at(ii)->dComputeFitness(pc_trajectories,  pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim, iParentSelection);

				v_objective.push_back(pv_population->at(ii)->d_fitness_pure);
				v_penalty.push_back(pv_population->at(ii)->d_penalty_pure);
			}//for  (int  ii = 0;  ii < (int) pv_population->size();  ii++)

			dCountFOM(pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty);
			v_objective.push_back(this->d_fom_level_pure);
			v_penalty.push_back(this->d_penalty_pure);			

			std::sort(v_objective.begin(),  v_objective.end(), bDoubleGreater);
			std::sort(v_penalty.begin(),  v_penalty.end(), bDoubleGreater);

			/*for  (int  i_test = 0; i_test < pv_population->size(); i_test++)
			{
				s_buf.Format("%.12lf", v_objective.at(i_test));
				::Tools::vRepInFile("zzz_test_objective.txt", s_buf);

				s_buf.Format("%.12lf", v_penalty.at(i_test));
				::Tools::vRepInFile("zzz_test_penalty.txt", s_buf);
			}//for  (int  i_test = 0; i_test < pv_population->size(); i_test++)

			::Tools::vShow("TEST");//*/

		}//if  (iParentSelection == VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED_RANKING)  



		//we do not reduce for the first generation...
		if  (i_gen  !=  0)  d_current_pop_size  *=  d_pop_reduction_juxtapositional;

		pv_new_population  =  new  vector  <CMessyIndividual  *>;

		for  (;(int) pv_new_population->size()  <  d_current_pop_size;)
		{

			pc_parent_1  =  pc_get_parent_tournament(2, pcVGA->pl_capacities, pcVGA->l_penalty, iParentSelection);
			pc_parent_2  =  pc_get_parent_tournament(2, pcVGA->pl_capacities, pcVGA->l_penalty, iParentSelection);

			pc_par_1_child_1  =  new  CMessyIndividual(i_number_of_pairs);
			pc_par_1_child_2  =  new  CMessyIndividual(i_number_of_pairs);
			pc_par_2_child_1  =  new  CMessyIndividual(i_number_of_pairs);
			pc_par_2_child_2  =  new  CMessyIndividual(i_number_of_pairs);

			c_err  =  pc_parent_1->eCut(d_prob_cut,  pc_par_1_child_1,  pc_par_1_child_2,  &i_parent_1_child_num);
			if  (c_err)
			{
				delete  pc_par_1_child_1;
				delete  pc_par_1_child_2;
				delete  pc_par_2_child_1;
				delete  pc_par_2_child_2;

				return(c_err);
			}//if  (c_err)

			c_err  =  pc_parent_2->eCut(d_prob_cut,  pc_par_2_child_1,  pc_par_2_child_2,  &i_parent_2_child_num);
			if  (c_err)
			{
				delete  pc_par_1_child_1;
				delete  pc_par_1_child_2;
				delete  pc_par_2_child_1;
				delete  pc_par_2_child_2;

				return(c_err);
			}//if  (c_err)

			
			bool  b_spliced;
			if  ( (i_parent_1_child_num  ==  2)&&(i_parent_2_child_num  ==  2) )
			{
				pc_par_1_child_1->eSplice(d_prob_splice,  pc_par_2_child_2,  &b_spliced);

				if  (b_spliced  ==  true)
				{
					pc_par_2_child_1->eSplice(d_prob_splice,  pc_par_1_child_2,  &b_spliced);

					if  (b_spliced  == true)
					{
						pv_new_population->push_back(pc_par_1_child_1);
						pv_new_population->push_back(pc_par_2_child_1);


						delete  pc_par_1_child_2;
						delete  pc_par_2_child_2;
					}//if  (b_spliced  == true)
					else
					{
						pv_new_population->push_back(pc_par_1_child_1);
						pv_new_population->push_back(pc_par_1_child_2);
						pv_new_population->push_back(pc_par_2_child_1);


						delete  pc_par_2_child_2;
					}//else  if  (b_spliced  == true)
				
				}//if  (b_spliced  ==  true)
				else
				{
					pc_par_2_child_2->eSplice(d_prob_splice,  pc_par_2_child_1,  &b_spliced);

					if  (b_spliced  == true)
					{
						pv_new_population->push_back(pc_par_1_child_1);
						pv_new_population->push_back(pc_par_1_child_2);
						pv_new_population->push_back(pc_par_2_child_2);


						delete  pc_par_2_child_1;
					}//if  (b_spliced  == true)
					else
					{
						pc_par_2_child_1->eSplice(d_prob_splice,  pc_par_1_child_2,  &b_spliced);

						if  (b_spliced  == true)
						{
							pv_new_population->push_back(pc_par_1_child_1);
							pv_new_population->push_back(pc_par_2_child_1);
							pv_new_population->push_back(pc_par_2_child_2);

							delete  pc_par_1_child_2;
						}//if  (b_spliced  == true)
						else
						{
							pv_new_population->push_back(pc_par_1_child_1);
							pv_new_population->push_back(pc_par_1_child_2);
							pv_new_population->push_back(pc_par_2_child_1);
							pv_new_population->push_back(pc_par_2_child_2);

						}//else  if  (b_spliced  == true)

					}//else  if  (b_spliced  == true)
				
				}//else  if  (b_spliced  ==  true)
			
			}//if  ( (i_parent_1_child_num  ==  2)&&(i_parent_2_child_num  ==  2) )


			if  ( (i_parent_1_child_num  ==  2)&&(i_parent_2_child_num  ==  1) )
			{
				delete  pc_par_2_child_2;
							

				pc_par_1_child_1->eSplice(d_prob_splice,  pc_par_2_child_1,  &b_spliced);

				if  (b_spliced  ==  true)
				{
					pv_new_population->push_back(pc_par_1_child_1);
					pv_new_population->push_back(pc_par_1_child_2);

					
					delete  pc_par_2_child_1;
				}//if  (b_spliced  ==  true)
				else
				{
					pc_par_2_child_1->eSplice(d_prob_splice,  pc_par_1_child_2,  &b_spliced);
					if  (b_spliced  ==  true)
					{
						pv_new_population->push_back(pc_par_1_child_1);
						pv_new_population->push_back(pc_par_2_child_1);

							
						delete  pc_par_1_child_2;
					}//if  (b_spliced  ==  true)
					else
					{
						pv_new_population->push_back(pc_par_1_child_1);
						pv_new_population->push_back(pc_par_1_child_2);
						pv_new_population->push_back(pc_par_2_child_1);

					}//else  if  (b_spliced  ==  true)*/
				
				}//else  if  (b_spliced  ==  true)

			
			}//if  ( (i_parent_1_child_num  ==  2)&&(i_parent_2_child_num  ==  1) )


			if  ( (i_parent_1_child_num  ==  1)&&(i_parent_2_child_num  ==  2) )
			{
				delete  pc_par_1_child_2;

				pc_par_1_child_1->eSplice(d_prob_splice,  pc_par_2_child_2,  &b_spliced);

				if  (b_spliced  ==  true)
				{
					pv_new_population->push_back(pc_par_1_child_1);
					pv_new_population->push_back(pc_par_2_child_1);

					delete  pc_par_2_child_2;
				}//if  (b_spliced  ==  true)
				else
				{
					pc_par_2_child_1->eSplice(d_prob_splice,  pc_par_2_child_2,  &b_spliced);
					if  (b_spliced  ==  true)
					{
						pv_new_population->push_back(pc_par_1_child_1);
						pv_new_population->push_back(pc_par_2_child_1);

						delete  pc_par_2_child_2;
					}//if  (b_spliced  ==  true)
					else
					{
						pc_par_2_child_1->eSplice(d_prob_splice,  pc_par_1_child_1,  &b_spliced);
						if  (b_spliced  ==  true)
						{
							pv_new_population->push_back(pc_par_2_child_1);
							pv_new_population->push_back(pc_par_2_child_2);

				
							delete  pc_par_1_child_1;
						}//if  (b_spliced  ==  true)
						else
						{
							pv_new_population->push_back(pc_par_1_child_1);
							pv_new_population->push_back(pc_par_2_child_1);
							pv_new_population->push_back(pc_par_2_child_2);

						}//else  if  (b_spliced  ==  true)
					}//else  if  (b_spliced  ==  true)
				
				}//else  if  (b_spliced  ==  true)

			}//if  ( (i_parent_1_child_num  ==  1)&&(i_parent_2_child_num  ==  2) )



			if  ( (i_parent_1_child_num  ==  1)&&(i_parent_2_child_num  ==  1) )
			{
				delete  pc_par_1_child_2;
				delete  pc_par_2_child_2;
				
				pc_par_1_child_1->eSplice(d_prob_splice,  pc_par_2_child_1,  &b_spliced);

				if  (b_spliced  ==  true)
				{
					pv_new_population->push_back(pc_par_1_child_1);
						
					delete  pc_par_2_child_1;
				}//if  (b_spliced  ==  true)
				else
				{
					pc_par_2_child_1->eSplice(d_prob_splice,  pc_par_1_child_1,  &b_spliced);

					if  (b_spliced  ==  true)
					{
						pv_new_population->push_back(pc_par_2_child_1);
							
						delete  pc_par_1_child_1;
					}//if  (b_spliced  ==  true)
					else
					{
						pv_new_population->push_back(pc_par_1_child_1);
						pv_new_population->push_back(pc_par_2_child_1);

					}//else
				
				}//else  if  (b_spliced  ==  true)
				
			
			}//if  ( (i_parent_1_child_num  ==  1)&&(i_parent_2_child_num  ==  1) )

		}//for  (;pv_new_population->size()  <  i_pop_size;)

		//replace old population with new
		for  (int  ii = 0;  ii < (int) pv_population->size();  ii++)
			delete  pv_population->at(ii);
		pv_population->clear();
		delete  pv_population;

		pv_population  =  pv_new_population;

		v_find_best_indiv(pcVGA, iParentSelection);

		//mutate population
		if  (d_prob_mut_rem_gene  >  0)
			for  (int  ii = 0;  ii < (int) pv_population->size();  ii++)
				pv_population->at(ii)->vMutateRemGene(d_prob_mut_rem_gene);

		if  (d_prob_mut  >  0)
			for  (int  ii = 0;  ii < (int) pv_population->size();  ii++)
				pv_population->at(ii)->vMutate(pc_net_sim, pc_trajectories,  pcVGA->pl_capacities, d_prob_mut, pl_start_finish_pairs, pc_virtual_ways);

		if  (d_prob_mut_add_gene  >  0)
			for  (int  ii = 0;  ii < (int) pv_population->size();  ii++)
				pv_population->at(ii)->vMutateAddGene(d_prob_mut_add_gene,  i_number_of_pairs, pl_start_finish_pairs, pc_virtual_ways);


		int  i_pop_size_before_low_level  =  (int) pv_population->size();
		if  (d_prob_low_level_cross  >  0)
		{
			CMessyIndividual  *pc_new_virus_low_level_crossed;

			for  (int  ii = 0;  ii < (int) i_pop_size_before_low_level;  ii++)
			{
				if  (dRand()  <  d_prob_low_level_cross)
				{
					pc_new_virus_low_level_crossed = new  CMessyIndividual(i_number_of_pairs);
					*pc_new_virus_low_level_crossed = *(pv_population->at(ii));
					
					pc_new_virus_low_level_crossed->vLowLevelCross(pl_start_finish_pairs, pc_virtual_ways, pc_trajectories, pc_net_sim, pcVGA->pl_capacities);
					pv_population->push_back(pc_new_virus_low_level_crossed);
				}//if  (dRand()  <  d_prob_low_level_cross)
			}//for  (int  ii = 0;  ii < (int) i_pop_size_before_low_level_crossing;  ii++)
		}//if  (d_prob_low_level_cross  >  0)




		if  (d_prob_low_level_mut  >  0)
		{
			int  i_pop_size_before_low_level_mutation  =  (int) pv_population->size();
			CMessyIndividual  *pc_new_virus_low_level_mutated;

			for  (int  ii = 0;  ii < (int) i_pop_size_before_low_level;  ii++)
			{
				if  (dRand()  <  d_prob_low_level_mut)
				{
					pc_new_virus_low_level_mutated = new  CMessyIndividual(i_number_of_pairs);
					*pc_new_virus_low_level_mutated = *(pv_population->at(ii));
					pc_new_virus_low_level_mutated->vLowLevelMutate(pl_start_finish_pairs, pc_virtual_ways, pc_trajectories, pc_net_sim, pcVGA->pl_capacities);
					pv_population->push_back(pc_new_virus_low_level_mutated);
				}//if  (dRand()  <  d_prob_low_level_cross)
			}//for  (int  ii = 0;  ii < (int) i_pop_size_before_low_level_crossing;  ii++)
		}//if  (d_prob_low_level_cross  >  0)*/


		v_find_best_indiv(pcVGA, iParentSelection);

		if  (pc_best_found  !=  NULL)
		{
			if  (
				pc_best_found->dComputeFitness(pc_trajectories,  pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim, VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED)
				>
				d_fom_level_penalized
				)
				i_gen = i_generations;
		
		}//if  (pc_best_found  !=  NULL)

	}//for  (; *piGenNum <  i_generations; (*piGenNum)++)


	if  (pc_best_found  !=  NULL)  
	{
		/*CString  s_buf;
		s_buf.Format("Current:%.16lf  Best:%.16lf", d_fom_level, pc_best_found->dComputeFitness(pc_trajectories, pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim));
		::MessageBox(NULL, s_buf, "", MB_OK);


		//pc_best_found->vShowFenotypeDiffr(pc_trajectories, "D:\\test.txt");
		FILE *pf_buf;
		pf_buf = fopen("D:\\test.txt", "w+");

		pc_best_found->eReport(pf_buf, false);
		s_buf.Format("\nFit:%.16lf", pc_best_found->dComputeFitness(pc_trajectories, pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim));
		fprintf(pf_buf, s_buf);

		fprintf(pf_buf, "\n\n\n");*/

		pc_best_found->vRemoveUnimportantGenes(pc_trajectories);
		/*pc_best_found->eReport(pf_buf, false);
		s_buf.Format("\nFit:%.16lf", pc_best_found->dComputeFitness(pc_trajectories, pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim));
		fprintf(pf_buf, s_buf);

		fprintf(pf_buf,  "\n\n\n\n\n");
		for  (int  ii = 0; ii < i_number_of_pairs;  ii++)
		{
			fprintf(pf_buf,  "\t%d", pc_trajectories[ii]->iId);
		}//for  (int  ii = 0; ii < i_fenotype_length;  ii++)

		fclose(pf_buf);



		//pc_best_found->vShowFenotypeDiffr(pc_trajectories, "D:\\test3.txt");
		s_buf.Format("After remove unimportant  Best:%.16lf", pc_best_found->dComputeFitness(pc_trajectories, pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim));
		::MessageBox(NULL, s_buf, "", MB_OK);*/

	

		v_infect_competetive_template(pcVGA, pc_best_found, pcVGA->pl_capacities, pcVGA->l_penalty);

		
		//s_buf.Format("Atfter infect Current:%.16lf", dCountFOM(pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty));
		//::MessageBox(NULL, s_buf, "", MB_OK);


		if  (d_ranking_objective_weight == 0)
		{
			if  (b_glue_infection_rows)
			{

				if  (pc_infection_history  ==  NULL)
				{
					pc_infection_history  =  new  CMessyIndividual(i_number_of_pairs);
					pc_infection_history->vSplice(pc_best_found);
				}//if  (pc_best_found  ==  NULL)
				else
				{
					pc_infection_history->vSplice(pc_best_found);			
				}//else  if  (pc_best_found  ==  NULL)
			
			}//if  (b_glue_infection_rows)
			else
			{
				CMessyPattern  *pc_buf;
				pc_buf  =  new  CMessyPattern(i_number_of_pairs);
				*pc_buf  =  *pc_best_found;
				if  (pvInfectionHistory  !=  NULL)  pvInfectionHistory->push_back(pc_buf);
			}//else  if  (bGlueInfectionRows)
		}//if  (d_ranking_objective_weight == 0)
		else
			vSetInfectionHistory(NULL);

		
	}//if  (pc_best_found  !=  NULL)
	else
		b_virgin_init  =  false;


	//we check if fitness hasnt droped if it did then we restore the previous (better) template
	if  (bRestoreCTifNoImprovement == true)
	{
		if  ( (iParentSelection != VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED_RANKING)||(d_ranking_objective_weight == 0) )  vRestoreCT(pcVGA);
		/*if  ( (pc_competetive_template_before_insert  !=  NULL)&&(d_templ_fittness_before_insert  >  dCountFOM(pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty)) )
		{
			//first we check if the modification was NOT a takeback of insert operation (pattern*ct in VirRegeneratePopulation)
			bool  b_take_back  =  true;
			for  (int  ii = 0;  (ii < i_number_of_pairs)&&(b_take_back  ==  true); ii++)
			{
				if  (pc_trajectories[ii]  !=  pc_competetive_template_before_insert[ii])
					b_take_back  =  false;
			}//for  (int  ii = 0;  (ii < i_templ_length)&&(b_take_back  ==  false); ii++)

			if  (b_take_back  ==  true)
			{
				delete  pc_infection_history;
				pc_infection_history  =  NULL;	
			}//if  (b_take_back  ==  true)
				


			for  (int  ii = 0;  ii < i_number_of_pairs; ii++)
				pc_trajectories[ii]  =  pc_competetive_template_before_insert[ii];

			//CMessyIndividual  c_buf(i_number_of_pairs);
			//d_fom_level  =  c_buf.dComputeFitness(pc_trajectories,  pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim);
			b_fom_lvl_actual = false;
			dCountFOM(pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty);
		}//if  ( (pi_competetive_template_before_insert  !=  NULL)&&(d_templ_fittness_before_insert  >  dGetCompTemplateFitness()) )*/
	}//if  (bRestoreCTifNoImprovement == true)
	


	

	return(c_err);
}//CError  CSingleTrajectorySet::e_juxtapositional_phase(int  *piGenNum)




void  CSingleTrajectorySet::vRestoreCT(CTrajectorySetsFinder  *pcVGA)
{
	if  ( (pc_competetive_template_before_insert  !=  NULL)&&(d_templ_fittness_before_insert  >  dCountFOM(pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty)) )
	{
		//first we check if the modification was NOT a takeback of insert operation (pattern*ct in VirRegeneratePopulation)
		bool  b_take_back  =  true;
		for  (int  ii = 0;  (ii < i_number_of_pairs)&&(b_take_back  ==  true); ii++)
		{
			if  (pc_trajectories[ii]  !=  pc_competetive_template_before_insert[ii])
				b_take_back  =  false;
		}//for  (int  ii = 0;  (ii < i_templ_length)&&(b_take_back  ==  false); ii++)

		if  (b_take_back  ==  true)
		{
			delete  pc_infection_history;
			pc_infection_history  =  NULL;	
		}//if  (b_take_back  ==  true)
			


		for  (int  ii = 0;  ii < i_number_of_pairs; ii++)
			pc_trajectories[ii]  =  pc_competetive_template_before_insert[ii];

		//CMessyIndividual  c_buf(i_number_of_pairs);
		//d_fom_level  =  c_buf.dComputeFitness(pc_trajectories,  pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim);
		b_fom_lvl_actual = false;
		dCountFOM(pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty);
	}//if  ( (pi_competetive_template_before_insert  !=  NULL)&&(d_templ_fittness_before_insert  >  dGetCompTemplateFitness()) )

}//void  CSingleTrajectorySet::vRestoreCT()



void  CSingleTrajectorySet::v_find_best_indiv(CTrajectorySetsFinder  *pcVGA, int iParentSelection)
{
	//Tools::vShow("aaa");

	if  ( (iParentSelection != VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED_RANKING)||(d_ranking_objective_weight == 0) )
	{
		for  (int  ii = 0;  ii < (int)  pv_population->size();  ii++)
		{
			if  (pc_best_found  ==  NULL)
			{
				if  (d_fom_level_penalized  <  pv_population->at(ii)->dComputeFitness(pc_trajectories,  pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim, VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED))
				{
					pc_best_found  =  new  CMessyIndividual(i_number_of_pairs);

					*pc_best_found  =  *(pv_population->at(ii));
				}//if  (d_templ_fitness  <  pv_population->at(ii)->dComputeFitness(pi_competetive_template,  pc_fitness))
			}//if  (pc_best_found  ==  NULL)
			else
			{
				if  (
					pc_best_found->dComputeFitness(pc_trajectories,  pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim, VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED)
					<
 					pv_population->at(ii)->dComputeFitness(pc_trajectories,  pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim, VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED)
					)
					*pc_best_found  =  *(pv_population->at(ii));
			
			}//else  if  (pc_best_found  ==  NULL)
		
		}//for  (int  ii = 0;  ii < (int)  pv_population->size();  ii++)
	}//if  ( (iParentSelection != VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED_RANKING)||(d_ranking_objective_weight == 0) )
	else
	{
		double  d_current_best_weighted_ranking, d_current_best_weighted_objective, d_current_best_weighted_penalty;
		double  d_pop_weighted_ranking, d_pop_weighted_objective, d_pop_weighted_penalty;

		if  (pc_best_found  ==  NULL)
		{

			//d_current_best_weighted_ranking = dGetRankingWeighted(&v_objective, &v_penalty, d_ranking_objective_weight, pc_fitness_counter,pcVGA->pl_capacities, pcVGA->l_penalty);
			d_current_best_weighted_ranking = 0;

			//CString  s_buf;
			//s_buf.Format("\n\n\n\nSTART\n CT: %.4lf  obj: %.4lf  pen: %.4lf  ", d_current_best_weighted_ranking);
			//s_buf.Format("\n\n\n\nSTART\n");
			//::Tools::vRepInFile("zz_ran_test.txt", s_buf);
		}//if  (pc_best_found  ==  NULL)
		else
			d_current_best_weighted_ranking = pc_best_found->dGetRankingWeighted(&v_objective, &v_penalty, d_ranking_objective_weight, &d_current_best_weighted_objective, &d_current_best_weighted_penalty);


		


		for  (int  ii = 0;  ii < (int)  pv_population->size();  ii++)
		{
			pv_population->at(ii)->dComputeFitness(pc_trajectories,  pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty, pc_net_sim, VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED);

			d_pop_weighted_ranking = pv_population->at(ii)->dGetRankingWeighted(&v_objective, &v_penalty, d_ranking_objective_weight, &d_pop_weighted_objective, &d_pop_weighted_penalty);
			
			if  (
				(d_current_best_weighted_ranking  <  d_pop_weighted_ranking)||
				((d_current_best_weighted_ranking  ==  d_pop_weighted_ranking)&&(d_current_best_weighted_penalty < d_pop_weighted_penalty))||
				((d_current_best_weighted_ranking  ==  d_pop_weighted_ranking)&&(d_current_best_weighted_penalty == d_pop_weighted_penalty)&&(d_current_best_weighted_objective < d_pop_weighted_objective))
				)
			{
				if  (pc_best_found  ==  NULL)  pc_best_found  =  new  CMessyIndividual(i_number_of_pairs);

				*pc_best_found  =  *(pv_population->at(ii));

				/*CString  s_buf;
				s_buf.Format
					(
					"before best: %.4lf  obj: %.4lf  pen: %.4lf   AFTER best: %.4lf  obj: %.4lf  pen: %.4lf  ", 
					d_current_best_weighted_ranking, d_current_best_weighted_objective, d_current_best_weighted_penalty,
					d_pop_weighted_ranking, d_pop_weighted_objective, d_pop_weighted_penalty
					);
				::Tools::vRepInFile("zz_ran_test.txt", s_buf);//*/


				d_current_best_weighted_ranking = pc_best_found->dGetRankingWeighted(&v_objective, &v_penalty, d_ranking_objective_weight, &d_current_best_weighted_objective, &d_current_best_weighted_penalty);
			}//if  (d_templ_fitness  <  pv_population->at(ii)->dComputeFitness(pi_competetive_template,  pc_fitness))
		
		}//for  (int  ii = 0;  ii < (int)  pv_population->size();  ii++)	
	}//else  if  ( (iParentSelection != VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED_RANKING)||(d_ranking_objective_weight == 0) )

}//void  CSingleTrajectorySet::v_find_best_indiv()





CError  CSingleTrajectorySet::eVirReGeneratePopulation(CTrajectorySetsFinder  *pcVGA,  bool  bVirInitDifferentToTemplate)//the template and CT is randomly chosen for every virus
{
	CError  c_err;

	CMessyIndividual  *pc_indiv;
	vector  <CMessyGene  *>  v_genotype;

	if  (pv_population  ==  NULL)  
		pv_population  =  new  vector<CMessyIndividual  *>;
	


	CMessyPattern  *pc_pattern;
	CSingleTrajectorySet  *pc_competetive_template, *pc_random_ct, *pc_random_ct_2;
	int  i_buf;

	int  i_gene_pos;
	CVirtualWay  *pc_gene_val;
	
	for  (int  ii = 0; ii < pv_population->size(); ii++)
		pv_population->at(ii)->b_fenotype_actual = false;


	bool  b_self_pattern_generated = false;
	CMessyPattern  *pc_self_pattern = NULL;
	double  d_this_fit_buf;
	d_this_fit_buf  =  this->dCountFOM(pc_fitness_counter, pcVGA->pl_capacities, pcVGA->l_penalty);
	if  ( (d_this_fit_buf != this->dGetBestResultOnTheRunFitness())&&(this->dGetBestResultOnTheRunFitness() > 0) )
	{

		pc_self_pattern  =  new CMessyPattern(i_number_of_pairs);

		for  (int  ii = 0; ii < i_number_of_pairs;  ii++)
		{
			if  (pc_trajectories[ii]  !=  pc_best_solution_on_the_run[ii])
			{
				pc_self_pattern->v_genotype.push_back(new CMessyGene(pc_trajectories[ii], ii));
			}//if  (pc_trajectories[ii]  !=  pcOther->pc_trajectories[ii])
		}//for  (int  ii = 0; ii < i_templ_length;  ii++)
	}//if  (d_fit_buf != pv_population->at(ii)->dGetBestResultOnTheRunFitness())


	int  i_virus_init_length;
	for  (int  ii = 0; ii < i_pop_size;  ii++)
	{
		if  (b_virgin_init  ==  false)
		{
			pc_pattern  =  pcVGA->pc_get_random_pattern();
			pc_competetive_template  =  pcVGA->pc_get_parent_tournament_normal_for_pattern_different(pc_pattern,  this);

			if  ( (pc_pattern  ==  NULL)||(pc_competetive_template == NULL) )
			{
				if  ( (d_this_fit_buf != this->dGetBestResultOnTheRunFitness())&&(pc_self_pattern != NULL) )
				{
					pc_pattern  =  pc_self_pattern;
					pc_competetive_template = this;
				}//if  ( (d_this_fit_buf != this->dGetBestResultOnTheRunFitness())&&(pc_self_pattern != NULL) )
			}//if  ( (pc_pattern  ==  NULL)||(pc_competetive_template == NULL) )
		}//if  (b_virgin_init  ==  false)
		else
		{
			pc_pattern  =  NULL;
			pc_competetive_template  =  NULL;
		}//else  if  (b_virgin_init  ==  false)


		i_virus_init_length  =  lRand(i_number_of_pairs) + 1;//pc_random_gen->Next(1, i_templ_length + 1);
		
		if  ( (pc_pattern  !=  NULL)&&(pc_competetive_template  !=  NULL)&&(b_virgin_init  ==  false) )
		{
			for  (int  ij = 0; ij < i_virus_init_length; ij++)
			{
				i_gene_pos = lRand(i_number_of_pairs);

					pc_gene_val  =  
						pc_virtual_ways->pcGetVirtualWay
							(
							pl_start_finish_pairs[i_gene_pos * 2],
							pl_start_finish_pairs[i_gene_pos * 2 + 1]
							);

				v_genotype.push_back(new  CMessyGene(pc_gene_val, i_gene_pos));
			}//for  (int  ij = 0; ij < i_virus_init_length; ij++)*/

			i_buf = lRand(pcVGA->pv_population->size());
			pc_random_ct = pcVGA->pv_population->at(i_buf);
			i_buf = lRand(pcVGA->pv_population->size());
			pc_random_ct_2 = pcVGA->pv_population->at(i_buf);
			CMessyPattern  c_pattern(i_number_of_pairs);
			pc_random_ct->bGetDifferences(pc_random_ct_2, &c_pattern);

			
			for  (int  ij = 0; ij < i_virus_init_length; ij++)
			{
				if  (bVirInitDifferentToTemplate  ==  false)
				{
					if  (c_pattern.pvGetGenotype()->size()  >  0)
					{
						i_gene_pos = lRand(c_pattern.pvGetGenotype()->size());
						i_gene_pos = c_pattern.pvGetGenotype()->at(i_gene_pos)->i_gene_pos;

						//i_gene_pos = lRand(i_number_of_pairs);

						pc_gene_val  =  
							pc_virtual_ways->pcGetVirtualWay
								(
								pl_start_finish_pairs[i_gene_pos * 2],
								pl_start_finish_pairs[i_gene_pos * 2 + 1]
								);

						v_genotype.push_back(new  CMessyGene(pc_gene_val, i_gene_pos));
					}//if  (c_pattern.pvGetGenotype()->size()  >  0)
				}//if  (bVirInitDifferentToTemplate  ==  false)
				else
				{
					/*i_gene_pos  =  pc_random_gen->Next(0, i_templ_length);
					i_gene_val  =  pi_competetive_template[i_gene_pos];

					if  (i_gene_val  ==  0)  
						i_gene_val  =  1;
					else
						i_gene_val  =  0;

					v_genotype.push_back(new  CMessyGene(i_gene_val,  i_gene_pos));*/

					c_err.vPutError("bVirInitDifferentToTemplate == true - not supported");
					return(c_err);
				}//else  if  (bVirInitDifferentToTemplate  ==  false)
			}//for  (int  ij = 0; ij < i_virus_init_length; ij++)


			for  (int  ij = 0; ij < (int) pc_pattern->pvGetGenotype()->size(); ij++)
			{
				v_genotype.push_back
					(
					new  CMessyGene
						(
						pc_competetive_template->pc_best_solution_on_the_run[pc_pattern->pvGetGenotype()->at(ij)->i_gene_pos], 
						pc_pattern->pvGetGenotype()->at(ij)->i_gene_pos
						)
					);

				//v_genotype_for_pure_ct_and_pattern.push_back(v_genotype.at(v_genotype.size() - 1));
			}//for  (int  ij = 0; ij < (int) pc_template->pvGetGenotype()->size(); ij++)

		}//if  (pcTemplate  !=  NULL)
		else
		{
			if  (bVirInitDifferentToTemplate  ==  false)
			{
				for  (int  ij = 0; ij < i_virus_init_length; ij++)
				{
					i_gene_pos = lRand(i_number_of_pairs);

						pc_gene_val  =  
							pc_virtual_ways->pcGetVirtualWay
								(
								pl_start_finish_pairs[i_gene_pos * 2],
								pl_start_finish_pairs[i_gene_pos * 2 + 1]
								);

					v_genotype.push_back(new  CMessyGene(pc_gene_val, i_gene_pos));
				}//for  (int  ij = 0; ij < i_virus_init_length; ij++)
			}//if  (bVirInitDifferentToTemplate  ==  false)
			else
			{
				c_err.vPutError("bVirInitDifferentToTemplate == true - not supported");
				return(c_err);
				/*i_gene_pos  =  pc_random_gen->Next(0, i_templ_length);
				i_gene_val  =  pi_competetive_template[i_gene_pos];

				if  (i_gene_val  ==  0)  
					i_gene_val  =  1;
				else
					i_gene_val  =  0;

				v_genotype.push_back(new  CMessyGene(i_gene_val,  i_gene_pos));*/
			}//else  if  (bVirInitDifferentToTemplate  ==  false)
		}//else  if  (pcTemplate  !=  NULL)

		//if  (ii  <  (int)  pv_population->size())
		//	pc_indiv  =  pv_population->at(ii);
		//else
		{
			pc_indiv  =  new  CMessyIndividual(i_number_of_pairs);
			pv_population->push_back(pc_indiv);
		}//else  if  (ii  <  (int)  pv_population->size())
		
		
		pc_indiv->vSetGenotype(&v_genotype);


				
		for  (int  ij = 0; ij < (int) v_genotype.size(); ij++)
			delete  v_genotype.at(ij);
		v_genotype.clear();

		
	}//for  (int  ii = 0; ii < i_pop_size;  ii++)

	if  (pc_self_pattern != NULL)  delete  pc_self_pattern;
	//for  (int  ii = 0; ii < (int) v_pure_ct_and_pattern_pop.size();  ii++)
	//	pv_population->push_back(v_pure_ct_and_pattern_pop.at(ii));*/


	return(c_err);
}//CError  CSingleTrajectorySet::eVirGeneratePopulation(int  iVirusInitLength,  CVirusGA  *pcVGA)//the template is randomly chosen








//---------------------------class  CMessyGene--------------------------------------

CMessyGene::CMessyGene()
{
	i_gene_pos  =  0;
	pc_gene_val  =  NULL;
}//CMessyGene::CMessyGene()


CMessyGene::CMessyGene(CVirtualWay  *pcGeneVal,  int  iGenePos)
{
	i_gene_pos  =  iGenePos;
	pc_gene_val  =  pcGeneVal;
}//CMessyGene::CMessyGene(int  iGeneVal,  int  iGenePos)


CMessyGene::CMessyGene(CMessyGene  *pcOther)
{
	i_gene_pos  =  pcOther->i_gene_pos;
	pc_gene_val  =  pcOther->pc_gene_val;
}//CMessyGene::CMessyGene(CMessyGene  *pcOther)


CMessyGene::~CMessyGene()
{

};//CMessyGene::~CMessyGene()






//---------------------------class  CMessyIndividual--------------------------------------

CMessyIndividual::CMessyIndividual(int  iFenotypeLength)
{
	pc_fenotype  =  new  CVirtualWay* [iFenotypeLength];
	pc_effective_fenotype  =  new  CVirtualWay* [iFenotypeLength];
	i_effective_fenotype_length  =  iFenotypeLength;


	b_fenotype_actual  =  false;
//	b_effective_fenotype_actual  =  false;

	d_fitness_penalized  =  0;
	d_fitness_pure = 0;
	d_penalty_pure = 0;

	i_fenotype_length  =  0;
}//CMessyIndividual::CMessyIndividual()


CMessyIndividual::~CMessyIndividual()
{
	vFlushGentoype();
	if  (pc_fenotype  !=  NULL)  delete  pc_fenotype;
	if  (pc_effective_fenotype  !=  NULL)  delete  pc_effective_fenotype;
};//CMessyIndividual::~CMessyIndividual()



void  CMessyIndividual::vSetGenotype(vector  <CMessyGene  *>  *pvNewGenotype)
{
	vFlushGentoype();
	for  (int  ii = 0;  ii < (int) pvNewGenotype->size();  ii++)
		v_genotype.push_back(new  CMessyGene(pvNewGenotype->at(ii)));

}//CMessyIndividual::vSetGenotype(vector  <CMessyGene  *>  *pvNewGenotype)


void  CMessyIndividual::vAddGenotype(vector  <CMessyGene  *>  *pvNewGenotype)
{
//	b_effective_fenotype_actual  =  false;
	b_fenotype_actual  =  false;

	for  (int  ii = 0;  ii < (int) pvNewGenotype->size();  ii++)
		v_genotype.push_back(new  CMessyGene(pvNewGenotype->at(ii)));

}//CMessyIndividual::vSetGenotype(vector  <CMessyGene  *>  *pvNewGenotype)




void  CMessyIndividual::vFlushGentoype()
{
//	b_effective_fenotype_actual  =  false;
	b_fenotype_actual  =  false;

	for  (int  ii = 0;  ii < (int) v_genotype.size();  ii++)
		delete  v_genotype.at(ii);
	v_genotype.clear();
}//CMessyIndividual::vFlushGentoype()



void  CMessyIndividual::vSplice(CMessyIndividual  *pcSplicedIndividual)
{
	for  (int  ii = 0; ii < (int) pcSplicedIndividual->v_genotype.size();  ii++)
		v_genotype.push_back(pcSplicedIndividual->v_genotype.at(ii));

	b_fenotype_actual  =  false;
//	b_effective_fenotype_actual  =  false;

	//now removing spliced pointers from the source...
	pcSplicedIndividual->v_genotype.clear();
}//void  CMessyIndividual::vSplice(CMessyIndividual  *pcSplicedIndividual)


CError  CMessyIndividual::eSplice //this individual will be a splice result...
	(
	double  dSpliceProb,  
	CMessyIndividual  *pcSplicedIndividual,
	bool  *pbSpliced
	)
{
	CError  c_err;

	*pbSpliced  =  false;

	if  (dRand()  <  dSpliceProb)
	{
		*pbSpliced  =  true;

		vSplice(pcSplicedIndividual);
	}//if  (pcRandomGen->NextDouble()  <  dSpliceProb)*/


	return(c_err);
}//CError  CMessyIndividual::eSplice //this individual will be a splice result...




CError  CMessyIndividual::eCut
	(
	double  dCutProb,  
	CMessyIndividual  *pcPart1,  CMessyIndividual  *pcPart2,
	int  *piReturnedPartsNumber
	)
{
	CError  c_err;

	double  d_effective_cut_prob;
	d_effective_cut_prob  =  dCutProb;
	d_effective_cut_prob  *=  v_genotype.size();

	//*piReturnedPartsNumber  =  1;
	//*pcPart1  =  *this;	


	if  ( (dRand()  <  d_effective_cut_prob)&&(v_genotype.size()  >  1) )
	{
		*piReturnedPartsNumber  =  2;

		vector  <CMessyGene  *>  v_genotype_1,  v_genotype_2;
		int  i_cut_point;

		i_cut_point  =  lRand(v_genotype.size()-1);//pcRandomGen->Next(0, v_genotype.size()-1);  // the numbers returned: 1,2,3,..., size()-1
		i_cut_point++;

		for  (int  ii = 0;  ii <  i_cut_point;  ii++)
			v_genotype_1.push_back(v_genotype.at(ii));

		for  (int  ii = i_cut_point;  ii <  (int) v_genotype.size();  ii++)
			v_genotype_2.push_back(v_genotype.at(ii));

		pcPart1->vSetGenotype(&v_genotype_1);
		pcPart2->vSetGenotype(&v_genotype_2);
	}//if  (pcRandomGen->NextDouble()  <  dCutProb)
	else
	{
		*piReturnedPartsNumber  =  1;
		*pcPart1  =  *this;
	}//else  if  (pcRandomGen->NextDouble()  <  dCutProb)

	return(c_err);
}//CError  CMessyIndividual::eCut(double  dCutProb,  CMessyIndividual  **pcPart1,  CMessyIndividual  **pcPart2)




void  CMessyIndividual::vMutateRemGene(double  dProbMutRemGene)
{
	if  ((int) v_genotype.size()  <=  0)  return;

	if  (dRand()  <  dProbMutRemGene)
	{
		vRemoveRandomGene();
	}//if  (pcRandomGen->NextDouble()  <  dProbMutRemGene)
}//void  CMessyIndividual::vMutateRemGene(double  dProbMutRemGene,  gcroot<Random*> pcRandomGen)




void  CMessyIndividual::vRemoveRandomGene()
{
	int  i_removed_gene;

	i_removed_gene  =  lRand(v_genotype.size());//pcRandomGen->Next(0, v_genotype.size());

	delete  v_genotype.at(i_removed_gene);
	v_genotype.erase(v_genotype.begin()  +  i_removed_gene);

	/*CString  s_buf;
	FILE  *pf_test;
	pf_test  =  fopen("D:\\test.txt", "w+");
	s_buf.Format("%d / %d", i_removed_gene, v_genotype.size());
	fprintf(pf_test,  s_buf);
	fclose(pf_test);*/

//	b_effective_fenotype_actual  =  false;
	b_fenotype_actual  =  false;
}//void  CMessyIndividual::vRemoveRandomGene()



void  CMessyIndividual::vMutate
	(
	CNETsimulator  *pcNetSim,
	CVirtualWay  **pcCompetetiveTemplate,
	long  *plCapacities,
	double  dProbMut,  long *plStartFinishPairs, CVirtualWayDatabase  *pcVirtualWays
	)
{
	if  ((int) v_genotype.size()  <=  0)  return;

	if  (dRand()  <  dProbMut)
	{
		int  i_mutated_gene;

		i_mutated_gene  =  lRand(v_genotype.size());//pcRandomGen->Next(0, v_genotype.size());


		int  i_buf;
		long  *pl_buf;
		long  l_conn_set_result;
		
		i_buf  =  pcCompetetiveTemplate[v_genotype.at(i_mutated_gene)->i_gene_pos]->iGetWay(&pl_buf);
		l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[v_genotype.at(i_mutated_gene)->i_gene_pos] * (-1) );


		pcVirtualWays->bGet2VirtualWaysWithLowLevelFOM
			(
			pcNetSim,
			plStartFinishPairs[v_genotype.at(i_mutated_gene)->i_gene_pos * 2],
			plStartFinishPairs[v_genotype.at(i_mutated_gene)->i_gene_pos * 2 + 1],
			&(v_genotype.at(i_mutated_gene)->pc_gene_val)
			);

		l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[v_genotype.at(i_mutated_gene)->i_gene_pos]);


		/*v_genotype.at(i_mutated_gene)->pc_gene_val  =  
			pcVirtualWays->pcGetVirtualWay
				(
				plStartFinishPairs[v_genotype.at(i_mutated_gene)->i_gene_pos * 2],
				plStartFinishPairs[v_genotype.at(i_mutated_gene)->i_gene_pos * 2 + 1]
				);*/


//		b_effective_fenotype_actual  =  false;
		b_fenotype_actual  =  false;			
	}//if  (pcRandomGen->NextDouble()  <  dProbMutRemGene)

}//void  CMessyIndividual::vMutate(double  dProbMut,  gcroot<Random*> pcRandomGen)




void  CMessyIndividual::vMutateAddGene(double  dProbMutAddGene,  int  iTemplLength, long *plStartFinishPairs, CVirtualWayDatabase  *pcVirtualWays)
{
	if  (dRand()  <  dProbMutAddGene)
	{
		int  i_gene_pos;
		CVirtualWay  *pc_gene_val;
		
		i_gene_pos = lRand(iTemplLength);

		pc_gene_val  =  
			pcVirtualWays->pcGetVirtualWay
				(
				plStartFinishPairs[i_gene_pos * 2],
				plStartFinishPairs[i_gene_pos * 2 + 1]
				);

		v_genotype.push_back(new  CMessyGene(pc_gene_val, i_gene_pos));
				
				
//		b_effective_fenotype_actual  =  false;
		b_fenotype_actual  =  false;
	}//if  (pcRandomGen->NextDouble()  <  dProbMutRemGene)
}//void  CMessyIndividual::vMutateAddGene(double  dProbMutAddGene,  gcroot<Random*> pcRandomGen)





void  CMessyIndividual::vLowLevelMutate
	(
	long *plStartFinishPairs, CVirtualWayDatabase  *pcVirtualWays, 
	CVirtualWay  **pcCompetetiveTemplate, 
	CNETsimulator  *pcNetSim,
	long  *plCapacities
	)
{
	if  (v_genotype.size()  <=  0)  return;

	v_create_fenotype();
	CVirtualWay  *pc_mutated_v_way;
	CVirtualWay  *pc_child1,  *pc_child2;


	//first we pick up which part of species is to be crossed
	int  i_mutated_gene;


	i_mutated_gene  =  lRand(i_effective_fenotype_length);//i_mutated_gene = (int)  lRand( (int) v_genotype.size());

	pcCompetetiveTemplate[i_mutated_gene]->iMutate
		(
		&pc_mutated_v_way,
		pcVirtualWays
		);
	/*v_genotype.at(i_mutated_gene)->pc_gene_val->iMutate
		(
		&pc_mutated_v_way,
		pcVirtualWays
		);*/


	CMessyGene  *pc_new_gene = new CMessyGene(pc_mutated_v_way, i_mutated_gene /*v_genotype.at(i_mutated_gene)->i_gene_pos*/);
	v_genotype.push_back(pc_new_gene);
	b_fenotype_actual = false;

	return;
}//void  CMessyIndividual::vLowLevelMutate(int  iTemplLength, long *plStartFinishPairs, CVirtualWayDatabase  *pcVirtualWays)





void  CMessyIndividual::vLowLevelCross
	(
	long *plStartFinishPairs, CVirtualWayDatabase  *pcVirtualWays, 
	CVirtualWay  **pcCompetetiveTemplate, 
	CNETsimulator  *pcNetSim,
	long  *plCapacities
	)
{
	CVirtualWay  *pc_mother_v_way,  *pc_father_v_way;
	CVirtualWay  *pc_child1,  *pc_child2;


	if  (v_genotype.size()  <=  0)  return;

	v_create_fenotype();

	//first we pick up which part of species is to be crossed
	int  i_crossed_pair_number;

	i_crossed_pair_number  =  lRand(i_effective_fenotype_length);//v_genotype.at( (int)  lRand( (int) v_genotype.size()) )->i_gene_pos;

	//we take off the mutated connection
	int  i_buf;
	long  *pl_buf;
	long  l_conn_set_result;

	for  (int  ii = 0; ii < i_effective_fenotype_length; ii++)
	{
		if ( (pc_fenotype[ii]  !=  NULL)&&(pc_fenotype[ii]  !=  pcCompetetiveTemplate[ii]) )
		{
			i_buf  =  pcCompetetiveTemplate[ii]->iGetWay(&pl_buf);
			l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] * (-1) );


			i_buf  =  pc_fenotype[ii]->iGetWay(&pl_buf);
			l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] );

		}//if (pc_fenotype[ii]  !=  NULL)
	}//for  (int  ii = 0; ii < i_fenotype_length; ii++)
	
	i_buf  =  pcCompetetiveTemplate[i_crossed_pair_number]->iGetWay(&pl_buf);//pc_fenotype[i_crossed_pair_number]->iGetWay(&pl_buf);
	l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_crossed_pair_number] * (-1) );
	

	//now we find mother and father
	pcVirtualWays->bGet2VirtualWaysWithLowLevelFOM
		(
		pcNetSim,
		plStartFinishPairs[i_crossed_pair_number * 2],
		plStartFinishPairs[i_crossed_pair_number * 2 + 1],
		&pc_mother_v_way,
		&pc_father_v_way
		);

	l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[i_crossed_pair_number] );

	for  (int  ii = 0; ii < i_effective_fenotype_length; ii++)
	{

		if ( (pc_fenotype[ii]  !=  NULL)&&(pc_fenotype[ii]  !=  pcCompetetiveTemplate[ii]) )
		{
			i_buf  =  pc_fenotype[ii]->iGetWay(&pl_buf);
			l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] * (-1) );

			i_buf  =  pcCompetetiveTemplate[ii]->iGetWay(&pl_buf);
			l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] );

		}//if (pc_fenotype[ii]  !=  NULL)	
	
	}//for  (int  ii = 0; ii < i_fenotype_length; ii++)

	
	//for crossing we use fathers enviroment of the net
	if  (
		pc_mother_v_way->iCross
			(
			pc_father_v_way, &pc_child1,  &pc_child2, 
			pcVirtualWays, pcNetSim
			)
		==
		1
		)
	{
		double  d_child1_fom, d_child2_fom;
		d_child1_fom  =  pc_child1->dCountFOM(pcNetSim);
		d_child2_fom  =  pc_child2->dCountFOM(pcNetSim);

		if  (dRand()  <  d_child1_fom / (d_child1_fom + d_child2_fom) )
		{
			CMessyGene  *pc_new_gene = new CMessyGene(pc_child1, i_crossed_pair_number);
			v_genotype.push_back(pc_new_gene);
			b_fenotype_actual = false;

			return;
		}//if  (dRand()  <  d_child1_fom / (d_child1_fom + d_child2_fom) )
		else
		{
			CMessyGene  *pc_new_gene = new CMessyGene(pc_child2, i_crossed_pair_number);
			v_genotype.push_back(pc_new_gene);
			b_fenotype_actual = false;

			return;
		}//else  if  (dRand()  <  d_child1_fom / (d_child1_fom + d_child2_fom) )
		
	}//if


	return;
}//void  CMessyIndividual::vLowLevelCross(int  iTemplLength, long *plStartFinishPairs, CVirtualWayDatabase  *pcVirtualWays)





void  CMessyIndividual::operator=(CMessyIndividual  &cOther)
{
	vSetGenotype(&cOther.v_genotype);

	i_fenotype_length  =  cOther.i_fenotype_length;

	if  (cOther.b_fenotype_actual  ==  true)
	{
		b_fenotype_actual  =  true;
		for  (int  ii = 0;  ii < i_effective_fenotype_length;  ii++)
			pc_fenotype[ii]  =  cOther.pc_fenotype[ii];

		d_fitness_penalized  =  cOther.d_fitness_penalized;
		d_fitness_pure  =  cOther.d_fitness_pure;
		d_penalty_pure  =  cOther.d_penalty_pure;
	}//if  (pcOther->b_fenotype_actual  ==  true)
	else
		b_fenotype_actual  =  false;


}//void  CMessyIndividual::operator=(CMessyIndividual  *pcOther)




bool  CMessyIndividual::bCompareFenotypes(CMessyIndividual  *pcOther)
{
	v_create_fenotype();
	pcOther->v_create_fenotype();

	if  (i_fenotype_length  !=  pcOther->i_fenotype_length)  return(false);

	for  (int  ii = 0; ii < i_effective_fenotype_length;  ii++)
		if  (pc_fenotype[ii]  !=  pcOther->pc_fenotype[ii])  return(false);

	return(true);
}//bool  CMessyIndividual::bCompareFenotypes(CMessyIndividual  *pcOther)



int  CMessyIndividual::iCompareAlles(CMessyIndividual  *pcOther)
{
	v_create_fenotype();
	pcOther->v_create_fenotype();

	if  (i_fenotype_length  !=  pcOther->i_fenotype_length)  return(-1);

	int  i_result  =  0;
	for  (int  ii = 0; ii < i_effective_fenotype_length;  ii++)
	{
		if  (
			(pc_fenotype[ii]  !=  NULL)&&(pcOther->pc_fenotype[ii] != NULL)
			)
			i_result++;

	}//for  (int  ii = 0; ii < i_effective_fenotype_length;  ii++)
		

	return(i_result);
}//int  CMessyIndividual::iCompareAlles(CMessyIndividual  *pcOther)




CError  CMessyIndividual::eReport(FILE  *pfReport, bool  bTemplate)
{
	CError  c_err;

	v_create_fenotype();
	/*if  (bTemplate  ==  true)
		fprintf(pfReport,  "length:%d\n", i_fenotype_length);

	for  (int  ii = 0; ii < (int) v_genotype.size();  ii++)
		fprintf(pfReport,  "\t%d", v_genotype.at(ii)->i_gene_pos);

	if  (bTemplate  ==  false)
	{
		fprintf(pfReport,  "\n");
		for  (int  ii = 0; ii < (int) v_genotype.size();  ii++)
			fprintf(pfReport,  "\t%d", v_genotype.at(ii)->pc_gene_val->iId);
	}//if  (bTemplate  ==  false)*/



	fprintf(pfReport,  "\n");
	for  (int  ii = 0; ii < i_effective_fenotype_length;  ii++)
	{
		if  (bTemplate  ==  true)
		{
			if  (pc_fenotype[ii]  ==  NULL)
				fprintf(pfReport,  "\t*");
			else
				fprintf(pfReport,  "\t1");
		}//if  (bTemplate  ==  true)
		else
		{
			if  (pc_fenotype[ii]  ==  NULL)
				fprintf(pfReport,  "\t*");
			else
				fprintf(pfReport,  "\t%d", pc_fenotype[ii]->iId);
		}//else if  (bTemplate  ==  true)
	}//for  (int  ii = 0; ii < i_fenotype_length;  ii++)

	return(c_err);
}//CError  CMessyIndividual::eReport(FILE  *pfReport)



CError  CMessyIndividual::eReport
	(
	FILE  *pfReport,
	CVirtualWay  **piCompetetiveTemplate,  
	CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty,
	CNETsimulator  *pcNetSim
	)
{
	CError  c_err;
	dComputeFitness(piCompetetiveTemplate, pcFOMcounter, plCapacities, lPenalty, pcNetSim, VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED);

	for  (int  ii = 0; ii < (int) v_genotype.size();  ii++)
		fprintf(pfReport,  "\t%d", v_genotype.at(ii)->i_gene_pos);

	fprintf(pfReport,  "\n");
	for  (int  ii = 0; ii < (int) v_genotype.size();  ii++)
		fprintf(pfReport,  "\t%d", v_genotype.at(ii)->pc_gene_val);

	fprintf(pfReport,  "\n");
	for  (int  ii = 0; ii < i_effective_fenotype_length;  ii++)
		fprintf(pfReport,  "\t%d", pc_effective_fenotype[ii]);

	fprintf(pfReport,  "\n");
	fprintf(pfReport,  "Fitness: %.4lf",  dComputeFitness(piCompetetiveTemplate, pcFOMcounter, plCapacities, lPenalty, pcNetSim, VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED));
	fprintf(pfReport,  "\n");

	return(c_err);
}//CError  CMessyIndividual::eReport(FILE  *pfReport)



void  CMessyIndividual::v_create_fenotype()
{
	if  (b_fenotype_actual  ==  true)  return;


	for  (int  ii = 0;  ii < i_effective_fenotype_length;  ii++)
		pc_fenotype[ii]  =  NULL;

	for  (int  ii = 0;  ii < (int) v_genotype.size();  ii++)
	{
		if  (v_genotype.at(ii)->i_gene_pos  >=  i_effective_fenotype_length)
		{
			CError  c_err;
			CString  s_buf;
			s_buf.Format("Gene pos: %d Length: %d", v_genotype.at(ii)->i_gene_pos, i_effective_fenotype_length);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
		}//if  (v_genotype.at(ii)->i_gene_pos  >=  i_effective_fenotype_length)

		pc_fenotype[v_genotype.at(ii)->i_gene_pos]  =  v_genotype.at(ii)->pc_gene_val;
	}//for  (int  ii = 0;  ii < (int) v_genotype.size();  ii++)

	i_fenotype_length  =  0;
	for  (int  ii = 0;  ii < i_effective_fenotype_length;  ii++)
		if  (pc_fenotype[ii]  !=  NULL)  i_fenotype_length++;

	b_fenotype_actual  =  true;
}//void  CMessyIndividual::v_create_fenotype()


int  CMessyIndividual::iGetFenotypeLength()
{
	v_create_fenotype();
	return(i_fenotype_length);
}//int  CMessyIndividual::iGetFenotypeLength()



void  CMessyIndividual::v_create_effective_fenotype(CVirtualWay  **pcCompetetiveTemplate)
{
//	if  (b_effective_fenotype_actual  ==  true)  return;


	for  (int  ii = 0;  ii < i_effective_fenotype_length;  ii++)
	{
		if  (pc_fenotype[ii]  !=  NULL)
			pc_effective_fenotype[ii]  =  pc_fenotype[ii];
		else
			pc_effective_fenotype[ii]  =  pcCompetetiveTemplate[ii];	
	}//for  (int  ii = 0;  ii < i_fenotype_length;  ii++)

//	b_effective_fenotype_actual  =  true;
}//void  CMessyIndividual::v_create_effecive_fenotype(int  *piCompetetiveTemplate)



void  CMessyIndividual::vShowFenotypeDiffr(CVirtualWay  **pcCompetetiveTemplate, CString  sReportFileName)
{
	FILE *pf_buf;

	pf_buf = fopen(sReportFileName, "w+");

	int  *pi_differences;
	pi_differences = new  int[i_effective_fenotype_length];
	for  (int  ii = 0;  ii < i_effective_fenotype_length;  ii++)
		pi_differences[ii] = -1;


	for  (int  ii = 0;  ii < (int) v_genotype.size();  ii++)
	{
		if  (
			pc_fenotype[v_genotype.at(ii)->i_gene_pos]  ==  pcCompetetiveTemplate[v_genotype.at(ii)->i_gene_pos]
			)
		{
			pi_differences[v_genotype.at(ii)->i_gene_pos] = 0;
		}//if  (
		else
			pi_differences[v_genotype.at(ii)->i_gene_pos] = 1;

	}//for  (int  ii = 0;  ii < (int) v_genotype.size();  ii++)


	for  (int  ii = 0;  ii < i_effective_fenotype_length;  ii++)
	{
		if  (pi_differences[ii] ==  -1)
			fprintf(pf_buf,  "%.4d \t * \n", ii);

		if  (pi_differences[ii] ==  0)
			fprintf(pf_buf,  "%.4d \t = \n", ii);

		if  (pi_differences[ii] ==  1)
			fprintf(pf_buf,  "%.4d \t <> \n", ii);

	}//for  (int  ii = 0;  ii < i_effective_fenotype_length;  ii++)


	delete  pi_differences;

	fclose(pf_buf);
}//void  CMessyIndividual::vShowFenotypeDiffr(CVirtualWay  **pcCompetetiveTemplate, CString  sReportFileName)



void  CMessyIndividual::vRemoveUnimportantGenes(CVirtualWay  **pcCompetetiveTemplate)
{
	//v_create_fenotype();

	for  (int  ii = 0;  ii < (int) v_genotype.size();  ii++)
	{
		if  (
			pc_fenotype[v_genotype.at(ii)->i_gene_pos]  ==  pcCompetetiveTemplate[v_genotype.at(ii)->i_gene_pos]
			)
		{
			delete  v_genotype.at(ii);
			v_genotype.erase(v_genotype.begin()  +  ii);
			ii--;
//			b_effective_fenotype_actual  =  false;
			b_fenotype_actual  =  false;

			//pc_fenotype[v_genotype.at(ii)->i_gene_pos]  =  NULL;
		}//if  (
	}//for  (int  ii = 0;  ii < (int) v_genotype.size();  ii++)

}//void  CMessyIndividual::vRemoveUnimportantGenes(int  *piCompetetiveTemplate)



double  CMessyIndividual::dComputeFitness(CVirtualWay  **pcCompetetiveTemplate,  CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty, CNETsimulator  *pcNetSim, int iParentSelection)
{
	//if  (b_effective_fenotype_actual  ==  true)  return(d_fitness);


	if  (b_fenotype_actual  ==  true)  return(d_fitness_penalized);
	/*if  (b_fenotype_actual  ==  true)
	{
		v_create_effective_fenotype(pcCompetetiveTemplate);
		pcFitness->eGetFuncValue(pi_effective_fenotype,  i_effective_fenotype_length, &d_fitness);
		return(d_fitness);
	}//if  (b_fenotype_actual  ==  true)*/

	//if none of the structures is actual...
	v_create_fenotype();
	//v_create_effective_fenotype(pcCompetetiveTemplate);


	int  i_buf;
	long  *pl_buf;
	long  l_conn_set_result;

	bool  b_buf;

	/*FILE  *pf_buf;
	d_fitness  =  pcFOMcounter->dCountFOM(pcNetSim, lPenalty,  &b_buf);
	pf_buf  =  fopen("D:\\zz_0.txt", "w+");
	pcNetSim->vPresentNetwork(pf_buf, true);
	fprintf(pf_buf, "\n%.16lf", d_fitness);
	fclose(pf_buf);*/


	/*pcNetSim->iRemoveAllConnections();
	for  (int  ii = 0; ii < i_effective_fenotype_length; ii++)
	{
		if ( (pc_fenotype[ii]  !=  NULL)&&(pc_fenotype[ii]  !=  pcCompetetiveTemplate[ii]) )
		{
			i_buf  =  pc_fenotype[ii]->iGetWay(&pl_buf);
			l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] );
		}//if (pc_fenotype[ii]  !=  NULL)
		else
		{
			i_buf  =  pcCompetetiveTemplate[ii]->iGetWay(&pl_buf);
			l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] );		
		}
	
	}//for  (int  ii = 0; ii < i_fenotype_length; ii++)

	

	d_fitness  =  pcFOMcounter->dCountFOM(pcNetSim, lPenalty,  &b_buf);*/


	/*pf_buf  =  fopen("D:\\zz_1.txt", "w+");
	pcNetSim->vPresentNetwork(pf_buf, true);
	fprintf(pf_buf, "\n%.16lf", d_fitness);
	fclose(pf_buf);*/
	
	

	if  (TSF_PEACH == 1)
	{
		for  (int  ii = 0; ii < i_effective_fenotype_length; ii++)
		{
			if ( (pc_fenotype[ii]  !=  NULL)&&(pc_fenotype[ii]  !=  pcCompetetiveTemplate[ii]) )
			{
				i_buf  =  pcCompetetiveTemplate[ii]->iGetWay(&pl_buf);
				l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] * (-1) );


				i_buf  =  pc_fenotype[ii]->iGetWay(&pl_buf);
				l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] );

			}//if (pc_fenotype[ii]  !=  NULL)

		
		}//for  (int  ii = 0; ii < i_fenotype_length; ii++)

		

		d_fitness_penalized  =  pcFOMcounter->dCountFOM(pcNetSim, lPenalty,  &b_buf, &d_fitness_pure, &d_penalty_pure);
		//d_fitness_pure = d_fitness_penalized - d_penalty_pure;

		CString  s_buf;
		//s_buf.Format("fit: %.16lf 1/fit:%.16lf  pure: %.16lf  penalty: %.16lf", d_fitness_penalized, 1.0/d_fitness_penalized, d_fitness_pure, d_penalty_pure);
		//::MessageBox(NULL, s_buf, s_buf, MB_OK);



		/*pf_buf  =  fopen("D:\\zz_2.txt", "w+");
		pcNetSim->vPresentNetwork(pf_buf, true);
		fprintf(pf_buf, "\n%.16lf", d_fitness);
		fclose(pf_buf);*/
		
		

		for  (int  ii = 0; ii < i_effective_fenotype_length; ii++)
		{

			if ( (pc_fenotype[ii]  !=  NULL)&&(pc_fenotype[ii]  !=  pcCompetetiveTemplate[ii]) )
			{
				i_buf  =  pc_fenotype[ii]->iGetWay(&pl_buf);
				l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] * (-1) );

				i_buf  =  pcCompetetiveTemplate[ii]->iGetWay(&pl_buf);
				l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] );

			}//if (pc_fenotype[ii]  !=  NULL)	
		
		}//for  (int  ii = 0; ii < i_fenotype_length; ii++)


		/*pf_buf  =  fopen("D:\\zz_3.txt", "w+");
		d_fitness  =  pcFOMcounter->dCountFOM(pcNetSim, lPenalty,  &b_buf);
		pcNetSim->vPresentNetwork(pf_buf, true);
		fprintf(pf_buf, "\n%.16lf", d_fitness);
		fclose(pf_buf);


		::MessageBox(NULL, "ok", "", MB_OK);*/
	
	}//if  (TSF_PEACH == 1)
	else
	{
		pcNetSim->iRemoveAllConnections();
		for  (int  ii = 0; ii < i_effective_fenotype_length; ii++)
		{
			if ( (pc_fenotype[ii]  !=  NULL)&&(pc_fenotype[ii]  !=  pcCompetetiveTemplate[ii]) )
			{
				i_buf  =  pc_fenotype[ii]->iGetWay(&pl_buf);
				l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] );			
			}//if ( (pc_fenotype[ii]  !=  NULL)&&(pc_fenotype[ii]  !=  pcCompetetiveTemplate[ii]) )
			else
			{
				i_buf  =  pcCompetetiveTemplate[ii]->iGetWay(&pl_buf);
				l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] );
			}//else  if ( (pc_fenotype[ii]  !=  NULL)&&(pc_fenotype[ii]  !=  pcCompetetiveTemplate[ii]) )
			
		}//for  (int  ii = 0; ii < i_fenotype_length; ii++)	

		d_fitness_penalized  =  pcFOMcounter->dCountFOM(pcNetSim, lPenalty,  &b_buf, &d_fitness_pure, &d_penalty_pure);
		//d_fitness_pure = d_fitness_penalized - d_penalty_pure;


		pcNetSim->iRemoveAllConnections();

		for  (int  ii = 0; ii < i_effective_fenotype_length; ii++)
		{
			i_buf  =  pcCompetetiveTemplate[ii]->iGetWay(&pl_buf);
			l_conn_set_result  =  pcNetSim->lSetUpConnection(pl_buf, i_buf, plCapacities[ii] );
		}//for  (int  ii = 0; ii < i_fenotype_length; ii++)	
	}//else  if  (TSF_PEACH == 1)

	

	return(d_fitness_penalized);
}//double  CMessyIndividual::dComputeFitness(int  *piCompetetiveTemplate,  CDecFunc  *pcFitness)




double  CMessyIndividual::dGetPatternEntrophyFittnes(int  *piGeneFreqTable)
{
	double  d_fit;
	
	d_fit  =  0;
	for  (int  ii = 0;  ii  <  (int) v_genotype.size(); ii++)
	{
		d_fit  +=  piGeneFreqTable[v_genotype.at(ii)->i_gene_pos];
	}//for  (int  ii = 0;  ii  <  (int) pc_buf->pvGetGenotype()->size(); ii++)

	d_fit  =  d_fit  /  v_genotype.size();

	return(d_fit);
}//int  CMessyIndividual::iGetPatternEntrophyFittnes(int  *piGeneFreqTable)



double  CMessyIndividual::dGetRankingWeighted(vector<double> *pvObjective, vector<double> *pvPenalty, double dWeight, double  *pdObjective, double  *pdPenalty)
{
	double d_ranking_objective, d_ranking_penalty, d_ranking_weighted;

	d_ranking_objective = dGetRankingObjective(pvObjective);
	d_ranking_penalty = dGetRankingPenalty(pvPenalty);

	d_ranking_weighted = d_ranking_objective * dWeight  +  d_ranking_penalty * (1.0 - dWeight);

	*pdObjective = d_ranking_objective;
	*pdPenalty = d_ranking_penalty;
	return(d_ranking_weighted);
}//double  CMessyIndividual::dGetRankingWeighted(vector<double> *pvObjective, vector<double> *pvPenalty, double dWeight)



double  CMessyIndividual::dGetRankingObjective(vector<double> *pvObjective)
{
	return(pvObjective->size() - d_get_ranking(pvObjective, d_fitness_pure));
}//double  CMessyIndividual::dGetRankingObjective(vector<double> *pvObjective)

double  CMessyIndividual::dGetRankingPenalty(vector<double> *pvPenalty)
{
	return(d_get_ranking(pvPenalty, d_penalty_pure));
}//double  CMessyIndividual::dGetRankingPenalty(vector<double> *pvPenalty)


double  CMessyIndividual::d_get_ranking(vector<double> *pvRanks, double  dValue)
{
	for  (int ii = 0; ii< pvRanks->size(); ii++)
	{
		if  (pvRanks->at(ii) <= dValue)  return(ii);
	}//for  (int ii = 0; ii< pvRanks->size(); ii++)

	return(pvRanks->size());
}//double  CMessyIndividual::d_get_ranking(vector<double> *pvRanks, double  dValue)


//---------------------------class  CMessyPattern--------------------------------------
bool bPatternGreater (CMessyPattern *elem1, CMessyPattern *elem2)
{
	return elem1->iGetMultiple() > elem2->iGetMultiple();
}


CMessyPattern::CMessyPattern(int  iFenotypeLength)  : CMessyIndividual(iFenotypeLength)
{
	i_pattern_multiple  =  1;
	i_old  =  0;
};//CMessyPattern::CMessyPattern(int  iFenotypeLength)  : CMessyIndividual(iFenotypeLength)
		

CMessyPattern::~CMessyPattern()
{

}//CMessyPattern::~CMessyPattern()



void  CMessyPattern::operator=(CMessyIndividual  &cMessyIndiv)
{
	CMessyIndividual  *pc_this_buf;

	pc_this_buf  =  (CMessyIndividual *)  this;

	*pc_this_buf  =  cMessyIndiv;
}//void  CMessyPattern::operator=(CMessyIndividual  &cMessyIndiv)




void  CMessyPattern::operator=(CMessyPattern  &cOther)
{
	CMessyIndividual  *pc_this_buf,   *pc_other_buf;

	pc_this_buf  =  (CMessyIndividual *)  this;
	pc_other_buf  =  (CMessyIndividual *)  &cOther;

	*pc_this_buf  =  *pc_other_buf;

	i_pattern_multiple  =  cOther.i_pattern_multiple;
	i_old  =  cOther.i_old;
}//void  CMessyPattern::operator=(CMessyIndividual  &cMessyIndiv)



CError  CMessyPattern::eReport(FILE  *pfReport,  bool  bTemplate  /*=  false*/)
{
	CError  c_err;
	fprintf(pfReport,  "multiple:%d\nold:%d\n",  i_pattern_multiple,  i_old);

	c_err  =  ((CMessyIndividual *) this)->eReport(pfReport,  bTemplate);
	return(c_err);
}//CError  CMessyPattern::eReport(FILE  *pfReport,  bool  bTemplate  =  false)



CError  CMessyPattern::eReportSimple(FILE  *pfReport)
{
	CError  c_err;

	
	fprintf(pfReport,  "%d/%d\n", pvGetGenotype()->size(), i_effective_fenotype_length);

	return(c_err);
}//CError  CMessyPattern::eReport(FILE  *pfReport,  bool  bTemplate  =  false)




CError  CMessyPattern::eReport
	(
	FILE  *pfReport,
	CVirtualWay  **piCompetetiveTemplate,  
	CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty,
	CNETsimulator  *pcNetSim
	)
{
	CError  c_err;
	fprintf(pfReport,  "multiple:%d\nold:%d\n",  i_pattern_multiple,  i_old);

	c_err  =  ((CMessyIndividual *) this)->eReport
		(
		pfReport, piCompetetiveTemplate,  
		pcFOMcounter, plCapacities,  lPenalty,
		pcNetSim
		);
	return(c_err);
}//CError  CMessyPattern::eReport








//-------------------------------------------------------------------------------------------
//--------------------------implementation of class CVirtualWayDatabase--------------------------



CVirtualWayDatabase::CVirtualWayDatabase()
{

	pc_virtual_ways_sets  =  NULL;
	l_number_of_nodes  =  0;

}//CVirtualWayDatabase::CVirtualWayDatabase()





CVirtualWayDatabase::~CVirtualWayDatabase()
{


	if  (pc_virtual_ways_sets  !=  NULL)
	{

		for  (long  li = 0; li < l_number_of_nodes; li++)
			delete  []  pc_virtual_ways_sets[li];

		delete  [] pc_virtual_ways_sets;
	
	}//if  (pl_virtual_ways  !=  NULL)



}//CVirtualWayDatabase::CVirtualWayDatabase()










/*
returned values:
1  -  ok
0  -  file not found
-1 -  unexpected end of file
-2 -  memory allocation problems
-3 -  node creation unsuccessfull
*/
int  CVirtualWayDatabase::iLoadVirtualWays
	(CString  sFileName, CTopologyTranslator *pcTranslator,  bool  bTranslate)
{


	FILE  *pf_source;

	long  l_number_of_ways;


	pc_translator  =  pcTranslator;


	
	pf_source  =  fopen( (LPCSTR)  sFileName, "r+");
	if  (pf_source  ==  NULL)  return(0);



	if  (feof(pf_source)  ==  0)
		fscanf(pf_source,"%ld", &l_number_of_ways);
	else
		return(10);



	l_number_of_nodes  =  pcTranslator->lGetNumberOfNodes();




	pc_virtual_ways_sets  =  new  CVirtualWaysSingleSet* [l_number_of_nodes];

	if  (pc_virtual_ways_sets  ==  NULL)
	{
		fclose(pf_source);
		return(-2);
	}//if  (pc_virtual_ways_sets  ==  NULL)


	long  li;
	for  (li = 0; li < l_number_of_nodes; li++)
	{

		pc_virtual_ways_sets[li]  =  new  CVirtualWaysSingleSet[l_number_of_nodes];


		if  (pc_virtual_ways_sets[li]  ==  NULL)
		{

			for  (long  lj = 0;  lj < li; lj++)
				delete  []  pc_virtual_ways_sets[lj];

			delete  []  pc_virtual_ways_sets;

			fclose(pf_source);

			return(-2);
		
		}//if  (pc_virtual_ways_sets[li]  ==  NULL)
		
	}//for  (li = 0; li < l_number_of_nodes; li++)





	//from this point we start to read the data in...
	long  l_start_node, l_finish_node;
	int   i_buf;
	for  (li = 0; li < l_number_of_ways; li++)
	{

		//read one set of virtual ways
		if  (feof(pf_source)  ==  0)
			fscanf(pf_source,"%ld", &l_start_node);
		else
			return(-1);

		if  (feof(pf_source)  ==  0)
			fscanf(pf_source,"%ld", &l_finish_node);
		else
			return(-1);


		if  (bTranslate  ==  true)
		{
			i_buf  =
				pc_virtual_ways_sets
				[pcTranslator->lTranslateNodeNum(l_start_node)]
				[pcTranslator->lTranslateNodeNum(l_finish_node)]
				.iLoadVirtualWays(pf_source, pcTranslator,  bTranslate);
		}//if  (bTranslate  ==  true)
		else
		{
			i_buf  =
				pc_virtual_ways_sets
				[l_start_node]
				[l_finish_node]
				.iLoadVirtualWays(pf_source, pcTranslator,  bTranslate);		
		}//else  if  (bTranslate  ==  true)

		if  (i_buf  !=  1)
		{

		//	printf("result:%d start:%ld  finish:%ld\n\n", i_buf, l_start_node, l_finish_node);

			fclose(pf_source);
			return(i_buf);
		}//if  (i_buf  !=  1)

	
	}//for  (li = 0; li < l_number_of_ways; li++)




	fclose(pf_source);



	return(1);

}//int  CVirtualWayDatabase::iLoadVirtualWays(CString  sFileName, CTopologyTranslator *pcTranslator)










/*
returned values:
1  -  ok
0  -  couldn't create file
*/
int  CVirtualWayDatabase::iCreateReportFile(CString  sFileName)
{

	FILE  *pf_report;

	
	pf_report  =  fopen( (LPCSTR) sFileName, "w+");
	if  (pf_report  ==  NULL)  return(0);
	


	long  li,lj;
	for  (li = 0; li < l_number_of_nodes; li++)
	{
		for  (lj = 0; lj < l_number_of_nodes; lj++)
		{

			//we create an information only if the start is not the end (in this situatiuon it's sensless)
			if  (li  !=  lj)
			{
				fprintf(pf_report,"\n\n");
				fprintf(pf_report,"%ld\n", li);
				fprintf(pf_report,"%ld\n", lj);

				pc_virtual_ways_sets[li][lj].vCreateReportFile(pf_report);
				
			}//if  (li  !=  lj)
					
		}//for  (lj = 0; lj < l_number_of_nodes; lj++)
	
	}//for  (li = 0; li < l_number_of_nodes; li++)
	



	fclose(pf_report);

	return(1);

}//void  CVirtualWayDatabase::vCreateConnectionFile(CString  sFileName)








/*
returned values:
1  -  ok
0  -  couldn't create file
-1 -  memory allocation problems
*/
int  CVirtualWayDatabase::iCreateStatisticsReportFile(CString  sFileName)
{

	FILE  *pf_report;
	long  li,lj;
	int  ii;

	
	pf_report  =  fopen( (LPCSTR) sFileName, "w+");
	if  (pf_report  ==  NULL)  return(0);
	
	fprintf(pf_report,"Statistical report file for a created virtual way database.\n\n\n");


	//counting the number of virt ways in the database and for specified lengths
	long  *pl_way_num_accumulator,  *pl_way_num_buf,  *pl_buf;
	int  i_tab_len,  i_buf;
	long  l_total_way_counter = 0;

	pl_way_num_accumulator  =  NULL;
	i_tab_len  =  0;
		
	for  (li = 0; li < l_number_of_nodes; li++)
	{
		for  (lj = 0; lj < l_number_of_nodes; lj++)
		{
			l_total_way_counter  +=
				pc_virtual_ways_sets[li][lj].lGetNumberOfWays(&pl_way_num_buf,&i_buf);

			if  (i_buf  >  i_tab_len)
			{
				//first we allocate new table of the proper length
				pl_buf  =  new  long[i_buf];
				if  (pl_buf  ==  NULL)
				{
					if  (pl_way_num_accumulator  !=  NULL)  delete  []  pl_way_num_accumulator;
					if  (pl_way_num_buf  !=  NULL)  delete  []  pl_way_num_buf;
					return(-1);
				}//if  (pl_buf  ==  NULL)

				//second we rewrite the way num values and delete the main table
				if  (pl_way_num_accumulator  !=  NULL)
				{
					for  (ii = 0; ii < i_buf; ii++)
						pl_buf[ii]  =  0;

					for  (ii = 0; ii < i_tab_len; ii++)
						pl_buf[ii]  =  pl_way_num_accumulator[ii];
					
					delete  []  pl_way_num_accumulator;
				}//if  (pl_way_num_accumulator  !=  NULL)
				else
				{
					for  (ii = 0; ii < i_buf; ii++)
						pl_buf[ii]  =  0;
				}//else  if  (pl_way_num_accumulator  !=  NULL)

				pl_way_num_accumulator  =  pl_buf;
				i_tab_len  =  i_buf;
			
			}//if  (i_buf  >  i_tab_len)

			for  (ii = 0; ii < i_buf; ii++)
				pl_way_num_accumulator[ii]  +=  pl_way_num_buf[ii];

			if  (pl_way_num_buf  !=  NULL)  
				delete  []  pl_way_num_buf;

		}//for  (lj = 0; lj < l_number_of_nodes; lj++)
	}//for  (li = 0; li < l_number_of_nodes; li++)


	fprintf(pf_report,"Total path number in the database:%ld\n",  l_total_way_counter);
	fprintf(pf_report,"\n\n\nGENERAL numbers of ways of a specified lengths:\n\n");
	for  (ii = 0; ii < i_tab_len; ii++)
	{
		fprintf(pf_report,"The number of ways of %d length: %ld\n",
			ii,  pl_way_num_accumulator[ii]);
	}//for  (ii = 0; ii < i_tab_len; ii++)

	delete  []  pl_way_num_accumulator;



	//now we generate the apriopriate report for every nodes pair
	for  (li = 0; li < l_number_of_nodes; li++)
	{
		for  (lj = 0; lj < l_number_of_nodes; lj++)
		{

			if  (li  !=  lj)
			{
				
				l_total_way_counter  =
					pc_virtual_ways_sets[li][lj].lGetNumberOfWays(&pl_way_num_buf,&i_buf);

				fprintf(pf_report,"Nodes pair: %ld - %ld\n", li, lj);
				fprintf(pf_report,"Total path number for the pair:%ld\n",  l_total_way_counter);
				fprintf(pf_report,"\nGENERAL numbers of ways of a specified lengths:\n");

				for  (ii = 0; ii < i_buf; ii++)
				{
					fprintf(pf_report,"The number of ways of %d length: %ld\n",
						ii,  pl_way_num_buf[ii]);
				}//if  (li  !=  lj)

				if  (pl_way_num_buf  !=  NULL)  delete  []  pl_way_num_buf;

				fprintf(pf_report,"\n\n");

			}//if  (li  !=  lj)
		
		}//for  (lj = 0; lj < l_number_of_nodes; lj++)
	}//for  (li = 0; li < l_number_of_nodes; li++)
	




	fclose(pf_report);

	return(1);

}//void  CVirtualWayDatabase::vCreateConnectionFile(CString  sFileName)













CVirtualWay*  CVirtualWayDatabase::pcGetVirtualWay(long  lStartNode, long lFinishNode, bool  bTranslated)
{

	if  (bTranslated  ==  false)
		return
			(
			pc_virtual_ways_sets
			[pc_translator->lTranslateNodeNum(lStartNode)]
			[pc_translator->lTranslateNodeNum(lFinishNode)].pcGetVirtualWay()
			);
	else
		return
			(
			pc_virtual_ways_sets
			[lStartNode]
			[lFinishNode].pcGetVirtualWay()
			);

}//CVirtualWay*  CVirtualWayDatabase::pcGetVirtualWay(long  lStartNode, long lFinishNode)




bool  CVirtualWayDatabase::bGet2VirtualWaysWithLowLevelFOM
	(
	CNETsimulator  *pcNetSim,  long  lStartNode, long lFinishNode, 
	CVirtualWay  **pcMother,  CVirtualWay  **pcFather,
	bool  bTranslated
	)
{
	if  (bTranslated  ==  false)
		return
			(
			pc_virtual_ways_sets
			[pc_translator->lTranslateNodeNum(lStartNode)]
			[pc_translator->lTranslateNodeNum(lFinishNode)].bGet2VirtualWaysWithLowLevelFOM
				(
				pcNetSim,
				pcMother,  pcFather
				)
			);
	else
		return
			(
			pc_virtual_ways_sets
			[lStartNode]
			[lFinishNode].bGet2VirtualWaysWithLowLevelFOM
				(
				pcNetSim,
				pcMother,  pcFather
				)
			);

}//CVirtualWay*  CVirtualWayDatabase::pcGetVirtualWay(long  lStartNode, long lFinishNode)






/*
returned values:
1  -  ok
0  -  memory allocation problems
-1 -  wrong start node number
*/
int   CVirtualWayDatabase::iCloneVirtualWays(long lStartNode)
{

	CMyList  ***pc_new_ways;


	if  (
		(lStartNode  !=  -1)&&
			( (lStartNode < 0)||(lStartNode >= l_number_of_nodes) )
		)
		return(-1);



	//now we create a new virtual ways database
	pc_new_ways  =  new  CMyList** [l_number_of_nodes];
	if  (pc_new_ways  ==  NULL)  return(0);

	long  li,lj;
	for  (li = 0; li < l_number_of_nodes; li++)
	{

		pc_new_ways[li]  =  new  CMyList* [l_number_of_nodes];

		if  (pc_new_ways[li]  ==  NULL)
		{

			for  (lj = 0; lj < li; lj++)
				delete  []  pc_new_ways[lj];

			delete  [] pc_new_ways;

			return(0);		

		}//if  (pc_new_ways[li]  =  NULL)
	
	}//for  (long  li = 0; li < l_number_of_nodes; li++)


	
	//now for all of the poniters we allocate the list
	for  (li = 0; li < l_number_of_nodes; li++)
	{

		for  (lj = 0; lj < l_number_of_nodes; lj++)
		{

			pc_new_ways[li][lj]  =  new  CMyList;

			if  (pc_new_ways[li][lj]  ==  NULL)
			{

				for  (long  lx = 0; lx < lj; lx++)
					delete  pc_new_ways[li][lx];

				for  (long  ly = 0; ly < li; ly++)
					for  (long  lx = 0; lx < l_number_of_nodes; lx++)
						delete  pc_new_ways[ly][lx];

				
				for  (long lx = 0; lx < l_number_of_nodes; lx++)
					delete  [] pc_new_ways[lx];

				delete  [] pc_new_ways;


				return(0);
			
			}//if  (pc_new_ways[li][lj]  ==  NULL)
		
		}//for  (lj = 0; lj < l_number_of_nodes; lj++)
	
	}//for  (li = 0; li < l_number_of_nodes; li++)

	



	//now we clone all ways we have
	CMyList  *pc_list1;
	CMyList  *pc_list2;
	long  lk;

	//this if-construction is not the best one because the only diffrence is in li but it was the easiest one to carry up
	if  (lStartNode  ==  -1)
	{
		for  (li = 0; li < l_number_of_nodes; li++)
		{

			for  (lj = 0; lj < l_number_of_nodes; lj++)
			{

				if  (li != lj)
				{
					pc_list1  =  &(pc_virtual_ways_sets[li][lj].c_virtual_ways);

					for  (lk = 0; lk < l_number_of_nodes; lk++)
					{  
						if  ( (lk != li)&&(lk != lj) )
						{

							pc_list2  =  &(pc_virtual_ways_sets[lj][lk].c_virtual_ways);

							i_clone_two_lists(pc_list1, pc_list2,  pc_new_ways[li][lk] );
						
						}//if  ( (lk != li)&&(lk != lj) )
					
					}//for  (lk = 0; lk < l_number_of_nodes; lk++)
				
				}//if  (li != lj)
			
			}//for  (lj = 0; lj < l_number_of_nodes; lj++)
		
		}//for  (li = 0; li < l_number_of_nodes; li++)
	}//if  (lStartNode  !=  -1)
	else
	{
		li = lStartNode;
		
			for  (lj = 0; lj < l_number_of_nodes; lj++)
			{

				if  (li != lj)
				{
					pc_list1  =  &(pc_virtual_ways_sets[li][lj].c_virtual_ways);

					for  (lk = 0; lk < l_number_of_nodes; lk++)
					{  
						if  ( (lk != li)&&(lk != lj) )
						{

							pc_list2  =  &(pc_virtual_ways_sets[lj][lk].c_virtual_ways);

							i_clone_two_lists(pc_list1, pc_list2,  pc_new_ways[li][lk] );
						
						}//if  ( (lk != li)&&(lk != lj) )
					
					}//for  (lk = 0; lk < l_number_of_nodes; lk++)
				
				}//if  (li != lj)
			
			}//for  (lj = 0; lj < l_number_of_nodes; lj++)
					
	}//else  if  (lStartNode  !=  -1)



	

	//now for all lists we try to input them into the virtual way database
	for  (li = 0; li < l_number_of_nodes; li++)
	{

		for  (lj = 0; lj < l_number_of_nodes; lj++)
		{

			if  (pc_new_ways[li][lj]->bFirst()  ==  true)
			{

				for  (lk = 0; lk < pc_new_ways[li][lj]->lGetCapacity(); lk++)
				{
					if  
						(
						pc_virtual_ways_sets[li][lj].iInputNewVirtWay
						(
						(CVirtualWay *)  pc_new_ways[li][lj]->pcGetNode()->pvGetObject(),
						pc_translator
						)
						!=  1
						)
					{
						//if the way was not inputted we MUST destroy if
						delete  (CVirtualWay *)  pc_new_ways[li][lj]->pcGetNode()->pvGetObject();
						//printf("One not inptutted\n");
					}//if
					/*else
						printf("One inptutted\n");*/

					pc_new_ways[li][lj]->bNext();

				}//for  (lk = 0; lk < pc_new_ways[li][lj].lGetCapacity(); lk++)
							
			}//if  (pc_new_way[li][lj].bFirst()  ==  true)


		}//for  (lj = 0; lj < l_number_of_nodes; lj++)

	}//for  (li = 0; li < l_number_of_nodes; li++)




	//now we destroy the lists
	for  (li = 0; li < l_number_of_nodes; li++)
		for  (lj = 0; lj < l_number_of_nodes; lj++)
			delete  pc_new_ways[li][lj];

	for  (li = 0; li < l_number_of_nodes; li++)
		delete  pc_new_ways[li];

	delete  pc_new_ways;



	return(1);
}//int   CVirtualWayDatabase::iCloneVirtualWays(int iNumberOfRepetations, long lStartNode = -1)
	





/*
1  -  ok
0  -  memory allocation problems
*/
int  CVirtualWayDatabase::i_clone_two_lists(CMyList  *pcStartList,  CMyList  *pcFinishList,  CMyList  *pcDestList)
{

	if  (pcStartList->bFirst()  ==  false)  return(1);
	if  (pcFinishList->bFirst()  ==  false)  return(1);



	CVirtualWay  *pc_mother, *pc_father, *pc_child;
	long  *pl_mother_way,  *pl_father_way,  *pl_child_way;
	int   i_mother_length,  i_father_length,  i_child_length;
	long  li,lj,lk;
	
	for  (li = 0;  li < pcStartList->lGetCapacity(); li++)
	{

		pc_mother  =  (CVirtualWay*)  pcStartList->pcGetNode()->pvGetObject();
		i_mother_length  =  pc_mother->iGetWay(&pl_mother_way);

		for  (lj = 0;  lj < pcFinishList->lGetCapacity(); lj++)
		{

			pc_father  =  (CVirtualWay*)  pcFinishList->pcGetNode()->pvGetObject();
			i_father_length  =  pc_father->iGetWay(&pl_father_way);


			pc_child  =  new  CVirtualWay;
			if  (pc_child  ==  NULL)  return(0);

			i_child_length  =  i_mother_length + i_father_length - 1;
			pl_child_way  =  new  long[i_child_length];

			if  (pl_child_way  ==  NULL)
			{
				delete  pc_child;
				return(0);			
			}//if  (pl_child_way  ==  NULL)

			//now rewrite the way
			for  (lk = 0; lk < i_mother_length; lk++)
			{
				pl_child_way[lk]  = pl_mother_way[lk];
			//	printf("child way[%ld]: %ld (mother part)\n",lk,pl_mother_way[lk]);
			}//for  (lk = 0; lk < i_mother_length; lk++)

			for  (lk = 0; lk < i_father_length; lk++)
			{
				pl_child_way[i_mother_length - 1 + lk]  = pl_father_way[lk];
			//	printf("child way[%ld]: %ld (father part)\n",lk,pl_father_way[lk]);
			}//for  (lk = 0; lk < i_father_length; lk++)

			
			if  (pc_child->bSetWay(pl_child_way, i_child_length)  ==  false)
			{
				delete  pc_child;
				delete  [] pl_child_way;
				return(0);
			}//if  (pc_child->bSetWay(pl_child_way, i_child_way_length)  == false)


			if  (pcDestList->bAdd(pc_child)  ==  false)
			{
				delete  pc_child;
				delete  [] pl_child_way;
				return(0);			
			}//if  (pcDestList->bAdd(pc_child)  ==  false)

			
			delete  [] pl_child_way;
		
			pcFinishList->bNext();

		}//for  (lj = 0;  pcFinishList->lGetCapacity(); lj++)


		pcStartList->bNext();
	
	}//for  (li = 0;  pcStartList->lGetCapacity(); li++)



	return(1);

}//int  CVirtualWayDatabase::i_clone_two_lists(CMyList  *pcStartList,  CMyList  *pcFinishList,  CMyList  *pcDestList)






/*
returned values:
1  -  ok
0  -  
-1 -  wrong start node
-2 -  wrong finish node
*/
int   CVirtualWayDatabase::iInputNewVirtWay
		(CVirtualWay  *pcNewWay,  long  lStartNode,  long  lFinishNode,
		CVirtualWay  **pcTheSameWayAsNew, bool bTranslated)//**pcTheSameWayAsNew is used for returning an addres of the way that is the same in the database)
{

	if  (bTranslated  ==  false)
		return(
			i_input_new_virt_way
			(pcNewWay,  
			pc_translator->lTranslateNodeNum(lStartNode),
			pc_translator->lTranslateNodeNum(lFinishNode),
			pcTheSameWayAsNew
			)
			);
	else
		return(
			i_input_new_virt_way
			(pcNewWay,  
			lStartNode,
			lFinishNode,
			pcTheSameWayAsNew
			)
			);

}//int   CVirtualWayDatabase::iInputNewVirtWay








/*
returned values:
1  -  ok
0  -  
-1 -  wrong start node
-2 -  wrong finish node
-3 -  virtual ways database is missing
*/
int   CVirtualWayDatabase::i_input_new_virt_way
		(CVirtualWay  *pcNewWay,  long  lTranslatedStartNode,  long  lTranslatedFinishNode,
		CVirtualWay  **pcTheSameWayAsNew)//**pcTheSameWayAsNew is used for returning an addres of the way that is the same in the database)
{

	long  *pl_way;
	int  i_way_length;

	i_way_length  =  pcNewWay->iGetWay(&pl_way);

	//now we check the start and finish node if they are not proper we retrun an error
	if  (pl_way[0]  !=  lTranslatedStartNode)  return(-1);
	if  (pl_way[i_way_length - 1]  !=  lTranslatedFinishNode)  return(-2);





	if  (pc_virtual_ways_sets  ==  NULL)  return(-3);
		





	return
		(
		pc_virtual_ways_sets
		[lTranslatedStartNode]
		[lTranslatedFinishNode].iInputNewVirtWay(pcNewWay, pc_translator,pcTheSameWayAsNew)
		);

}//int   CVirtualWayDatabase::iInputNewVirtWay













//-------------------------------------------------------------------------------------------
//--------------------------implementation of class CVirtualWaysSingleSet--------------------------

CVirtualWaysSingleSet::CVirtualWaysSingleSet()
{

}//CVirtualWaysSingleSet::CVirtualWaysSingleSet()







CVirtualWaysSingleSet::~CVirtualWaysSingleSet()
{

	c_virtual_ways.bFirst();

	for  (long  li = 0; li < c_virtual_ways.lGetCapacity(); li++)
	{

		delete  ((CVirtualWay *)  c_virtual_ways.pcGetNode()->pvGetObject());


		c_virtual_ways.bNext();
	
	}//for  (long  li = 0; li < c_virtual_ways.lGetCapacity(); li++)


	c_virtual_ways.vBYE(false);

}//CVirtualWaysSingleSet::~CVirtualWaysSingleSet()






/*
returned  values:
1  -  ok
-1 -  number of ways below 0
-2 -  unexpected end of file
-3 -  error creating the virtual way
-4 -  insertion into list unsuccessfull
-5 -  virtual way not apropriate for a given topology
*/
int  CVirtualWaysSingleSet::iLoadVirtualWays
		(FILE  *pfSource, CTopologyTranslator *pcTranslator,  bool  bTranslate)
{

	long  l_number_of_ways;

	
	if  (feof(pfSource)  ==  0)
		fscanf(pfSource,"%ld", &l_number_of_ways);
	else
		return(-2);

	
	if  (l_number_of_ways  <  0)  return(-1);




	CVirtualWay  *pc_virt_way;

	for  (long  li = 0; li < l_number_of_ways; li++)
	{

		pc_virt_way  =  new  CVirtualWay;

		if  (pc_virt_way  ==  NULL)  return(-2);
		if  (pc_virt_way->iLoadWay(pfSource, pcTranslator, bTranslate)  !=  1)  return(-3);


		if  (iInputNewVirtWay(pc_virt_way,  pcTranslator)  !=  1)  
		{
			delete  pc_virt_way;
			return(-4);
		}//if  (iInputNewVirtWay(pc_virt_way,  pcTranslator)  !=  1)  

	}//for  (long  li = 0; li < l_number_of_ways; li++)


	return(1);

}//int  CVirtualWaysSingleSet::iLoadVirtualWays







/*
returned values:
2  -  virtual way already exists in the database ()
1  -  ok
0  -  bad way
-3 -  memory allocation problems
*/
int  CVirtualWaysSingleSet::iInputNewVirtWay
	(CVirtualWay  *pcNewWay,  CTopologyTranslator  *pcTranslator,
	 CVirtualWay  **pcTheSameWayAsNew)//**pcTheSameWayAsNew is used for returning an addres of the way that is the same in the database
{

	//first we check if the way is correct from topography simulator point of view
	long  *pl_way;
	int  i_way_length;

	i_way_length  =  pcNewWay->iGetWay(&pl_way);


	if  (pcTranslator->iCheckConnection(pl_way, i_way_length,0 , false)  !=  1)  return(0);


	
	//now we check if we don't have this way already in the topology
	if  (c_virtual_ways.bFirst()  ==  true)
	{

		for  (long  li = 0; li < c_virtual_ways.lGetCapacity(); li++)
		{
			
			if  (  
				*((CVirtualWay *)  c_virtual_ways.pcGetNode()->pvGetObject())
				==
				*pcNewWay
				)
			{

				//we return the same way only if we have a given buffer for that
				if  (pcTheSameWayAsNew  !=  NULL)
					*pcTheSameWayAsNew  =  (CVirtualWay *)  c_virtual_ways.pcGetNode()->pvGetObject();

				return(2);
			
			}//if

			c_virtual_ways.bNext();
		}//for  (long  li = 0; li < c_virtual_ways.lGetCapacity(); li++)

	
	}//if  (c_virtual_ways.bFirst()  ==  true)
	
	if  (c_virtual_ways.bAdd(pcNewWay)  ==  false)  return(-3);

	pcNewWay->iId  =  c_virtual_ways.lGetCapacity();





	return(1);

}//int  CVirtualWaysSingleSet::iInputNewVirtWay(CVirtualWay  *pcNewWay)








CVirtualWay*  CVirtualWaysSingleSet::pcGetVirtualWay()
{
	

	if  (c_virtual_ways.bSetPos(lRand(c_virtual_ways.lGetCapacity()) + 1)  ==  false)
		return(NULL);

	return((CVirtualWay *)  c_virtual_ways.pcGetNode()->pvGetObject());
  

}//CVirtualWay*  CVirtualWaysSingleSet::pcGetVirtualWay()





bool  CVirtualWaysSingleSet::bGet2VirtualWaysWithLowLevelFOM
	(
	CNETsimulator  *pcNetSim, 
	CVirtualWay  **pcMother,  CVirtualWay  **pcFather,  
	bool  bTranslated
	)
{

	double  *pd_pop_fom;

	pd_pop_fom  =  new  double[c_virtual_ways.lGetCapacity()];
	if  (pd_pop_fom  ==  NULL)  return(false);

	
	//first we compute the whole "population" fom
	double  d_pop_fom, d_specie_fom;
	CVirtualWay  *pc_vw_buf;
	

	c_virtual_ways.bFirst();
	d_pop_fom  =  0;

	long  li;
	for  (li = 0; li < c_virtual_ways.lGetCapacity(); li++)
	{

		pc_vw_buf  =  (CVirtualWay *)  c_virtual_ways.pcGetNode()->pvGetObject();

		d_specie_fom  =  pc_vw_buf->dCountFOM(pcNetSim);
		

		d_pop_fom  +=  d_specie_fom;
		pd_pop_fom[li]  =  d_specie_fom;

		c_virtual_ways.bNext();
	}//for  (long  li = 0; li < c_virtual_ways.lGetCapacity(); li++)


	

	//mother
	double  d_rand  =  dRand();
	d_rand  *=  d_pop_fom;


	double  d_sum = 0;
	bool  b_found  =  false;

	c_virtual_ways.bFirst();
	for  (li = 0; (li < c_virtual_ways.lGetCapacity())&&(b_found  == false); li++)
	{
		d_sum  +=  pd_pop_fom[li];
		if (d_sum  >  d_rand)
		{
			*pcMother  =  (CVirtualWay *)  c_virtual_ways.pcGetNode()->pvGetObject();
			b_found  =  true;
		}//if (d_sum  >  d_rand)
	
	}//for  (li = 0; li < c_virtual_ways.lGetCapacity(); li++)
	
	if  (b_found  ==  false)
	{
		c_virtual_ways.bLast();
		*pcMother  =  (CVirtualWay *)  c_virtual_ways.pcGetNode()->pvGetObject();
	}//if  (b_found  ==  false)


	if  (pcFather  ==  NULL)
	{
		c_virtual_ways.bFirst();
		delete  []  pd_pop_fom;
		return(true);
	}//if  (pcFather  ==  NULL)

	//father
	d_rand  =  dRand();
	d_rand  *=  d_pop_fom;

	d_sum = 0;
	b_found  =  false;

	c_virtual_ways.bFirst();
	for  (li = 0; (li < c_virtual_ways.lGetCapacity())&&(b_found  == false); li++)
	{
		d_sum  +=  pd_pop_fom[li];
		if (d_sum  >  d_rand)
		{
			*pcFather  =  (CVirtualWay *)  c_virtual_ways.pcGetNode()->pvGetObject();
			b_found  =  true;
		}//if (d_sum  >  d_rand)
	
	}//for  (li = 0; li < c_virtual_ways.lGetCapacity(); li++)

	if  (b_found  ==  false)
	{
		c_virtual_ways.bLast();
		*pcFather  =  (CVirtualWay *)  c_virtual_ways.pcGetNode()->pvGetObject();
	}//if  (b_found  ==  false)

	c_virtual_ways.bFirst();
	delete  []  pd_pop_fom;
	return(true);
}//void  CVirtualWaysSingleSet::vGet2VirtualWaysWithLowLevelFOM







void  CVirtualWaysSingleSet::vCreateReportFile(FILE  *pfReport)
{

	fprintf(pfReport,"%ld\n", c_virtual_ways.lGetCapacity());


	c_virtual_ways.bFirst();



	for  (long  li = 0; li < c_virtual_ways.lGetCapacity(); li++)
	{

		((CVirtualWay *)  c_virtual_ways.pcGetNode()->pvGetObject())->vCreateReportFile(pfReport);

		fprintf(pfReport,"\n");

		c_virtual_ways.bNext();
	
	}//for  (long  li = 0; li < c_virtual_ways.lGetCapacity(); li++)

	
}//int  CVirtualWaysSingleSet::iCreateConnectionFile(FILE  *pfDest)



/*
returns a number of virtual ways in the set. 
If plLengthSets  ==  NULL the only answer will be the above
returned values:
0 or more  -  ok
-1  -  memory allocation problems
-2  -  unexpected trajectory length (this error shouldn't occur)
*/
long  CVirtualWaysSingleSet::lGetNumberOfWays(long  **plLengthSets, int *piTableLen)
{

	if  (plLengthSets  ==  NULL)  return(c_virtual_ways.lGetCapacity());
	

	//searching for the longest virual way
	int  i_longest_way_len = 0;
	long  *pl_buf;

	c_virtual_ways.bFirst();
	for (long li = 0; li < c_virtual_ways.lGetCapacity(); li++)
	{
		if  ( 
			((CVirtualWay *) c_virtual_ways.pvGetObject())->iGetWay(&pl_buf)
			>
			i_longest_way_len
			)
			i_longest_way_len
			=
			((CVirtualWay *) c_virtual_ways.pvGetObject())->iGetWay(&pl_buf);

		c_virtual_ways.bNext();
	
	}//for (long li = 0; li < c_virtual_ways.lGetCapacity(); li++)


	if  (i_longest_way_len  ==  0)
	{
		*plLengthSets  =  NULL;
		*piTableLen  =  0;
		return(0);
	}//if  (i_longest_way_len  ==  0)


	//now we create a proper table for statistical information
	*plLengthSets  =  new  long[(i_longest_way_len - 1)/2];
	if  (*plLengthSets  ==  NULL)
	{
		*piTableLen  =  0;
		return(-1);	
	}//if  (*plLengthSets  ==  NULL)
	*piTableLen  =  (i_longest_way_len - 1) / 2;

	//now preparing the table to work
	for  (long  li = 0;  li < (i_longest_way_len - 1) / 2;  li++)
		(*plLengthSets)[li]  =  0;
		


	//now we input the proper nubers of ways into the returned table
	int  i_len_buf;
	c_virtual_ways.bFirst();
	for (long  li = 0; li < c_virtual_ways.lGetCapacity(); li++)
	{
		i_len_buf  =  ((CVirtualWay *) c_virtual_ways.pvGetObject())->iGetWay(&pl_buf);

		if  (i_len_buf  >  i_longest_way_len)  return(-2);

		(*plLengthSets)[((i_len_buf - 1) / 2) - 1]++;

		c_virtual_ways.bNext();
	
	}//for (li = 0; li < c_virtual_ways.lGetCapacity(); li++)


	return(c_virtual_ways.lGetCapacity());


}//long  CVirtualWaysSingleSet::lGetNumberOfWays(long  **plLengthSets, int *piTableLen)














//-------------------------------------------------------------------------------------------
//--------------------------implementation of class CVirtualWay--------------------------



CVirtualWay::CVirtualWay()
{

	pl_way  =  NULL;
	i_way_length  =  0;

}//CVirtualWay::CVirtualWay()





CVirtualWay::~CVirtualWay()
{

	if  (pl_way  !=  NULL)
	{

	delete  []  pl_way;

	}//if  (pl_way  !=  NULL)



}//CVirtualWay::~CVirtualWay()



double  CVirtualWay::dCountFOM(CNETsimulator  *pcNetSim)
{
	double  d_specie_fom;
	double  d_buf;

	d_specie_fom  =  0;
	for  (int  ii = 1; ii < i_way_length; ii+=2)
	{
		d_buf  =  pcNetSim->lGetActLinkCapacity(pl_way[ii]);

		if  (d_buf  <  0)
		{
			d_buf  =  d_buf * (-1.0) + 1;
			d_specie_fom  +=  d_buf;
		}//if  (l_buf  <=  0)
		else
		{
			d_buf  +=  1;
			d_buf  *=  d_buf;
			d_specie_fom  +=  1 / d_buf;			
		}//else  if  (l_buf  <=  0)
	
	}//for  (int  ii = 0; ii < i_buf; ii+=2)

	d_specie_fom  =  1.0  /  d_specie_fom;

	return(d_specie_fom);
}//double  CVirtualWay::dCountFOM(CTopologyTranslator  *pcTranslator)



//returns the returned way length
int  CVirtualWay::iGetWay(long  **plWay)
{

	if  (i_way_length  >  0)
	{

		*plWay  =  pl_way;
		return(i_way_length);
	
	}//if  (i_way_length  >  0)


	return(0);

}//int  CVirtualWay::iGetWay(long  **plWay)








bool  CVirtualWay::bSetWay(long  *plNewWay,  int  iNewWayLength)
{

	long  *pl_new_way;


	pl_new_way  =  new  long[iNewWayLength];


	if  (pl_new_way  ==  NULL)  return(false);


	for  (int ii = 0; ii < iNewWayLength; ii++)
		pl_new_way[ii]  =  plNewWay[ii];

	

	if  (pl_way  !=  NULL)
		delete  []  pl_way;


	pl_way  =  pl_new_way;
	i_way_length  =  iNewWayLength;


	v_remove_loops_from_way();


	return(true);



}//bool  CVirtualWay::bSetWay(long  *plNewWay,  int  iNewWayLength)





/*
1  -  ok
0  -  memory allocation problems
-1 -  unable to communicate with other objects
*/
int  CVirtualWay::iCross
	(
	CVirtualWay *pcFather,  CVirtualWay **pcChild1, CVirtualWay **pcChild2,
	CVirtualWayDatabase  *pCVirtualWays,
	CNETsimulator  *pcNetSim
	)
{

	CVirtualWay  *pc_child1,  *pc_child2;

	*pcChild1  =  NULL;
	*pcChild2  =  NULL;


	pc_child1  =  new  CVirtualWay;
	if  (pc_child1  ==  NULL)  return(false);

	pc_child2  =  new  CVirtualWay;
	if  (pc_child2  ==  NULL)
	{
		delete  pc_child1;
		return(0);
	}//if  (pc_child2  ==  NULL)



	//now we extract ways from mother and father virtual way
	long  *pl_mother_way,  *pl_father_way;
	int  i_mother_way_len,  i_father_way_len;


	i_mother_way_len  =  iGetWay(&pl_mother_way);
	i_father_way_len  =  pcFather->iGetWay(&pl_father_way);



	if  ( (i_mother_way_len  ==  0)||(i_father_way_len  ==  0) )
	{

		delete  pc_child1;
		delete  pc_child2;

		return(-1);
	
	}//if  ( (i_mother_way_len  ==  0)||(i_father_way_len  ==  0) )


	
	
	//now when we have extracted all data we cross to way sets

	//first we pick up mother and father crossing point
	int  i_mother_crossing_node;
	int  i_father_crossing_node;


	//we must remeber that way length is inpair and every second number is a link id
	i_mother_crossing_node  =  (int)  lRand( (i_mother_way_len + 1)/2 );
	i_father_crossing_node  =  (int)  lRand( (i_father_way_len + 1)/2 );

	i_mother_crossing_node  *=  2;
	i_father_crossing_node  *=  2;

	
	long  l_mother_cross_node_id;
	long  l_father_cross_node_id;

	l_mother_cross_node_id  =  pl_mother_way[i_mother_crossing_node];
	l_father_cross_node_id  =  pl_father_way[i_father_crossing_node];

	
	
	//now if these two nodes are not the same we must find a a virtual way connecting them both
	CVirtualWay  *pc_moth_fath_way,  *pc_fath_moth_way;
	long  *pl_moth_fath_way,  *pl_fath_moth_way;
	int  i_moth_fath_way_len,  i_fath_moth_way_len;


	if  (l_mother_cross_node_id  !=  l_father_cross_node_id)
	{

		pc_moth_fath_way  =  
			pCVirtualWays->pcGetVirtualWay(l_mother_cross_node_id,l_father_cross_node_id, true);
		pc_fath_moth_way  =  
			pCVirtualWays->pcGetVirtualWay(l_father_cross_node_id,l_mother_cross_node_id, true);
				
				
		i_moth_fath_way_len  =  pc_moth_fath_way->iGetWay(&pl_moth_fath_way);
		i_fath_moth_way_len  =  pc_fath_moth_way->iGetWay(&pl_fath_moth_way);


	}//if  (l_mother_cross_node_id  ==  l_father_cross_node_id)
	else
	{

		i_moth_fath_way_len  =  0;
		i_fath_moth_way_len  =  0;
	
	}//else  if  (l_mother_cross_node_id  !=  l_father_cross_node_id)


	
	
	//now all we have to do is just to glue all pieces together

	long  *pl_child1_way,  *pl_child2_way;
	int  i_child1_way_len,  i_child2_way_len;

	
	if  (i_moth_fath_way_len  >  0)
		i_child1_way_len  =  i_mother_crossing_node + 1
								+
								i_moth_fath_way_len - 1
								+
								i_father_way_len - i_father_crossing_node - 1;
	else
		i_child1_way_len  =  i_mother_crossing_node + 1
								+
								i_father_way_len - i_father_crossing_node - 1;


	pl_child1_way  =  new  long[i_child1_way_len];
	if  (pl_child1_way  ==  NULL)
	{
		delete  pc_child1;
		delete  pc_child2;
	}//if  (pl_child1_way  ==  NULL)




	if  (i_fath_moth_way_len  >  0)
		i_child2_way_len  =  i_father_crossing_node + 1
								+
								i_fath_moth_way_len - 1
								+
								i_mother_way_len - i_mother_crossing_node - 1;
	else
		i_child2_way_len  =  i_father_crossing_node + 1
								+
								i_mother_way_len - i_mother_crossing_node - 1;


	
	pl_child2_way  =  new  long[i_child2_way_len];
	if  (pl_child2_way  ==  NULL)  
	{
		delete  [] pl_child1_way;

		delete  pc_child1;
		delete  pc_child2;
	}//if  (pl_child2_way  ==  NULL)  


	
	//now we fill up the ways
	int  ii, ij, ik;
	for  (ii = 0; ii < i_mother_crossing_node + 1; ii++)
		pl_child1_way[ii]  =  pl_mother_way[ii];
			
	ii--;
	for  (ij = 1; ij < i_moth_fath_way_len; ij++)
		pl_child1_way[ii + ij]  =  pl_moth_fath_way[ij];
	
	ij--;
	for  (ik = 1; ik < i_father_way_len - i_father_crossing_node; ik++)
		pl_child1_way[ii + ij + ik]  =  pl_father_way[ik + i_father_crossing_node];
	
	


	for  (ii = 0; ii < i_father_crossing_node + 1; ii++)
		pl_child2_way[ii]  =  pl_father_way[ii];
	
	ii--;
	for  (ij = 1; ij < i_fath_moth_way_len; ij++)
		pl_child2_way[ii + ij]  =  pl_fath_moth_way[ij];
	
	ij--;
	for  (ik = 1; ik < i_mother_way_len - i_mother_crossing_node; ik++)
		pl_child2_way[ii + ij + ik]  =  pl_mother_way[ik + i_mother_crossing_node];
	
		


	//now we insert the ways into virtual way object
	if  (pc_child1->bSetWay(pl_child1_way, i_child1_way_len)  ==  false)
	{

		delete  [] pl_child1_way;
		delete  [] pl_child2_way;

		delete  pc_child1;
		delete  pc_child2;

		return(-1);
	
	}//if  (pc_child1->bSetWay(pl_child1_way, i_child1_way_len)  ==  false)


	if  (pc_child2->bSetWay(pl_child2_way, i_child2_way_len)  ==  false)
	{

		delete  [] pl_child1_way;
		delete  [] pl_child2_way;

		delete  pc_child1;
		delete  pc_child2;

		return(-1);
	
	}//if  (pc_child2->bSetWay(pl_child2_way, i_child2_way_len)  ==  false)



	//when the ways are inserted we delete them
	delete  [] pl_child1_way;
	delete  [] pl_child2_way;





	//now we try to input the virtual ways into the database
	//if there alredy is the same way we delete currently created and use the older one
	CVirtualWay  *pc_the_same_way;
	int  i_insert_res;

	i_insert_res  =  pCVirtualWays->iInputNewVirtWay(pc_child1, 
		pl_way[0], pl_way[i_way_length - 1],
		&pc_the_same_way, true);

	//if  (i_insert_res == 1) printf("JEST\n");

	//if the created way already exists
	if  (i_insert_res  ==  2)
	{
		*pcChild1  =  pc_the_same_way;
		delete  pc_child1;
	}//if  (i_insert_res  ==  2)

	if  (i_insert_res  ==  1)  *pcChild1  =  pc_child1;
	

	//if the operation was unsuccesful we delete everything and return false
	if  (i_insert_res  <  1)
	{
		delete  pc_child1;
		delete  pc_child2;

		return(-1);

	}//if  (i_insert_res  ==  2)

	
	



	//NOW SECOND CHILD
	i_insert_res  =  pCVirtualWays->iInputNewVirtWay(pc_child2, 
		pl_way[0], pl_way[i_way_length - 1],
		&pc_the_same_way, true);

	//if the created way already exists
	if  (i_insert_res  ==  2)
	{
		*pcChild2  =  pc_the_same_way;
		delete  pc_child2;
	}//if  (i_insert_res  ==  2)

	if  (i_insert_res  ==  1)  *pcChild2  =  pc_child2;

	

	//if the operation was unsuccesful we delete everything and return false
	if  (i_insert_res  <  1)
	{
		//step back with first child
		*pcChild1  =  NULL;
		
		if  (pc_child1  !=  NULL)  delete  pc_child1;
		delete  pc_child2;

		return(-1);

	}//if  (i_insert_res  ==  2)

	
	return(1);

}//int  CVirtualWay::iCross(CVirtualWay *pcFather,  CVirtualWay *pcChild1, CVirtualWay *pcChild2)





/*
returned values:
1  -  ok
0  -  memory allocation problems
-1 -  unable to communicate wuth other objects
*/
int  CVirtualWay::iMutate
	(
	CVirtualWay  **pcNewWay,
	CVirtualWayDatabase  *pCVirtualWays,
	CNETsimulator  *pcNetSim
	)
{
	CVirtualWay  *pc_new_way;

	*pcNewWay  = NULL;
	
	pc_new_way  =  new  CVirtualWay;
	if  (pc_new_way  ==  NULL)  return(0);


	long  *pl_actual_way;
	int  i_actual_way_len;

	i_actual_way_len  =  iGetWay(&pl_actual_way);


	//now we find the start and finish mutation nodes
	int  i_start_mut_node, i_finish_mut_node;

	i_start_mut_node  =  (int)  lRand( (i_actual_way_len + 1)/2 );
	i_finish_mut_node  =  i_start_mut_node;
	while  (i_start_mut_node  ==  i_finish_mut_node)
		i_finish_mut_node  =  (int)  lRand( (i_actual_way_len + 1)/2 );
	

	i_start_mut_node  *=  2;
	i_finish_mut_node  *=  2;

	
	long  l_start_mut_node_id;
	long  l_finish_mut_node_id;

	l_start_mut_node_id  =  pl_actual_way[i_start_mut_node];
	l_finish_mut_node_id  =  pl_actual_way[i_finish_mut_node];
	



	CVirtualWay  *pc_inserted_way;
	long  *pl_inserted_way;
	int  i_inserted_way_len;



	pc_inserted_way  =
		pCVirtualWays->pcGetVirtualWay(l_start_mut_node_id,l_finish_mut_node_id, true);

	i_inserted_way_len  =  pc_inserted_way->iGetWay(&pl_inserted_way);



	int  i_new_way_len;
	long  *pl_new_way;

	i_new_way_len  =  i_start_mut_node + 1
								+
								i_inserted_way_len - 1
								+
								i_actual_way_len - i_finish_mut_node- 1;


	pl_new_way  =  new  long[i_new_way_len];

	if  (pl_new_way  ==  NULL)
	{
		delete  pc_new_way;
		return(0);
	}//if  (pl_new_way  ==  NULL)



	//now we fill up the ways
	int  ii, ij, ik;
	for  (ii = 0; ii < i_start_mut_node + 1; ii++)
		pl_new_way[ii]  =  pl_actual_way[ii];

	ii--;
	for  (ij = 1; ij < i_inserted_way_len; ij++)
		pl_new_way[ii + ij]  =  pl_inserted_way[ij];

	ij--;
	for  (ik = 1; ik < i_actual_way_len - i_finish_mut_node; ik++)
		pl_new_way[ii + ij + ik]  =  pl_actual_way[ik + i_finish_mut_node];



	if  (pc_new_way->bSetWay(pl_new_way,i_new_way_len)  ==  false)
	{
		delete  pc_new_way;
		delete  []  pl_new_way;

		return(-1);	
	}//if  (pc_new_way->bSetWay(pl_new_way,i_new_way_len)  ==  false)


	
	
	//now we cane freely delete the table with new way
	delete  []  pl_new_way;


	
	
	
	
	//now we try to input the virtual ways into the database
	//if there alredy is the same way we delete currently created and use the older one
	CVirtualWay  *pc_the_same_way;
	int  i_insert_res;

	i_insert_res  =  pCVirtualWays->iInputNewVirtWay(pc_new_way, 
		pl_way[0],  pl_way[i_way_length - 1],
		&pc_the_same_way);

	
	//if the created way already exists
	if  (i_insert_res  ==  2)
	{
		*pcNewWay  =  pc_the_same_way;
		delete  pc_new_way;
	}//if  (i_insert_res  ==  2)

	if  (i_insert_res  ==  1)  *pcNewWay  =  pc_new_way;
	

	//if the operation was unsuccesful we delete everything and return false
	if  (i_insert_res  <  1)
	{
		delete  pc_new_way;
		return(i_insert_res);
	}//if  (i_insert_res  ==  2)


	return(1);

}//CVirtualWay  * CVirtualWay::pcMutate(CVirtualWayDatabase  *pCVirtualWays)


/*
returned  values:
1  -  ok
-1 -  number of ways below 0
-2 -  unexpected end of file
-3 -  memory allocation problems
-4 -  bad node number
-5 -  bad link number
-6 -  way setting unsuccessfull
*/
int  CVirtualWay::iLoadWay(FILE  *pfSource, CTopologyTranslator *pcTranslator, bool  bTranslate)
{

	
	int  i_way_length_buf;



	if  (feof(pfSource)  ==  0)
		fscanf(pfSource,"%d", &i_way_length_buf);
	else
		return(-2);


	long  *pl_way_buf;

	pl_way_buf  =  new  long [i_way_length_buf];

	if  (pl_way_buf  ==  NULL)  return(-3);




	long  l_num;

	if  (feof(pfSource)  ==  0)
		fscanf(pfSource,"%ld", &l_num);
	else
		return(-2);


	if  (bTranslate  ==  true)
		pl_way_buf[0]  =  pcTranslator->lTranslateNodeNum(l_num);
	else
		pl_way_buf[0]  =  l_num;




	if  (pl_way_buf[0]  <  0)  
	{
		delete  []  pl_way_buf;
		return(-4);
	}//if  (pl_way_buf[0]  <  0)



	for  (int  ii = 0; ii < (i_way_length_buf - 1) / 2; ii++)
	{

		if  (feof(pfSource)  ==  0)
			fscanf(pfSource,"%ld", &l_num);
		else
		{
			delete  []  pl_way_buf;
			return(-2);
		}//else  if  (feof(pfSource)  ==  0)

		
		if  (bTranslate  ==  true)
			pl_way_buf[ii * 2 + 1]  =  pcTranslator->lTranslateLinkNum(l_num);
		else
			pl_way_buf[ii * 2 + 1]  =  l_num;


		if  (pl_way_buf[ii * 2 + 1]  <  0)  
		{
			delete  []  pl_way_buf;
			return(-5);
		}//if  (pl_way_buf[ii * 2 + 1]  <  0)  



		if  (feof(pfSource)  ==  0)
			fscanf(pfSource,"%ld", &l_num);
		else
		{
			delete  []  pl_way_buf;
			return(-2);
		}//else  if  (feof(pfSource)  ==  0)



		if  (bTranslate  ==  true)
			pl_way_buf[ii * 2 + 2]  =  pcTranslator->lTranslateNodeNum(l_num);
		else
			pl_way_buf[ii * 2 + 2]  =  l_num;



		if  (pl_way_buf[ii * 2 + 2]  <  0)  
		{
			delete  []  pl_way_buf;
			return(-4);
		}//if  (pl_way_buf[ii * 2 + 2]  <  0)  
	
	}//for  (int  ii; ii < i_way_length_buf; ii++)



	if  (bSetWay(pl_way_buf, i_way_length_buf)  ==  false)  
	{
		delete  []  pl_way_buf;
		return(-6);
	}//if  (bSetWay(pl_way_buf, i_way_length_buf)  ==  false)  

	
	//now we must delete the buffer
	delete  []  pl_way_buf;



	return(1);

}//int  CVirtualWay::iLoadWay(FILE  *pfSource, CTopologyTranslator *pcTranslator)











void  CVirtualWay::v_remove_loops_from_way()
{

	for  (int ii = 0; ii < i_way_length;  ii+=2)
	{
		for  (int ij = ii + 2; ij < i_way_length;  ij+=2)
		{

			//if there are 2 the same nodes we cut them everything between them down
			if  (pl_way[ii]  ==  pl_way[ij])
			{

				for  (int  ik = 0;  ij + ik < i_way_length; ik++)
					pl_way[ii + ik]  =  pl_way[ij + ik];

				i_way_length  =  i_way_length  -  (ij - ii);

				ij  =  ii + 2;
			
			}//if  (pl_way[ii]  ==  pl_way[ij])
		
		}//for  (int ij = ii + 2; ij < i_way_length;  ij+=2)
	
	}//for  (int ii = 0; ii < i_way_length;  ii+=2)

}//void  CVirtualWay::v_remove_loops_from_way()











bool  CVirtualWay::operator ==(CVirtualWay  &pcOther)
{

	if  (pcOther.i_way_length  !=  i_way_length)  return(false);

	for  (int ii = 0; ii <  i_way_length; ii++)
		if  (pcOther.pl_way[ii]  !=  pl_way[ii])  return(false);


	return(true);

}//bool  CVirtualWay::operator ==(CVirtualWay  &pcOther)












void   CVirtualWay::vCreateReportFile(FILE  *pfReport)
{

	fprintf(pfReport,"%d",i_way_length);

	for  (int  ii = 0; ii < i_way_length; ii++)
		fprintf(pfReport," %ld",pl_way[ii]);

}//void   CVirtualWay::vCreateReportFile(FILE  *pfReport)










//-------------------------------------------------------------------------------------------
//--------------------------implementation of class CBrainStormSupervisor--------------------------

CBrainStormSupervisor::CBrainStormSupervisor()
{
	pd_actual_pops  =  NULL;
	pd_previous_pops  =  NULL;

	l_num_of_gen_to_avr  =  0;
	i_current_state  =  0;
}//CBrainStormSupervisor::CBrainStormSupervisor()




CBrainStormSupervisor::~CBrainStormSupervisor()
{

	if  (pd_actual_pops  !=  NULL)  delete  []  pd_actual_pops;
	if  (pd_previous_pops  !=  NULL)  delete  []  pd_previous_pops;
	
}//CBrainStormSupervisor::~CBrainStormSupervisor()






bool  CBrainStormSupervisor::bSetUpConfig
		(
		long  lNumOfGenToAvr,
		double  dMinInc,//turn on trigger
		long  lTimeLen,  long  lFinishTime,//full turn on state time and turning off time
		long  lMinBreak//time between tuning off and turning on again
		)
{

	if  (l_num_of_gen_to_avr  ==  0)  return(true);
	
	if  (pd_actual_pops  !=  NULL)  delete  []  pd_actual_pops;
	if  (pd_previous_pops  !=  NULL)  delete  []  pd_previous_pops;
	

	pd_actual_pops  =  new  double[lNumOfGenToAvr];
	if  (pd_actual_pops  ==  NULL)  return(false);

	pd_previous_pops  =  new  double[lNumOfGenToAvr];
	if  (pd_previous_pops  ==  NULL)
	{
		delete  []  pd_actual_pops;
		return(false);
	}//if  (pd_previous_pops  ==  NULL)



	for  (long  li = 0; li < lNumOfGenToAvr; li++)
	{
		pd_actual_pops[li]  =  0;
		pd_previous_pops[li]  =  0;	
	}//for  (long  li = 0; li < lNumOfGenToAvr; li++)
	d_actual_pops_sum  =  0;
	d_previous_pops_sum  =  0;


	
	
	l_num_of_gen_to_avr  =  lNumOfGenToAvr;
	d_min_inc  =  dMinInc;//turn on trigger
	l_time_len  =  lTimeLen;
	l_finish_time  =  lFinishTime;//full turn on state time and turning off time
	l_min_break  =  lMinBreak;//time between tuning off and turning on again
	
	l_actual_gen_counter  =  0;
	i_current_state  =  0;



	return(true);

}//bool  CBrainStormSupervisor::bSetUpConfig





/*
returned  values:
the value that should be added to every creature in the population
*/
double  CBrainStormSupervisor::dGetNextGenerationState(double  dActGenFOM)
{
	if  (l_num_of_gen_to_avr  ==  0)  return(0);
	//now inserting the new value and pushing all others

	d_previous_pops_sum  =  d_previous_pops_sum  -  pd_previous_pops[0];
	long  li;
	for  (li = 0; li < l_num_of_gen_to_avr - 1; li++)
		pd_previous_pops[li]  =  pd_previous_pops[li + 1];
	
	pd_previous_pops[l_num_of_gen_to_avr - 1]  =  pd_actual_pops[0];
	d_previous_pops_sum  =  d_previous_pops_sum  +  pd_actual_pops[0];



	d_actual_pops_sum  =  d_actual_pops_sum  -  pd_actual_pops[0];
	for  (li = 0; li < l_num_of_gen_to_avr - 1; li++)
		pd_actual_pops[li]  =  pd_actual_pops[li + 1];

	pd_actual_pops[l_num_of_gen_to_avr - 1]  =  dActGenFOM;
	d_actual_pops_sum  =  d_actual_pops_sum  +  dActGenFOM;



	//we check wheather not to turn on the "brain storming" if it's off
	if  (i_current_state  ==  0)
	{
		l_actual_gen_counter++;

		//we don't turn on if the break was too small
		if  (l_actual_gen_counter  <  l_min_break)  return(0);

		//now we compute the averages
		double  d_previoud_pops_avr;
		double  d_actual_pops_avr;


		d_previoud_pops_avr  =  d_previous_pops_sum / l_num_of_gen_to_avr;
		d_actual_pops_avr  =  d_actual_pops_sum / l_num_of_gen_to_avr;


		//checking up the turning on trigger
		if  (
			( (d_min_inc / 100) + 1.0 >  d_actual_pops_avr / d_previoud_pops_avr)
			||
			(d_previoud_pops_avr  ==  0)
			)
		{
			l_actual_gen_counter  =  0;
			i_current_state  =  2;//the "turned on" state

			return(0);

		}//if  (d_min_inc + 1.0 <  d_actual_pops_avr / d_previoud_pops_avr)

	}//if  (i_current_state  ==  0)

	
	//the "turning off" state
	if  (i_current_state  ==  1)
	{

		l_actual_gen_counter++;

		double  d_buf;

		d_buf  =  l_finish_time  -  l_actual_gen_counter  +  1;
		d_buf  =  d_buf / l_finish_time;
		d_buf  *=  dActGenFOM;


		//we don't change a state if proper amount 
		if  (l_actual_gen_counter  <  l_finish_time)  
			return(d_buf);
		else
		{
			i_current_state  =  0;
			l_actual_gen_counter  =  0;

			return(d_buf);		
		}//else  if  (l_actual_gen_counter  <=  l_finish_time)
			
	}//if  (i_current_state  ==  1)



	//the "turned on" state
	if  (i_current_state  ==  2)
	{
		l_actual_gen_counter++;

		//we don't go to "turning off" state if the "turned on" is to short
		if  (l_actual_gen_counter  <  l_time_len)  
			return(dActGenFOM);
		else
		{
			i_current_state  =  1;//"turning off" state
			l_actual_gen_counter  =  0;
			return(dActGenFOM);		
		}//else  if  (l_actual_gen_counter  <=  l_time_len)  
		
	
	}//if  (i_current_state  ==  2)

	return(0);
	
}//int  CBrainStormSupervisor::iGetNextGenerationState




//vmga




void  CTrajectorySetsFinder::v_remove_the_same_ct()
{
	for (int  ii = 0; ii < (int) pv_population->size()-1;  ii++)
	{
		for (int  ij = ii+1; ij < (int) pv_population->size();  ij++)
		{
			if  (
				pv_population->at(ii)->bIsTheSame(pv_population->at(ij))
				==  true				
				)
			{
				delete  pv_population->at(ij);
				pv_population->erase(pv_population->begin() + ij);
				ij--;//the next is going to have the offset as we have removed one			
			}//if  (		
		}//for (int  ij = ii+1; ij < (int) pv_population->size();  ij++)	
	}//for (int  ii = 0; ii < (int) pv_population->size();  ii++)
}//void  CTrajectorySetsFinder::v_remove_the_same_ct()



void  CTrajectorySetsFinder::v_remove_all_ct_except_best()
{
	double  d_best = 0;
	int  i_best_offset = 0;

	for (int  ii = 0; ii < (int) pv_population->size();  ii++)
	{
		if  (d_best  <  pv_population->at(ii)->dGetFOMLevel())  
		{
			d_best  =  pv_population->at(ii)->dGetFOMLevel();
			i_best_offset = ii;
		}//if  (d_best  <  pv_population->at(ii)->dGetFOMLevel())  
	}//for (int  ii = 0; ii < (int) pv_population->size()-1;  ii++)

	CString  s_buf;

	//s_buf.Format("best: %.8lf", d_best);
	//::MessageBox(NULL, s_buf, s_buf, MB_OK);
	CSingleTrajectorySet  *pc_best;
	pc_best = pv_population->at(i_best_offset);

	for (int  ii = 0; ii < (int) pv_population->size();  ii++)
	{
		//s_buf.Format("best: %.8lf  actual:%.8lf", d_best, pv_population->at(ii)->dGetFOMLevel());
		//::MessageBox(NULL, s_buf, s_buf, MB_OK);

		if  (ii  !=  i_best_offset)
		{
			delete  pv_population->at(ii);
		}//if  (		
	}//for (int  ii = 0; ii < (int) pv_population->size();  ii++)

	pv_population->clear();
	pv_population->push_back(pc_best);
}//void  CTrajectorySetsFinder::v_remove_the_same_ct()



void  CTrajectorySetsFinder::v_remove_all_ct_except_best_and_remember_and_remove_one_randomly()
{
	double  d_best = 0;
	int  i_best_offset = 0;

	for (int  ii = 0; ii < (int) pv_population->size();  ii++)
	{
		if  (d_best  <  pv_population->at(ii)->dGetFOMLevel())  
		{
			d_best  =  pv_population->at(ii)->dGetFOMLevel();
			i_best_offset = ii;
		}//if  (d_best  <  pv_population->at(ii)->dGetFOMLevel())  
	}//for (int  ii = 0; ii < (int) pv_population->size()-1;  ii++)


	CSingleTrajectorySet  *pc_best;
	pc_best = pv_population->at(i_best_offset);
	

	for (int  ii = 0; ii < (int) pv_population->size();  ii++)
	{
		if  (ii  !=  i_best_offset)
		{
			v_memo_cts.push_back(pv_population->at(ii));
		}//if  (		
	}//for (int  ii = 0; ii < (int) pv_population->size();  ii++)

	if  (v_memo_cts.size() > 0)
	{
		int  i_memo_ct_to_delete;
		i_memo_ct_to_delete  =  lRand(v_memo_cts.size());//pc_random_gen->Next(0,  v_memo_cts.size());

		delete v_memo_cts.at(i_memo_ct_to_delete);	
		v_memo_cts.erase(v_memo_cts.begin() + i_memo_ct_to_delete);
	}//if  (v_memo_cts.size() > 0)


	pv_population->clear();
	pv_population->push_back(pc_best);
}//void  CTrajectorySetsFinder::v_remove_all_ct_except_best_and_remember_and_remove_one_randomly()




void  CTrajectorySetsFinder::v_remove_all_ct_except_best_and_remember()
{
	double  d_best = 0;
	int  i_best_offset = 0;

	for (int  ii = 0; ii < (int) pv_population->size();  ii++)
	{
		if  (d_best  <  pv_population->at(ii)->dGetFOMLevel())  
		{
			d_best  =  pv_population->at(ii)->dGetFOMLevel();
			i_best_offset = ii;
		}//if  (d_best  <  pv_population->at(ii)->dGetFOMLevel())  
	}//for (int  ii = 0; ii < (int) pv_population->size()-1;  ii++)


	CSingleTrajectorySet  *pc_best;
	pc_best = pv_population->at(i_best_offset);
	

	for (int  ii = 0; ii < (int) pv_population->size();  ii++)
	{
		if  (ii  !=  i_best_offset)
		{
			v_memo_cts.push_back(pv_population->at(ii));
		}//if  (		
	}//for (int  ii = 0; ii < (int) pv_population->size();  ii++)

	pv_population->clear();
	pv_population->push_back(pc_best);
}//void  CTrajectorySetsFinder::v_remove_all_ct_except_best_and_remember()



void  CTrajectorySetsFinder::v_add_new_ct(CString  sIniFile, int iCtStrategy)
{
	//if we do not make new cts then there is only 
	//ONE CT that is being used through the whoile time
	if  (iCtStrategy  >  0)
	{
		if  (pv_population->size() >= iCtStrategy)  return;
	}//if  (iNoNewCt  >  0)


	if  ( (iCtStrategy  ==  -3)&&(v_memo_cts.size() > 0) )//memo muppets
	{
		int  i_chosen_ct;
		i_chosen_ct  =  lRand(v_memo_cts.size());//pc_random_gen->Next(0,  v_memo_cts.size());

		v_memo_cts.at(i_chosen_ct)->eVirReGeneratePopulation(this, false);	
		pv_population->push_back(v_memo_cts.at(i_chosen_ct));
		v_memo_cts.erase(v_memo_cts.begin() + i_chosen_ct);
		pv_population->at(pv_population->size()-1)->d_ranking_objective_weight = 0;

		return;
	}//if  ( (i_ct_add_remove_strategy  ==  3)&&(v_memo_cts.size() > 0) )


	if  ( (iCtStrategy  ==  -4)&&(v_memo_cts.size() > 0) )//total memo muppets
	{
		//int  i_chosen_ct;
		//i_chosen_ct  =  lRand(v_memo_cts.size());//pc_random_gen->Next(0,  v_memo_cts.size());

		for  (int  ii = 0; ii < v_memo_cts.size(); ii++)
		{
			v_memo_cts.at(ii)->eVirReGeneratePopulation(this, false);	
			pv_population->push_back(v_memo_cts.at(ii));
		}//for  (int  ii = 0; ii < v_memo_cts.size(); ii++)
		v_memo_cts.clear();
		pv_population->at(pv_population->size()-1)->d_ranking_objective_weight = 0;

		return;
	}//if  ( (i_ct_add_remove_strategy  ==  3)&&(v_memo_cts.size() > 0) )


	if  ( (iCtStrategy  ==  -5)&&(v_memo_cts.size() > 0) )//total memo muppets with exchange
	{
		//int  i_chosen_ct;
		//i_chosen_ct  =  lRand(v_memo_cts.size());//pc_random_gen->Next(0,  v_memo_cts.size());

		for  (int  ii = 0; ii < v_memo_cts.size(); ii++)
		{
			v_memo_cts.at(ii)->eVirReGeneratePopulation(this, false);	
			pv_population->push_back(v_memo_cts.at(ii));
		}//for  (int  ii = 0; ii < v_memo_cts.size(); ii++)
		v_memo_cts.clear();

		//return; NO RETURN WE ADD NEW CT!!!
	}//if  ( (i_ct_add_remove_strategy  ==  3)&&(v_memo_cts.size() > 0) )



	pv_population->push_back(new  CSingleTrajectorySet());
	pv_population->at(pv_population->size()-1)->d_ranking_objective_weight = 0;


	pv_population->at(pv_population->size() - 1)->bInit
			(pl_start_finish_pairs, i_number_of_pairs, &c_virtual_ways, c_translator.pcGetSim(),  c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);


	pv_population->at(pv_population->size() - 1)->eVirConfigure
		(
		b_glue_infection_rows,
		i_virus_gen,  i_virus_pop_size,  d_pop_reduction_juxtapositional,
		d_vir_prob_cut,  d_vir_prob_splice,  d_vir_prob_mut,
		d_prob_mut_rem_gene,  d_prob_mut_add_gene,
		d_prob_low_level_cross, d_prob_low_level_mut,
		d_prob_init_mut
		);

	//if  ( (pv_population->size() ==  1)||(pv_population->size() ==  2) )
	if  (pv_population->size() ==  1)
	{
		pv_population->at(pv_population->size() - 1)->bInit
			(
			pl_start_finish_pairs, i_number_of_pairs, 
			&c_virtual_ways, c_translator.pcGetSim(), 
			c_translator.pcGetFittnesCounter(), 
			pl_capacities, l_penalty
			);



		if  (sIniFile  !=  "")
		{
			CError  c_err;
			int  i_ini_type;

			i_ini_type  =  i_check_header(sIniFile);
			if  (i_ini_type  <=  0)
			{
				c_err.vPutError("Unknown ini file type");
				c_err.vShowWindow();
				return;			
			}//if  (i_ini_type  <=  0)

			FILE  *pf_source;
			pf_source  =  fopen( (LPCSTR)  sIniFile, "r+");
			if  (pf_source  ==  NULL)
			{
				c_err.vPutError("INI file not found or can not be opened");
				c_err.vShowWindow();
				return;			
			}//if  (pf_source  ==  NULL)

			if  (i_ini_type  ==  1)
			{

				if  (
					pv_population->at(pv_population->size() - 1)->iLoadFromOldIniFile(&c_translator,  pf_source,  pl_capacities, true)  
					!=  1
					)  
				{
					c_err.vPutError("Error while reading from ini file");
					c_err.vShowWindow();
					return;			
				}//if  (pc_single_trajectory_set_buf->iLoadFromFile(pf_source,  &c_translator,  bTranslate)  !=  1)  
			}//if  (i_ini_type  ==  1)


			if  (i_ini_type  ==  2)
			{

				if  (
					pv_population->at(pv_population->size() - 1)->iLoadFromIniFile(&c_translator,  pf_source,  pl_capacities, true)
					!=  1
					)  
				{
					c_err.vPutError("Error while reading from ini file");
					c_err.vShowWindow();
					return;
				}//if  (pc_single_trajectory_set_buf->iLoadFromFile(pf_source,  &c_translator,  bTranslate)  !=  1)  
			}//if  (i_ini_type  ==  1)

			pv_population->at(pv_population->size() - 1)->vSaveBestSolutionOnTheRun(this);

		
		}//if  (sIniFile  !=  "")
	
	}//if  (pv_population->size() ==  0)



	if  (pv_population->size() > 1)
	{
		int  i_init_base;

		i_init_base = lRand(pv_population->size() - 1);



		pv_population->at(pv_population->size() - 1)->vCopy(pv_population->at(i_init_base));


		if  (i_new_ct_disturbed_copy == 1)
		{
			//::Tools::vShow("if  (i_new_ct_disturbed_copy == 1)");

			if  (i_new_ct_disturbed_LLDSI == 1)
			{
				pv_population->at(pv_population->size() - 1)->vRandomize_LLDSI(this);
				//::Tools::vShow("if  (i_new_ct_disturbed_LLDSI == 1)");
			}//if  (i_new_ct_disturbed_LLDSI == 1)
			else 
			{
				pv_population->at(pv_population->size() - 1)->vRandomize(pl_capacities, d_new_ct_disturbed_gene_disturbed_prob);
				//::Tools::vShow("else  if  (i_new_ct_disturbed_LLDSI == 1)");
			}//else  if  (i_new_ct_disturbed_LLDSI == 1)
		}//if  (i_new_ct_disturbed_copy == 1)
		else
		{
			pv_population->at(pv_population->size() - 1)->vRandomize(pl_capacities, -1);
			//::Tools::vShow("else  if  (i_new_ct_disturbed_copy == 1)");
		}//else  if  (i_new_ct_disturbed_copy == 1)
	}//if  (pv_population->size() > 1)*/


	pv_population->at(pv_population->size() - 1)->pc_net_sim->iRemoveAllConnections();
	pv_population->at(pv_population->size() - 1)->b_set_all_conns(pl_capacities);
	pv_population->at(pv_population->size() - 1)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);

}//void  CTrajectorySetsFinder::v_add_new_cmga()





CSingleTrajectorySet*  CTrajectorySetsFinder::pc_get_parent_tournament_normal(int  iIndiv1Offset,  int  iIndiv2Offset,  bool  bBetterTakesAll  /*=  false*/)
{
	CSingleTrajectorySet  *pc_candidate_1,  *pc_candidate_2;

	pc_candidate_1  =  pv_population->at(iIndiv1Offset);
	pc_candidate_2  =  pv_population->at(iIndiv2Offset);

	double  d_fit_1,  d_fit_2;

	d_fit_1  =  pc_candidate_1->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);
	d_fit_1  =  Math::Round(d_fit_1, 2);
	d_fit_2  =  pc_candidate_2->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);
	d_fit_2  =  Math::Round(d_fit_2, 2);

	
	if  (bBetterTakesAll  ==  true)
	{
		if  (d_fit_1  >  d_fit_2)  
			return(pc_candidate_1);
		else
			return(pc_candidate_2);
	
	}//if  (bBetterTakesAll  ==  true)
	else
	{
		double  d_fit_sum;
		d_fit_sum  =  d_fit_1  +  d_fit_2;
		d_fit_sum  =  d_fit_sum  *  dRand();

		if  (d_fit_sum  <  d_fit_1)
			return(pc_candidate_1);
		else
			return(pc_candidate_2);	
	}//else  if  (bBetterTakesAll  ==  true)

}//CSingleTrajectorySet*  CTrajectorySetsFinder::pc_get_parent_tournament(int  iIndiv1Offset,  int  iIndiv2Offset,  bool  bBetterTakesAll  /*=  false*/)




CSingleTrajectorySet*  CTrajectorySetsFinder::pc_get_parent_tournament_normal(int  iTournamentSize,  bool  bBetterTakesAll  /*= false*/)
{
	if  (iTournamentSize  ==  2)
	{
		int  i_indiv_1,  i_indiv_2;

		i_indiv_1  =  lRand(pv_population->size());// pc_random_gen->Next(0,  pv_population->size());
		i_indiv_2  =  lRand(pv_population->size());//pc_random_gen->Next(0,  pv_population->size());

		
		while  ( (i_indiv_1  ==  i_indiv_2)&&(pv_population->size()  >  1) )
			i_indiv_2  =  lRand(pv_population->size());//pc_random_gen->Next(0,  pv_population->size());


		return(pc_get_parent_tournament_normal(i_indiv_1,  i_indiv_2,  bBetterTakesAll));
	}//if  (iTournamentSize  ==  2)

	return(NULL);
}//CSingleTrajectorySet*  CTrajectorySetsFinder::pc_get_parent_tournament(int  iTournamentSize,  bool  bBetterTakesAll)





CSingleTrajectorySet*  CTrajectorySetsFinder::pc_get_parent_tournament(bool  bBetterTakesAll  /*=  false*/)
{
//	if  (i_comp_templates_crossing_type  ==  VGA_CT_CROSS_TYPE_NORMAL_SIZE_2)
//	{
		return(pc_get_parent_tournament_normal(2, bBetterTakesAll));
//	}//if  (i_comp_templates_crossing_type  ==  VGA_CT_CROSS_TYPE_NORMAL_SIZE_2)


/*	if  (i_comp_templates_crossing_type  ==  VGA_CT_CROSS_TYPE_NORMAL_SIZE_2_AND_DIFFRENCE_SIZE_3)
	{
		return(pc_get_parent_tournament_normal_and_diffrence(2, 3, d_prob_fit_diffr_tournament, bBetterTakesAll));
	}//if  (i_comp_templates_crossing_type  ==  VGA_CT_CROSS_TYPE_NORMAL_SIZE_2)*/


	return(NULL);
}//CmGA*  CTrajectorySetsFinder::pc_get_parent_tournament(bool  bBetterTakesAll  /*=  false*/)




CSingleTrajectorySet*  CTrajectorySetsFinder::pc_get_parent_tournament_normal_for_pattern_different(CMessyPattern  *pcPattern,  CSingleTrajectorySet  *pcParentTaker)
{
	if  (pv_population  ==  NULL)  return(NULL);
	if  (pcPattern  ==  NULL)  return(pc_get_parent_tournament());

	double  *pd_template_diffr_fitness;
	double  d_diffr_fitness,  d_diffr_fitness_sum;

	pd_template_diffr_fitness  =  new  double[pv_population->size()];

	d_diffr_fitness_sum  =  0;
	for  (int  ii = 0; ii < (int) pv_population->size(); ii++)
	{
		//d_diffr_fitness  =  pcParentTaker->iGetNumberOfDiffrGenes(pcPattern,  pv_population->at(ii));jgjhg
		d_diffr_fitness  =  pcParentTaker->iGetNumberOfDiffrGenesToOtherBest(pcPattern,  pv_population->at(ii));

		
		
		
		//d_diffr_fitness  *=  pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);
		d_diffr_fitness  *=  pv_population->at(ii)->dGetBestResultOnTheRunFitness();

		d_diffr_fitness  =  Math::Round(d_diffr_fitness, 2);

		pd_template_diffr_fitness[ii]  =  d_diffr_fitness;
		d_diffr_fitness_sum  +=  d_diffr_fitness;
	}//for  (int  ii = 0; ii < (int) pv_population->size(); ii++)

	if  (d_diffr_fitness_sum  ==  0)
	{
		delete  []  pd_template_diffr_fitness;	
		return(NULL);
	}//if  (d_diffr_fitness_sum  ==  0)

	double  d_rand, d_buf;
	d_rand  =  dRand()  *  d_diffr_fitness_sum;

	d_buf  =  0;
	for  (int  ii = 0; ii < (int) pv_population->size(); ii++)
	{
		d_buf  +=  pd_template_diffr_fitness[ii];
		
		//found!
		if  (d_buf  >  d_rand)
		{
			delete  []  pd_template_diffr_fitness;
			return(pv_population->at(ii));
		}//if  (d_buf  >  d_rand)
	
	}//for  (int  ii = 0; ii < (int) pv_population->size(); ii++)


	delete  []  pd_template_diffr_fitness;
	return(pv_population->at(pv_population->size() - 1));
}//CmGA*  CTrajectorySetsFinder::pc_get_parent_tournament_normal_for_pattern_different(CMessyPattern  *pcPattern,  CMessyIndividual  *pcParentTaker)





bool  CTrajectorySetsFinder::b_the_same_templates_check(CMessyIndividual  *pcTemplCandidate)
{
	vector  <int>  v_templates_offsets,  v_chosen_templates_offsets;//for "the same templates" check
	int  i_chosen_template_offset;


	if  (i_the_same_template_check  >  0)
	{
		//now checking if the same template is not in random piece of the current templates
									
		v_chosen_templates_offsets.clear();

		//now choosing proper number of random templates
		if  ((int) pv_pattern_pool->size()  <=  i_the_same_template_check)
		{
			//just copy if we are to take all anyway...
			for  (int  ii = 0; ii < (int)  pv_pattern_pool->size();  ii++)
				v_chosen_templates_offsets.push_back(ii);
		}//if  (pv_pattern_pool->size()  <=  i_the_same_template_check)
		else
		{
			v_templates_offsets.clear();
			for  (int  ii = 0; ii < (int) pv_pattern_pool->size();  ii++)
				v_templates_offsets.push_back(ii);

			//we randomly choose offsets...
			for  (int  ii = 0; ii < i_the_same_template_check;  ii++)
			{
				i_chosen_template_offset  =  lRand(v_templates_offsets.size());//pc_random_gen->Next(0,  v_templates_offsets.size());
				v_chosen_templates_offsets.push_back(v_templates_offsets.at(i_chosen_template_offset));
				v_templates_offsets.erase(v_templates_offsets.begin()  +  i_chosen_template_offset);
			}//for  (int  ii = 0; ii < i_the_same_template_check;  ii++)

		
		}//else  if  (pv_pattern_pool->size()  <=  i_the_same_template_check)

	}//if  (i_the_same_template_check  >  0)
	
	for  (int  ii = 0; ii < (int) v_chosen_templates_offsets.size();  ii++)
	{
		if  (
			pcTemplCandidate->bCompareFenotypes
				(
				pv_pattern_pool->at(v_chosen_templates_offsets.at(ii))
				)
			==
			true
			)
		return(false);
	}//for

	return(true);
}//bool  CTrajectorySetsFinder::b_the_same_templates_check()





CError  CTrajectorySetsFinder::eFindBestSet_vmEA
		(
		System::Windows::Forms::ListBox *  listComm,
		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		CString  sIniFile,
		CString  sReportFileName,
		CString  sFileSummarize,



		int  iGen,
		bool  bGlueInfectionRows,//it glueas all infection in a row until the individual is stucked
		bool  bFitnessChangeTemplCheck,
		int  iPatternPoolSize,
		int  iTheSameTemplateCheck,//the number of templates checked with new. If any is the same, new template is NOT accepted
		int  iPreferredTemplateLength,
		int  iMinimalTemplateLength,
		bool  bPatternCheckLengthEntophy,

		bool  bUseTemplatesAtVirusPopInit,

		int  iVirusGen,
		int  iVirusPopSize, 
		double  dPopReductionJuxtapositional,
		double  dVirProbCut,  double  dVirProbSplice,
		double  dVirProbMut,
		double  dVirProbMutRemGene,
		double  dVirProbMutAddGene,
		double  dVirProbLowCross,
		double  dVirProbLowMut,
		double  dVirProbInitMut,
		int  iVirginityRounds,
		int  iCtStrategy,
		int  iParentSelection,
		int  iNewCtDisturbedCopy,
		int  iNewCtDisturbedLLDSI,
		double  dNewCtDisturbedGeneDisturbedProb
		)
{
	CError  c_err;

	//::Tools::vShow(dNewCtDisturbedGeneDisturbedProb);

	l_penalty  =  lPenalty;


	if  (pv_pattern_pool  !=  NULL)
	{
		for  (int  ii = 0; ii < (int) pv_pattern_pool->size(); ii++)
			delete  pv_pattern_pool->at(ii);
		delete  pv_pattern_pool;
	}//pv_pattern_pool
	pv_pattern_pool  =  new  vector  <CMessyPattern  *>;


	/*FILE  *pf_fom_tracking;
	
	if  (sPopulationFOMtrackingFile  !=  "")
	{
		pf_fom_tracking  =  fopen( (LPCSTR) sPopulationFOMtrackingFile, "w+");
		if  (pf_fom_tracking  ==  NULL)  
		{
			c_err.vPutError("Couldn't open FOM tracking file");
			return(c_err);
		
		}//if  (pf_fom_tracking  ==  NULL)  
		else
			fprintf(pf_fom_tracking,"Pop number  \tAverage population FOM\t\t Best specie FOM \t Brain Storm \t Time\n\n");
					
	}//if  (sPopulationFOMtrackingFile  !=  "")  */


	if  (pv_population  !=  NULL)
	{
		for  (int  ii = 0; ii < (int) pv_population->size();  ii++)
			delete  pv_population->at(ii);	
		pv_population->clear();
	}//if  (pv_population  !=  NULL)
	else
		pv_population  =  new  vector  <CSingleTrajectorySet *>;

	if  (listComm  !=  NULL)
	{
		listComm->Items->Add(S"Initting...1");
		listComm->Refresh();
	}//if  (listInfo  !=  NULL)



	//for parameter check...
	c_err  =  eConfigure
		(
		iGen,
		bGlueInfectionRows,//it glueas all infection in a row until the individual is stucked
		bFitnessChangeTemplCheck,
		iPatternPoolSize,
		iTheSameTemplateCheck,//the number of templates checked with new. If any is the same, new template is NOT accepted
		iPreferredTemplateLength,
		iMinimalTemplateLength,
		bPatternCheckLengthEntophy,

		bUseTemplatesAtVirusPopInit,

		iVirusGen,
		iVirusPopSize, 
		dPopReductionJuxtapositional,
		dVirProbCut,  dVirProbSplice,
		dVirProbMut,
		dVirProbMutRemGene,
		dVirProbMutAddGene,
		dVirProbLowCross,
		dVirProbLowMut,
		dVirProbInitMut,
		iVirginityRounds,
		iNewCtDisturbedCopy,
		iNewCtDisturbedLLDSI,
		dNewCtDisturbedGeneDisturbedProb
		);
	if  (c_err)  return(c_err);


	//for (int  ii = 0; ii < i_pop_size;  ii++)
	//v_add_new_ct();


	if  (listComm  !=  NULL)
	{
		listComm->Items->Add(S"Initting...2");
		listComm->Refresh();
	}//if  (listInfo  !=  NULL)



	
	
	double  d_pop_avr_fom = 0;//the information colector for "brain storm" supervisor
	double  d_fom_modifier = 0;//the modifier set up by "brain storm" supervisor


	CTimeCounter  c_time_counter;
	FILE  *pf_report;
	pf_report  =  fopen(sReportFileName,  "w+");
	vSaveParameters(pf_report);

	CString  s_buf;
	c_time_counter.vSetStartNow();

	double  d_buf,  d_prev_best_fitness, d_best_fitness,  d_prev_average,  d_average,  d_time_passed, d_time_passed_qpc, d_time_passed_cpu;
	double  d_best_fitness_current_solution;
	double  d_time_until_best, d_ffe_until_best;
	double  d_unitation_perc, d_time_passed_till_max, d_fitness_eval_till_max;

	int  i_vir_init_done,  i_break_at_the_same_base,  i_break_at_immediate_infect;
	int  i_best_not_changed_after_stuck;

	d_time_until_best = 0;
	d_ffe_until_best = 0;
	d_time_passed  =  0;
	i_break_at_the_same_base  =  0;
	i_break_at_immediate_infect  =  0;
	d_prev_average  =  0;
	d_average  =  1;
	d_prev_best_fitness = 0;
	d_best_fitness  =  0;
	i_best_not_changed_after_stuck = 0;
	int  i_iteration = 0;//prw remove
	bool  b_one_ct_and_virgin = true;//prw remove
	double  d_prev_fit_buf, d_fit_after_vir_run;


	v_add_new_ct(sIniFile, iCtStrategy);
	pv_population->at(pv_population->size()-1)->d_ranking_objective_weight = 0;

	if  (listComm  !=  NULL)  listComm->Items->Add(S"Started..");
	for (int  i_cur_gen = 0; (d_time_passed < i_gen)&&(d_best_fitness  <  1.0)&&(b_one_ct_and_virgin == true);  i_cur_gen++)//prw remove
	{
		//fprintf(pf_report,  "Generation: %d \n", i_cur_gen);

		if  ((d_prev_best_fitness  ==  d_best_fitness)||(iCtStrategy  >=  0))
		{
			if  (d_average  ==  d_prev_average)
			{
				i_best_not_changed_after_stuck++;

				v_remove_the_same_ct();//we remove cts that are exactly the same
				s_buf.Format
					(
					"ct number refresh; number after refresh: %d [memo: %d]",  
					pv_population->size(),
					v_memo_cts.size()
					);
				listComm->Items->Add((System::String *) s_buf);
				listComm->SelectedIndex  =  listComm->Items->Count - 1;
				listComm->Refresh();
				
				if  (
					( (i_best_not_changed_after_stuck  >  0)&&(iCtStrategy < 0) )
					||
					(iCtStrategy >= 0)
					)
				{
					if  (iCtStrategy < 0)
					{
						s_buf.Format
							(
							"ct population stucked %d times -> increase CT number to: %d",  
							i_best_not_changed_after_stuck,
							pv_population->size()+1
							);
						listComm->Items->Add((System::String *) s_buf);
						listComm->SelectedIndex  =  listComm->Items->Count - 1;
						listComm->Refresh();					
					}//if  (iNoNewCt < 0)

					//if  (pv_population->size()  ==  0) v_add_new_ct();//we add new ct to population if we are stucked
					v_add_new_ct(sIniFile, iCtStrategy);//we add new ct to population if we are stucked
					//if  (pv_population->size() > 2)
					//	pv_population->at(pv_population->size()-1)->d_ranking_objective_weight = 1.0 - 1.0 / pv_population->size();
				}//if  (i_best_not_changed_after_stuck  >  5)
			}//if  (d_average  ==  d_prev_average)
			else
				i_best_not_changed_after_stuck = 0;
		}//if  (d_prev_best_fitness  ==  d_best_fitness)
		else
		{
			i_best_not_changed_after_stuck = 0;

			if  (pv_population->size()  >  1)
			{
				if  (iCtStrategy  == -1)  v_remove_the_same_ct();//classic
				if  (iCtStrategy  == -2)  v_remove_all_ct_except_best();//active
				if  (iCtStrategy  == -3)  v_remove_all_ct_except_best_and_remember();//memo
				if  (iCtStrategy  == -4)  v_remove_all_ct_except_best_and_remember();//total memo
				if  (iCtStrategy  == -5)  v_remove_all_ct_except_best_and_remember_and_remove_one_randomly();//total memo with exchange
				
			
				s_buf.Format
					(
					"ct best fitness increased - reducing CT number to: %d [memo: %d]",  
					pv_population->size(),
					v_memo_cts.size()
					);
				listComm->Items->Add((System::String *) s_buf);
				listComm->SelectedIndex  =  listComm->Items->Count - 1;
				listComm->Refresh();		
			}//if  (pv_population->size()  >  1)

			
		}//else  if  (d_prev_best_fitness  ==  d_best_fitness)

		if  (d_prev_best_fitness  <  d_best_fitness)
		{
			c_time_counter.bGetTimePassed(&d_time_until_best);
			d_ffe_until_best = c_translator.pcGetFittnesCounter()->dEvalNumber();
		}//if  (d_prev_best_fitness  <  d_best_fitness)

		d_prev_average  =  d_average;
		d_prev_best_fitness  =  d_best_fitness;


		//first we remove virginity
		int  i_virginity_current_round;
		for (int  ii = 0; (ii < (int) pv_population->size())&&(d_time_passed < i_gen);  ii++)
		{

			i_virginity_current_round = 0;
			while  ( (pv_population->at(ii)->bGetVirgin()  ==  true)&&(d_time_passed < i_gen)&&(i_virginity_current_round < i_virginity_rounds) )//prw remove
			{
				i_iteration++;
				i_virginity_current_round++;
				if  (b_use_templates_at_virus_pop_init  ==  true)
					pv_population->at(ii)->eVirReGeneratePopulation(this, false);	
				else
				{
					c_err.vPutError("we must use b_use_templates_at_virus_pop_init");
					return(c_err);
				}//	pv_population->at(ii)->eVirGeneratePopulation(i_templ_length);

				
				//pv_population->at(ii)->d_ranking_objective_weight = 0;
				c_err  =  pv_population->at(ii)->eVirRun(pv_pattern_pool, this,  &i_vir_init_done, iParentSelection);
					
				v_get_new_patterns();//PRW CHANGE!!!


				c_time_counter.bGetTimePassedCPUTime(&d_time_passed_cpu);
				c_time_counter.bGetTimePassedQTCT(&d_time_passed_qpc);
				c_time_counter.bGetTimePassed(&d_time_passed);
				s_buf.Format
					(
					"removing virginity fitness: %.16lf [patterns: %d] [evaluations:%lf] [time passed:%.4lf] [QPC: %lf] [CPU: %lf]",  
					pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty),
					pv_pattern_pool->size(),
					c_translator.pcGetFittnesCounter()->dEvalNumber(),
					d_time_passed, d_time_passed_qpc, d_time_passed_cpu
					);
				listComm->Items->Add((String *) s_buf);
				listComm->SelectedIndex  =  listComm->Items->Count - 1;
				listComm->Refresh();

				
				System::Windows::Forms::Application::DoEvents();

					/*s_buf.Format
						(
						"INFO LINE: virnigty %d  Time passed:%.4lf < %d   %d < %d",  
						pv_population->at(ii)->bGetVirgin(), 
						d_time_passed, i_gen,
						i_virginity_current_round, i_virginity_rounds
						);
					listComm->Items->Add((String *) s_buf);
					listComm->SelectedIndex  =  listComm->Items->Count - 1;
					listComm->Refresh();

					System::Windows::Forms::Application::DoEvents();*/
			}//while  (pv_population->at(ii)->bGetVirgin()  ==  true)
		
			//b_one_ct_and_virgin = false;
			pv_population->at(ii)->b_virgin_init = false;

		}//for (int  ii = 0; ii < (int) pv_population->size();  ii++)


		if  (d_prev_best_fitness  <  d_best_fitness)
		{
			c_time_counter.bGetTimePassed(&d_time_until_best);
			d_ffe_until_best = c_translator.pcGetFittnesCounter()->dEvalNumber();
		}//if  (d_prev_best_fitness  <  d_best_fitness)


		d_best_fitness_current_solution = 0;
		d_best_fitness  =  0;
		d_average  =  0;
		for (int  ii = 0; ii < (int) pv_population->size();  ii++)
		{
			

				if  (b_use_templates_at_virus_pop_init  ==  true)
					pv_population->at(ii)->eVirReGeneratePopulation(this, false);	
//				else
//					pv_population->at(ii)->eVirGeneratePopulation(i_templ_length, b_vir_init_different_to_template);


				//CString  s_buf;
				//s_buf.Format("%d", pv_population->at(ii)->pv_population->size());
				//::MessageBox(NULL, s_buf, "", MB_OK);

				//pv_population->at(0)->d_ranking_objective_weight = 0;

				d_prev_fit_buf  =  pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);
				c_err  =  pv_population->at(ii)->eVirRun(pv_pattern_pool, this,  &i_vir_init_done, iParentSelection);
				d_fit_after_vir_run  =  pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);


				if  ( (d_prev_fit_buf >= d_fit_after_vir_run)&&(d_fit_after_vir_run == pv_population->at(ii)->dGetBestResultOnTheRunFitness()) )
				{
					if  (pv_population->at(ii)->d_ranking_objective_weight == 0)
						pv_population->at(ii)->d_ranking_objective_weight = dRand();
					else
						pv_population->at(ii)->d_ranking_objective_weight = 0;
				}//if  (d_prev_fit_buf >= d_fit_after_vir_run)
				else
					pv_population->at(ii)->d_ranking_objective_weight = 0;//*/
					

				/*if  (d_prev_fit_buf >= d_fit_after_vir_run)
				{
					//pv_population->at(ii)->d_ranking_objective_weight = dRand();

					if  (b_use_templates_at_virus_pop_init  ==  true)
						pv_population->at(ii)->eVirReGeneratePopulation(this, false);	

					pv_population->at(ii)->b_fom_lvl_actual = false;
					d_prev_fit_buf = pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);
					int  i_buf;
					pv_population->at(ii)->v_try_pattern_and_template_insert(this,  &i_buf, pl_capacities, l_penalty);
					d_fit_after_vir_run  =  pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);

					if  (listComm  !=  NULL)
					{
						s_buf.Format
							(
							"CT after insert: START:%.16lf END:%.16lf",  
							d_prev_fit_buf, d_fit_after_vir_run
							);
						listComm->Items->Add((String *) s_buf);
						listComm->SelectedIndex  =  listComm->Items->Count - 1;
						listComm->Refresh();

						System::Windows::Forms::Application::DoEvents();
					}//if  (listInfo  !=  NULL)


					int  i_steps_no = 2;

					for (int i_step = 0; i_step < i_steps_no; i_step++)
					{
						pv_population->at(ii)->d_ranking_objective_weight = i_step;
						pv_population->at(ii)->d_ranking_objective_weight = 1.0 - pv_population->at(ii)->d_ranking_objective_weight / (i_steps_no - 1);

						c_err  =  pv_population->at(ii)->eVirRun(pv_pattern_pool, this,  &i_vir_init_done, iParentSelection, false);

						d_fit_after_vir_run  =  pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);

						if  (i_step == i_steps_no - 1)  pv_population->at(ii)->vRestoreCT(this);


						
						c_time_counter.bGetTimePassedCPUTime(&d_time_passed_cpu);
						c_time_counter.bGetTimePassedQTCT(&d_time_passed_qpc);
						c_time_counter.bGetTimePassed(&d_time_passed);

						if  (listComm  !=  NULL)
						{
							s_buf.Format
								(
								"Fluent optimization %d weight:%.4lf START:%.16lf END:%.16lf   [fitness evaluations:%lf] [time passed:%.4lf] [QPC: %lf] [CPU: %lf] [TimeBest: %.2lf][FFEBest: %lf]",  
								ii, pv_population->at(ii)->d_ranking_objective_weight, d_prev_fit_buf, d_fit_after_vir_run,

								c_translator.pcGetFittnesCounter()->dEvalNumber(),
								d_time_passed, d_time_passed_qpc, d_time_passed_cpu,
								d_time_until_best, d_ffe_until_best
								);
							listComm->Items->Add((String *) s_buf);
							listComm->SelectedIndex  =  listComm->Items->Count - 1;
							listComm->Refresh();

							System::Windows::Forms::Application::DoEvents();
						}//if  (listInfo  !=  NULL)
					}//for (int i_step = 0; i_step < 5; i_step++)


						//double  d_factor;
						//d_factor = ii;
						//d_factor = d_factor / pv_population->size();
						//pv_population->at(ii)->d_ranking_objective_weight *= d_factor;
						//s_buf.Format("factor: %.4lf  weight: %.4lf", d_factor, pv_population->at(ii)->d_ranking_objective_weight);
						//::Tools::vShow(s_buf);
				}//if  (d_prev_fit_buf >= d_fit_after_vir_run)*/


				/*for  (int  ier = 0;  ier < (int) pv_population->at(ii)->pv_population->size();  ier++)
				{
					fprintf
						(
						pf_report, 
						"%d: %.16lf\n", 
						ier, 
						pv_population->at(ii)->pv_population->at(ier)->dComputeFitness
							(
							pv_population->at(ii)->pc_trajectories,  c_translator.pcGetFittnesCounter(),
							pl_capacities, l_penalty, pv_population->at(ii)->pc_net_sim
							)
						);
				}//for  (int  ier = 0;  ii < (int) pv_population->size();  ier++)*/

				if  (i_vir_init_done  ==  1)  i_break_at_the_same_base++;
				if  (i_vir_init_done  ==  2)  i_break_at_immediate_infect++;

				if  (c_err)
				{
					//fclose(pf_report);
					return(c_err);
				}//if  (c_err)


			
			/*if  (pv_population->at(ii)->pcGetLastInfection()  ==  NULL)
				fprintf(pf_report,  "Individual: %d (STUCKED!)\n", ii);
			else
				fprintf(pf_report,  "Individual: %d \n", ii);
			pv_population->at(ii)->eReport(pf_report);
			//pv_population->at(ii)->vReport(pf_report, false, pl_capacities, l_penalty);
			fprintf(pf_report,  "\n\n");*/

			//d_buf  =  pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);
			d_buf  =  pv_population->at(ii)->dGetBestResultOnTheRunFitness();
			if  (d_buf  >  d_best_fitness)  
			{
				//d_unitation_perc  =  pv_population->at(ii)->iGetUnitation();
				//d_unitation_perc  =  d_unitation_perc  /  i_templ_length;
				//c_time_counter.bGetTimePassed(&d_time_passed_till_max);
				//d_fitness_eval_till_max  =  pc_fitness->dGetFuncEval();
				d_best_fitness  =  d_buf;
				d_best_fitness_current_solution = pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);
			}//if  (d_buf  >  d_best_fitness)  
			d_average  +=  d_buf;

		}//for (int  ii = 0; ii < i_pop_size;  ii++)


		if  (d_prev_best_fitness  <  d_best_fitness)
		{
			c_time_counter.bGetTimePassed(&d_time_until_best);
			d_ffe_until_best = c_translator.pcGetFittnesCounter()->dEvalNumber();
		}//if  (d_prev_best_fitness  <  d_best_fitness)


		c_time_counter.bGetTimePassedCPUTime(&d_time_passed_cpu);
		c_time_counter.bGetTimePassedQTCT(&d_time_passed_qpc);
		c_time_counter.bGetTimePassed(&d_time_passed);
		//fprintf(pf_report,  "\n\nFITNESS EVALUATIONS: %lf  \t  time passed:%.4lf \n\n\n\n", c_translator.pcGetFittnesCounter()->dEvalNumber(), d_time_passed);


		CString  s_factors;
		for  (int ii = 0; ii < pv_population->size(); ii++)
		{
			s_buf.Format("%.4lf | ", pv_population->at(ii)->d_ranking_objective_weight);
			s_factors += s_buf;
		}//for  (int ii = 0; ii < pv_population->size(); ii++)
		

		if  (listComm  !=  NULL)
		{
			CString  s_dif_text;
			s_dif_text = "";
			if  (d_best_fitness != d_best_fitness_current_solution)  s_dif_text = "DIFF!";

			s_buf.Format
				(
				"Generation: %d ct number: %d [%s] (%s best fitness: %.16lf Cur: %.16lf) average: %.16lf best - average:%.16lf  [patterns:%d] [fitness evaluations:%lf] [time passed:%.4lf] [QPC: %lf] [CPU: %lf] [TimeBest: %.2lf][FFEBest: %lf]",  
				i_cur_gen,  pv_population->size(), s_factors, s_dif_text, d_best_fitness, d_best_fitness_current_solution, d_average/pv_population->size(),
				d_best_fitness  - d_average/pv_population->size(),
				pv_pattern_pool->size(),
				c_translator.pcGetFittnesCounter()->dEvalNumber(),
				d_time_passed, d_time_passed_qpc, d_time_passed_cpu,
				d_time_until_best, d_ffe_until_best
				);
			listComm->Items->Add((String *) s_buf);
			listComm->SelectedIndex  =  listComm->Items->Count - 1;
			listComm->Refresh();

			System::Windows::Forms::Application::DoEvents();
		}//if  (listInfo  !=  NULL)


		//now we save infection histories as templates
		v_get_new_patterns();
		//v_get_new_patterns_multiple();
		

		//template number control - we delete the overnumbered templates
		v_pattern_number_control_new(b_pattern_check_length_entrophy);  //true - length based pattern fitnes; false - entrophy based pattern fitnes;
		//v_pattern_number_control_multiple(b_pattern_check_length_entrophy);
		

		
		//fprintf(pf_report,  "\n\n\n");
		System::Windows::Forms::Application::DoEvents();
	}//for (int  ii = 0; ii < i_gen;  ii++)

	
	std::sort(pv_pattern_pool->begin(),  pv_pattern_pool->end(), bPatternGreater);


	fprintf(pf_report,  "\n\n\nBREAK AT THE SAME BASE: %d\n", i_break_at_the_same_base);
	fprintf(pf_report,  "\n\n\nBREAK AT IMMEDIATE INFECT: %d\n", i_break_at_immediate_infect);
	

	fprintf(pf_report,  "\n\n\nTEMPLATES: %d (%d)\n", pv_pattern_pool->size(), i_max_infections_considered_at_crossing);
	for  (int  ii = 0;  ii < (int) pv_pattern_pool->size();  ii++)
	{
		fprintf(pf_report,  "\n\n\nTEMPLATES: %d\n", ii);
		/*if  (pi_pattern_genes_freq  !=  NULL)
		{
			fprintf(pf_report, "template entrophy fitness: %.8lf\n", pv_pattern_pool->at(ii)->dGetPatternEntrophyFittnes(pi_pattern_genes_freq));
		}//if  (pi_pattern_genes_freq  !=  NULL)*/
		pv_pattern_pool->at(ii)->eReport(pf_report,  true);	


		
	}//for  (int  ii = 0;  ii < (int) v_best_found.size();  ii++)


	fprintf(pf_report,  "\n\n\n");
	/*if  (pi_pattern_genes_freq  !=  NULL)
	{
		fprintf(pf_report, "\n\ngene pattern freq table: \n\t");

		for  (int  ii = 0; ii < i_templ_length; ii++)
			fprintf(pf_report, "%d\t", pi_pattern_genes_freq[ii]);
	}//if  (pi_pattern_genes_freq  !=  NULL)*/

	fprintf(pf_report,  "\n\nFITNESS EVALUATIONS: 0\n\n\n\n");

	
	
	for  (int  ii = 0; ii < (int) pv_population->size();  ii++)
		pv_population->at(ii)->vReport(pf_report, false, pl_capacities, l_penalty);

	fclose(pf_report);

	

	for  (int  ii = 0; ii < (int) pv_pattern_pool->size();  ii++)
		delete  pv_pattern_pool->at(ii);
	pv_pattern_pool->clear();



	FILE  *pf_run_save;
	CString  s_effective_file_name;
	s_effective_file_name.Format("%s_RUN.txt", sReportFileName);
	pf_run_save  =  fopen(s_effective_file_name,  "w+");
	if  (pf_run_save  !=  NULL)
	{
		for  (int  ii = 0; ii  <  listComm->Items->get_Count();  ii++)
		{
			s_buf  =  listComm->Items->get_Item(ii)->ToString();		
			fprintf(pf_run_save,  "%s\n", s_buf);
		}//for  (int  ii = 0; ii  <  listInfo->Items->get_Count();  ii++)
		fclose(pf_run_save);
	}//if  (pf_run_save  !=  NULL)


	int  i_best_specie = 0;
	d_best_fitness = 0;

	for  (int  ii = 0; ii  <  pv_population->size();  ii++)
	{
		//d_buf  =  pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty);
		d_buf  =  pv_population->at(ii)->dGetBestResultOnTheRunFitness();
		
		if  (d_buf  >  d_best_fitness)
		{
			d_best_fitness  =  d_buf;
			i_best_specie = ii;			
		}//if  (d_buf  >  d_best_fitness)
	}//for  (int  ii = 0; ii  <  listInfo->Items->get_Count();  ii++)


	FILE  *pf_full_report;
	s_effective_file_name.Format("%s.ful", sReportFileName);
	pf_full_report  =  fopen(s_effective_file_name,  "w+");
	if  (pf_full_report  !=  NULL)
	{
		pv_population->at(i_best_specie)->vReport(pf_full_report, true, pl_capacities, l_penalty);
		fclose(pf_full_report);
	}//if  (pf_run_save  !=  NULL)



	if  (sFileSummarize  !=  "")
	{
		FILE  *pf_summarized_rep;
		pf_summarized_rep  =  fopen(sFileSummarize, "a");

		double  d_optimized_func_val;
		d_optimized_func_val =  Math::Round(((double) 1.0) / d_best_fitness  -1);
		

		double  d_path_len_avr;
		int i_path_len_min, i_path_len_max;

		pv_population->at(i_best_specie)->vGetPathStats(&d_path_len_avr, &i_path_len_min, &i_path_len_max);

		CString  s_path_lens;
		s_path_lens = pv_population->at(i_best_specie)->sReportPathLens(20);

		//TUTAJ DOLOZYC SREDNIA SLUGOSC SCIEZKI I MINIMALNA/MAKSYMALNA DLUGOSC SCIEZKI, EWENTUALNIE LICZBE SCEIZEK O DLUGOSCI 1,2,3,4,5,...,20, 20<
		fprintf
			(pf_summarized_rep, 
			"%d \t %.8lf \t %.0lf \t %.4lf \t %d \t %d \t %.0lf \t %.2lf \t %lf \t %lf \t %d \t %.2lf \t %lf \t \t %s \t %s \n", 

			i_iteration,//prw remove
			d_best_fitness, d_optimized_func_val,
			d_path_len_avr, i_path_len_min, i_path_len_max,
			c_translator.pcGetFittnesCounter()->dEvalNumber(),
			d_time_passed, d_time_passed_qpc, d_time_passed_cpu, i_gen, 
			d_time_until_best, d_ffe_until_best,
			sReportFileName,
			s_path_lens
			);
		fclose(pf_summarized_rep);		
	}//if  (sFileSummarize  !=  "")
	
	



	return(c_err);
}//CError  CTrajectorySetsFinder::eFindBestSet_vmEA






void  CTrajectorySetsFinder::v_pattern_number_control_new(bool  bLengthEntrophy)
{
	while  ((int)  pv_pattern_pool->size()  >  i_max_infections_considered_at_crossing)
	{
		int  i_indiv;

		i_indiv  =  lRand(pv_pattern_pool->size());//pc_random_gen->Next(0,  pv_pattern_pool->size());

		delete  pv_pattern_pool->at(i_indiv);
		pv_pattern_pool->erase(pv_pattern_pool->begin()  +  i_indiv);
	}//while  ((int)  pv_new_pattern_pool->size()  <  i_max_infections_considered_at_crossing)

	return;
}//void  CTrajectorySetsFinder::v_pattern_number_control_new(bool  bLengthEntrophy)




void  CTrajectorySetsFinder::v_get_new_patterns()
{
	
	for (int  ii = 0; ii < (int) pv_population->size();  ii++)
	{

		if  (pv_population->at(ii)->pcGetInfectionHistory()  !=  NULL)
		{
			if  (pv_population->at(ii)->pcGetInfectionHistory()->pvGetGenotype()->size()  >  0)
			{
				if  (b_fitness_change_templ_check  ==  true)
				{
					if  (
							(
							pv_population->at(ii)->dCountFOM(c_translator.pcGetFittnesCounter(), pl_capacities, l_penalty)
							>
							pv_population->at(ii)->dGetCompTemplateFitnessBeforeCrossing()						
							)
							&&
							(
							i_minimal_template_length  <=
							pv_population->at(ii)->pcGetInfectionHistory()->iGetFenotypeLength()
							)
						)
					{
						if  (b_the_same_templates_check(pv_population->at(ii)->pcGetInfectionHistory())  ==  true)
						{
							CMessyPattern  *pc_buf;
							pc_buf  =  new   CMessyPattern(i_number_of_pairs);
							*pc_buf  =  *(pv_population->at(ii)->pcGetInfectionHistory());
							pv_pattern_pool->push_back(pc_buf);
							pv_population->at(ii)->vSetInfectionHistory(NULL);

							//compute gene freq if necessary
							/*if  (pi_pattern_genes_freq  !=  NULL)
							{
								for  (int  ij = 0;  ij  <  i_templ_length; ij++)
								{
									if  (pc_buf->piGetFenotype()[ij]   !=  -1)
										pi_pattern_genes_freq[ij]++;			
								}//for  (int  ij = 0;  ij  <  (int) pv_pattern_pool->at(ii)->pvGetGenotype()->size(); ij++)
							
							}//if  (pi_pattern_genes_freq  !=  NULL)*/
						}//if  (b_chosen_templates_check_passed  ==  true)

					}//if  (
				}//if  (b_fitness_change_templ_check  ==  true)
				else
				{
					if  (
							i_minimal_template_length  <=
							pv_population->at(ii)->pcGetInfectionHistory()->iGetFenotypeLength()
						)
					{
						if  (b_the_same_templates_check(pv_population->at(ii)->pcGetInfectionHistory())  ==  true)
						{
							CMessyPattern  *pc_buf;
							pc_buf  =  new   CMessyPattern(i_number_of_pairs);
							*pc_buf  =  *(pv_population->at(ii)->pcGetInfectionHistory());
							pv_pattern_pool->push_back(pc_buf);
							pv_population->at(ii)->vSetInfectionHistory(NULL);

							//compute gene freq if necessary
							/*for  (int  ij = 0;  ij  <  i_templ_length; ij++)
							{
								if  (pc_buf->piGetFenotype()[ij]   !=  -1)
									pi_pattern_genes_freq[ij]++;			
							}//for  (int  ij = 0;  ij  <  (int) pv_pattern_pool->at(ii)->pvGetGenotype()->size(); ij++)*/
						}//if  (b_the_same_templates_check()  ==  true)					
					}//if  (
					
				}//else  if  (b_fitness_change_templ_check  ==  true)
			}//if  (pv_population->at(ii)->pcGetInfectionHistory()->pvGetGenotype()->size()  >  0)
		}//if  (pv_population->at(ii)->pcGetInfectionHistory()  !=  NULL)				
	}//for (int  ii = 0; ii < (int) pv_population->size();  ii++)
}//void  CTrajectorySetsFinder::v_get_new_templates()





CMessyPattern*  CTrajectorySetsFinder::pc_get_random_pattern()
{
	if  (pv_pattern_pool->size()  ==  0)  return(NULL);

	int  i_pattern;

	i_pattern  =  lRand(pv_pattern_pool->size());// pc_random_gen->Next(0,  pv_pattern_pool->size());
	return(pv_pattern_pool->at(i_pattern));
}//CMessyPattern*  CTrajectorySetsFinder::pc_get_random_pattern()



void  CTrajectorySetsFinder::vSaveParameters(FILE  *pfReport)
{
	fprintf(pfReport, "%d\\\\%s\n",  i_gen, VGA_PARAM_MAX_TIME);
	fprintf(pfReport, "%d\\\\%s\n",  i_pop_size, VGA_PARAM_POP_SIZE);
	fprintf(pfReport, "%.6lf\\\\%s\n",  d_prob_cross, VGA_PARAM_PROB_CROSS);
	fprintf(pfReport, "%d\\\\%s\n",  b_static_cross, VGA_PARAM_STATIC_CROSS);
	
	fprintf(pfReport, "%d\\\\%s\n",  b_glue_infection_rows, VGA_PARAM_GLUE_INFECTIONS);
	fprintf(pfReport, "%d\\\\%s\n",  b_fitness_change_templ_check, VGA_PARAM_TEMPL_FITNESS_CHECK);
	fprintf(pfReport, "%d\\\\%s\n",  i_max_infections_considered_at_crossing, VGA_PARAM_PATTERN_POOL_SIZE);
	fprintf(pfReport, "%d\\\\%s\n",  i_the_same_template_check, VGA_PARAM_SAME_PATTERN_CHECK);
	fprintf(pfReport, "%d\\\\%s\n",  i_preferred_template_length, VGA_PARAM_PREFERRED_PATTERN_LENGTH);
	fprintf(pfReport, "%d\\\\%s\n",  i_minimal_template_length, VGA_PARAM_MINIMAL_PATTERN_LEN);
	fprintf(pfReport, "%d\\\\%s\n",  b_pattern_check_length_entrophy, VGA_PARAM_LEN_OR_ENTROPHY);
	

	fprintf(pfReport, "%d\\\\%s\n",  b_use_templates_at_virus_pop_init, VGA_PARAM_USE_TEMPL_AT_VIRUS_INIT);
	
	
	fprintf(pfReport, "%d\\\\%s\n",  i_virus_gen, VGA_PARAM_VIR_GENERATIONS);
	fprintf(pfReport, "%d\\\\%s\n",  i_virus_pop_size, VGA_PARAM_VIR_POP);
	fprintf(pfReport, "%.6lf\\\\%s\n",  d_pop_reduction_juxtapositional, VGA_PARAM_VIR_POP_RED);
	
	fprintf(pfReport, "%.6lf\\\\%s\n",  d_vir_prob_cut, VGA_PARAM_VIR_PROB_CUT);
	fprintf(pfReport, "%.6lf\\\\%s\n",  d_vir_prob_splice, VGA_PARAM_VIR_PROB_SPLICE);
	fprintf(pfReport, "%.6lf\\\\%s\n",  d_vir_prob_mut, VGA_PARAM_VIR_PROB_MUT);
	fprintf(pfReport, "%.6lf\\\\%s\n",  d_prob_mut_rem_gene, VGA_PARAM_VIR_REM_GENE);
	fprintf(pfReport, "%.6lf\\\\%s\n",  d_prob_mut_add_gene, VGA_PARAM_VIR_ADD_GENE);
	fprintf(pfReport, "%.6lf\\\\%s\n",  d_prob_low_level_cross, VGA_PARAM_VIR_LOW_CROSS);
	fprintf(pfReport, "%.6lf\\\\%s\n",  d_prob_low_level_mut, VGA_PARAM_VIR_LOW_CROSS);
	fprintf(pfReport, "%.6lf\\\\%s\n",  d_prob_init_mut, VGA_PARAM_VIR_INIT_MUT);
	fprintf(pfReport, "%d\\\\%s\n",  i_virginity_rounds, VGA_PARAM_VIR_VIRGINITY_ROUNDS);

				

	fprintf(pfReport, "\n\n\n\n\n");

}//void  CTrajectorySetsFinder::vSaveParameters(FILE  *pfReport)





CError  CTrajectorySetsFinder::eConfigure
	(
	int  iGen,
	bool  bGlueInfectionRows,//it glueas all infection in a row until the individual is stucked
	bool  bFitnessChangeTemplCheck,
	int  iPatternPoolSize,
	int  iTheSameTemplateCheck,//the number of templates checked with new. If any is the same, new template is NOT accepted
	int  iPreferredTemplateLength,
	int  iMinimalTemplateLength,
	bool  bPatternCheckLengthEntophy,

	bool  bUseTemplatesAtVirusPopInit,

	int  iVirusGen,
	int  iVirusPopSize, 
	double  dPopReductionJuxtapositional,
	double  dVirProbCut,  double  dVirProbSplice,
	double  dVirProbMut,
	double  dVirProbMutRemGene,
	double  dVirProbMutAddGene,
	double  dVirProbLowCross,
	double  dVirProbLowMut,
	double  dVirProbInitMut,
	int  iVirginityRounds,
	int  iNewCtDisturbedCopy,
	int  iNewCtDisturbedLLDSI,
	double  dNewCtDisturbedGeneDisturbedProb
	)
{

	CError  c_err;


	if  (iGen  <  0)
	{
		c_err.vPutError("Number of generations below 0");
		return(c_err);	
	}//if  (iVirusNumber  <  0)



	if  (iPatternPoolSize  <  0)
	{
		c_err.vPutError("Generations considered at high lvl crossing below 0");
		return(c_err);
	}//if  (iGenMax  <  0)



	if  (iPreferredTemplateLength  <  0)
	{
		c_err.vPutError("Preferred template length below 0");
		return(c_err);
	}//if  (iGenMax  <  0)


	if  (iMinimalTemplateLength  <  0)
	{
		c_err.vPutError("Minimal template length below 0");
		return(c_err);
	}//if  (iGenMax  <  0)






	if  (iVirusGen  <  0)
	{
		c_err.vPutError("Virus generation number below 0");
		return(c_err);	
	}//if  (iVirusNumber  <  0)

	if  (iVirusPopSize  <  0)
	{
		c_err.vPutError("Vires number per individual below 0");
		return(c_err);	
	}//if  (iVirusNumber  <  0)


	if  (dVirProbCut  <  0)
	{
		c_err.vPutError("Virus probability of cut below 0");
		return(c_err);	
	}//if  (iVirusNumber  <  0)

	if  (dVirProbSplice  <  0)
	{
		c_err.vPutError("Virus probability of splice below 0");
		return(c_err);	
	}//if  (iVirusNumber  <  0)

	if  (dVirProbMut  <  0)
	{
		c_err.vPutError("Virus probability of mutate below 0");
		return(c_err);	
	}//if  (iVirusNumber  <  0)

	if  (dVirProbMutRemGene  <  0)
	{
		c_err.vPutError("Virus probability of mutate below 0");
		return(c_err);	
	}//if  (iVirusNumber  <  0)

	if  (dVirProbMutAddGene  <  0)
	{
		c_err.vPutError("Virus probability of mutate below 0");
		return(c_err);	
	}//if  (iVirusNumber  <  0)


	if  (iTheSameTemplateCheck  <  0)
	{
		c_err.vPutError("The same template check below 0");
		return(c_err);	
	}//if  (iTheSameTemplateCheck  <  0)



	

	i_gen  =  iGen;

	b_glue_infection_rows  =  bGlueInfectionRows;//it glueas all infection in a row until the individual is stucked
	b_fitness_change_templ_check  =  bFitnessChangeTemplCheck;//if true cthen every template must cause any change fitness change in the next population if not the template candidate is not considered
	i_max_infections_considered_at_crossing  =  iPatternPoolSize;
	i_the_same_template_check  =  iTheSameTemplateCheck;
	i_preferred_template_length  =  iPreferredTemplateLength;
	i_minimal_template_length  =  iMinimalTemplateLength;
	b_pattern_check_length_entrophy  =  bPatternCheckLengthEntophy;

	b_use_templates_at_virus_pop_init  =  bUseTemplatesAtVirusPopInit;

	i_virus_gen  =  iVirusGen;
	i_virus_pop_size  =  iVirusPopSize;
	d_pop_reduction_juxtapositional  =  dPopReductionJuxtapositional;
	d_vir_prob_cut  =  dVirProbCut;
	d_vir_prob_splice  =  dVirProbSplice;
	d_vir_prob_mut  =  dVirProbMut;
	d_prob_mut_rem_gene  =  dVirProbMutRemGene;
	d_prob_mut_add_gene  =  dVirProbMutAddGene;
	d_prob_low_level_cross = dVirProbLowCross;
	d_prob_low_level_mut = dVirProbLowMut;
	d_prob_init_mut = dVirProbInitMut;
	i_virginity_rounds =   iVirginityRounds;

	i_new_ct_disturbed_copy = iNewCtDisturbedCopy;
	i_new_ct_disturbed_LLDSI = iNewCtDisturbedLLDSI;
	d_new_ct_disturbed_gene_disturbed_prob = dNewCtDisturbedGeneDisturbedProb;
	
//asd
	
	return(c_err);
}//CError  CVirusGA::CVirusGAeConfigure


